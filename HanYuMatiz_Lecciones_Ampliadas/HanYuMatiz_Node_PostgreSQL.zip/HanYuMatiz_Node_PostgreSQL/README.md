# HanYuMatiz — Node.js + PostgreSQL

196 palabras, 16 lecciones, 54 pares, 217 casos para comparar y 232 ejercicios en el banco completo. Las lecciones trabajan 217 situaciones distintas con una pregunta por contexto. Los 162 casos originales de comparación también se practican como ejercicios.

Interfaz HTML/CSS/JavaScript y servidor Node.js. No requiere Python. Si solo quieres estudiar o probar la página, usa el ZIP HTML: descomprímelo y abre su archivo HTML sin instalar este proyecto.

Requisitos de la web conectada: Node.js 22 o posterior y Docker, o una instancia PostgreSQL externa configurada como se explica en docs/BASE_DATOS_REPORTES.md.

Desde esta carpeta:

```bash
npm ci --cache .local/npm-cache --no-fund --no-audit
npm run db:start
npm run db:import
npm start
```

Abre http://127.0.0.1:8770. La bandeja privada está en /admin. Las credenciales se generan en .local/node-admin.json; son privadas y no se incluyen en este paquete.

El catálogo editable está en data/catalog.json. Para corregir contenido, conserva sus IDs, edita los textos y ejecuta npm run db:import. El importador calcula una nueva versión, conserva la anterior y mantiene los reportes vinculados a la versión que se comentó. Recarga la página después de importar.

Para generar otra copia HTML: node tools/build_preview.mjs. Para las pruebas SQL: npm run test:backend.

Los reportes web se almacenan realmente en PostgreSQL y solo el propietario autenticado puede consultarlos. El HTML autónomo conserva borradores locales y permite descargarlos. Para recibir reportes desde Internet falta desplegar el servidor con HTTPS y su base de datos.

Este paquete excluye credenciales, comentarios de usuarios y expedientes de auditoría. Las lecciones originales no están clasificadas como curso HSK oficial.
