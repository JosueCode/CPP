/** Build one HTML with its content, styles, fonts and JavaScript included. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { buildCatalog, ROOT } from './catalog.mjs';

const WEB=path.join(ROOT,'web');
const sha=value=>crypto.createHash('sha256').update(value).digest('base64');

function transformModule(name) {
  let code=fs.readFileSync(path.join(WEB,name+'.js'),'utf8');
  code=code.replace(/^import\s*\{([^}]+)\}\s*from\s*['"]\.\/([a-z]+)\.js['"];?\s*$/gm,
    (_,names,dependency)=>`const {${names}}=modules.${dependency};`);
  if (/^import\s/m.test(code)) throw Error('Importación no soportada en el HTML: '+name);
  const exports=[...code.matchAll(/^export\s+(?:async\s+)?(?:function|const|let|class)\s+(\w+)/gm)].map(match=>match[1]);
  code=code.replace(/^export\s+/gm,'');
  if (name==='main') {
    const old="  const response = await fetch('/api/bootstrap', { credentials: 'same-origin', cache: 'no-store' });\n  if (!response.ok) throw new Error('No se pudo cargar el banco autorizado.');\n  bootstrap = await response.json();";
    if(!code.includes(old)) throw Error('Ha cambiado la carga del catálogo; actualizar el adaptador HTML');
    code=code.replace(old,"  bootstrap = JSON.parse(document.querySelector('#previewData').textContent);");
    code=code.replace('Comprueba que has iniciado el servidor y que tu acceso al entorno privado está autorizado.',
      'Vuelve a descargar el HTML completo y ábrelo en un navegador actualizado.');
    code=code.replace('Sin conexión con el servidor','No se pudo abrir la vista');
    return `(async()=>{\n${code}\n})().catch(error=>console.error(error));\n`;
  }
  return `modules.${name}=(()=>{\n${code}\nreturn {${exports.join(',')}};\n})();\n`;
}

export function buildPreview({outputDir, filename='HanYuMatiz_100_Palabras.html'} = {}) {
  if(path.basename(filename)!==filename || !filename.endsWith('.html')) throw Error('Nombre HTML inválido');
  const catalog=buildCatalog({mode:'public'});
  catalog.delivery='standalone';
  const payload=JSON.stringify(catalog).replaceAll('<','\\u003c');
  let css=fs.readFileSync(path.join(WEB,'styles.css'),'utf8');
  css=css.replace("@import url('/v9-base.css');",fs.readFileSync(path.join(WEB,'v9-base.css'),'utf8'));
  for(const filename of ['AtelierUI-Regular.woff2','AtelierUI-Bold.woff2','AtelierHanzi.woff2']) {
    const url='data:font/woff2;base64,'+fs.readFileSync(path.join(WEB,'fonts',filename)).toString('base64');
    css=css.replaceAll(`url('/fonts/${filename}')`,`url('${url}')`);
  }
  if(/@import\b/.test(css)) throw Error('El HTML no puede depender de CSS externo');
  const script="(()=>{\n'use strict';\nconst modules=Object.create(null);\n"+
    ['scheduler','engine','progress','reports','practice','main'].map(transformModule).join('\n')+'\n})();';
  if(/<\/script/i.test(script)||/<\/style/i.test(css)) throw Error('Cierre de etiqueta inesperado');
  const policy=`default-src 'none'; script-src 'sha256-${sha(script)}' 'sha256-${sha(payload)}'; style-src 'sha256-${sha(css)}'; font-src data:; img-src data:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'`;
  let html=fs.readFileSync(path.join(WEB,'index.html'),'utf8');
  html=html.replace('<link rel="stylesheet" href="/styles.css">',`<style>${css}</style>`)
    .replace('<script type="module" src="/main.js"></script>','')
    .replace('<meta name="color-scheme" content="light">',`<meta name="color-scheme" content="light"><meta http-equiv="Content-Security-Policy" content="${policy}">`);
  const licenses=['Lato-OFL.txt','NotoSansSC-OFL.txt'].map(name=>fs.readFileSync(path.join(WEB,'fonts',name),'utf8')).join('\n').replaceAll('--','—');
  html=html.replace('</body>',`<!-- Font licenses: ${licenses} -->\n<script type="application/json" id="previewData">${payload}</script>\n<script>${script}</script>\n</body>`);
  const folder=outputDir ? path.resolve(outputDir) : path.resolve(ROOT,'../shared/downloads/HanYuMatiz_100_Palabras');
  fs.mkdirSync(folder,{recursive:true});
  const target=path.join(folder,filename);
  fs.writeFileSync(target,html);
  const report={file:target,bytes:Buffer.byteLength(html),sha256:crypto.createHash('sha256').update(html).digest('hex'),
    dataVersion:catalog.dataVersion,...catalog.editorial.counts,requiresPython:false,requiresServer:false,
    reportDelivery:'local_draft_and_export',expertReviewRequired:false};
  fs.mkdirSync(path.join(ROOT,'reports'),{recursive:true});
  fs.writeFileSync(path.join(ROOT,'reports/PASS_01_HTML_BUILD.json'),JSON.stringify(report,null,2)+'\n');
  return report;
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) console.log(JSON.stringify(buildPreview(),null,2));
