import { createProgress } from './progress.js';
import { mountPractice } from './practice.js';
import { scheduler } from './scheduler.js';
import { mountReports } from './reports.js';

const el = (tag, className = '', text) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
};
const zh = (text, className = 'zh') => {
  const node = el('span', className, text);
  node.lang = 'zh-Hans';
  return node;
};
const button = (text, action, className = 'secondary-button') => {
  const node = el('button', className, text);
  node.type = 'button';
  node.addEventListener('click', action);
  return node;
};
const norm = value => String(value || '').toLowerCase().normalize('NFD')
  .replace(/u\u0308/g, 'v').replace(/[\u0300-\u036f]/g, '')
  .replace(/ü/g, 'v').replace(/u:/g, 'v').replace(/[\s1-5]/g, '');
const reading = word => (word?.readings || []).map(item => item.pinyin).filter(Boolean).join(' / ');
const gloss = sense => sense.gloss || sense.gloss_es || (sense.glosses || []).join('; ');
const partOfSpeech = value => ({ verb: 'Verbo', noun: 'Sustantivo', adjective: 'Adjetivo',
  adverb: 'Adverbio', pronoun: 'Pronombre', particle: 'Partícula', interjection: 'Interjección',
  phrase: 'Expresión', conjunction: 'Conjunción', numeral: 'Numeral' }[value] || value || 'Categoría pendiente');
const textValue = value => typeof value === 'string' ? value : Array.isArray(value)
  ? value.map(textValue).filter(Boolean).join(' · ') : value && typeof value === 'object'
    ? value.note || value.description || value.zh || '' : '';

const content = document.querySelector('#content');
const announcer = document.querySelector('#announcer');
const progress = createProgress();
let bootstrap;
let view = 'learn';
let selectedUnit = null;
let selectedLesson = null;
let selectedOriginalLesson = null;
let selectedWord = null;
let selectedContrast = null;
let cleanupPractice = null;
let wordIndex = [];
let currentSession = null;
let reports = null;
let showHsk = false;
const ownerPolicy = () => bootstrap?.editorial?.reviewPolicy === 'owner_reports';

function page(title, description, symbol) {
  const fragment = document.createDocumentFragment();
  const intro = el('header', 'page-intro');
  const copy = el('div');
  const heading = el('h1', '', title);
  heading.tabIndex = -1;
  copy.append(heading, el('p', '', description));
  intro.append(copy, zh(symbol, 'page-icon'));
  fragment.append(intro);
  if (bootstrap.mode === 'private' && !ownerPolicy()) {
    const note = el('div', 'draft-note');
    note.append(el('span', 'draft-dot'), el('span', '', 'Prueba privada · Los textos y actividades están pendientes de revisión de chino.'));
    fragment.append(note);
  }
  return fragment;
}

function finishPage(fragment) {
  content.replaceChildren(fragment);
  content.classList.remove('view-enter');
  void content.offsetWidth;
  content.classList.add('view-enter');
}

function showView(next, { updateHash = true, focus = false } = {}) {
  if (!bootstrap || !['learn', 'dictionary', 'compare', 'review'].includes(next)) return;
  cleanupPractice?.(); cleanupPractice = null;
  document.body.classList.remove('practice-mode');
  currentSession = null;
  view = next;
  document.querySelectorAll('[data-view]').forEach(link => {
    if (link.dataset.view === next) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
  ({ learn: renderLearn, dictionary: renderDictionary, compare: renderCompare, review: renderReview })[next]();
  if (updateHash) history.replaceState(null, '', `#${next}`);
  if (focus) content.querySelector('h1')?.focus({ preventScroll: true });
  document.title = `HanYuMatiz · ${ { learn: 'Aprender', dictionary: 'Diccionario', compare: 'Comparar', review: 'Repasar' }[next] }`;
}

function renderLearn() {
  const originalLessons = (bootstrap.lessons || []).filter(lesson => lesson.status === 'published'
    && lesson.exerciseIds?.some(id => bootstrap.exercises.some(exercise => exercise.id === id)));
  const fragment = page('Tus lecciones', originalLessons.length
    ? 'Practica con situaciones de la vida diaria.'
    : 'Trabaja las palabras en contexto y entiende qué cambia al usarlas.', '学');
  if (originalLessons.length) {
    renderOriginalLessons(fragment, originalLessons);
    const hskSection = el('section', 'hsk-explorer');
    const toggle = button(showHsk ? 'Ocultar niveles HSK' : 'Ver niveles HSK 1–6', () => {
      showHsk = !showHsk; renderLearn(); content.querySelector('#hskToggle')?.focus({ preventScroll: true });
    }, 'text-button');
    toggle.id = 'hskToggle'; toggle.setAttribute('aria-expanded', String(showHsk));
    toggle.setAttribute('aria-controls', 'hskContent'); hskSection.append(toggle);
    fragment.append(hskSection);
    if (!showHsk) { finishPage(fragment); return; }
    hskSection.append(el('p', 'small-meta', 'Estas lecciones todavía no tienen un nivel HSK asignado.'));
    const hskContent = el('section'); hskContent.id = 'hskContent'; fragment.append(hskContent);
    renderHsk(hskContent); finishPage(fragment); return;
  }
  renderHsk(fragment); finishPage(fragment);
}

function renderOriginalLessons(fragment, lessons) {
  const state = progress.getState(bootstrap.dataVersion);
  const completed = lessons.filter(lesson => state.completedLessons[lesson.id]);
  if (!lessons.some(lesson => lesson.id === selectedOriginalLesson)) {
    selectedOriginalLesson = lessons.find(lesson => !state.completedLessons[lesson.id])?.id || lessons[0].id;
  }
  const course = el('section', 'lesson-course'); course.setAttribute('aria-label', 'Lecciones de chino');
  const chooser = el('div', 'lesson-chooser');
  const chooserMeta = el('div', 'lesson-chooser-meta');
  const chooserLabel = el('label', '', 'Elegir una lección'); chooserLabel.htmlFor = 'originalLessonSelect';
  const label = el('span', '', `${completed.length} de ${lessons.length} completadas`); label.id = 'lessonProgress';
  chooserMeta.append(chooserLabel, label);
  const select = el('select', 'lesson-select'); select.id = 'originalLessonSelect';
  lessons.forEach((lesson, index) => {
    const option = el('option', '', `${String(index + 1).padStart(2, '0')} · ${lesson.title}${state.completedLessons[lesson.id] ? ' · Completada' : ''}`);
    option.value = lesson.id; option.dataset.originalLesson = lesson.id;
    option.selected = lesson.id === selectedOriginalLesson; select.append(option);
  });
  select.addEventListener('change', () => {
    selectedOriginalLesson = select.value; renderLearn();
    content.querySelector('#originalLessonSelect')?.focus({ preventScroll: true });
    announcer.textContent = `Lección seleccionada: ${lessons.find(lesson => lesson.id === selectedOriginalLesson)?.title}.`;
  });
  chooser.append(chooserMeta, select); course.append(chooser);
  const lesson = lessons.find(item => item.id === selectedOriginalLesson);
  const exercises = lesson.exerciseIds.map(id => bootstrap.exercises.find(exercise => exercise.id === id)).filter(Boolean);
  const pending = Object.values(state.sessions).find(session => session.lessonId === lesson.id && !session.ended
    && session.exerciseIds.length === exercises.length && session.exerciseIds.every(id => lesson.exerciseIds.includes(id)));
  const detail = el('div', 'lesson-preview');
  detail.append(el('p', 'lesson-position', `Lección ${lessons.indexOf(lesson) + 1} · ${exercises.length} ejercicios`));
  const title = el('h2', '', lesson.title); title.id = 'originalLessonTitle'; title.tabIndex = -1;
  detail.append(title, el('p', 'lesson-summary', lesson.description || lesson.objective));
  const actions = el('div', 'lesson-start');
  const start = button(pending ? 'Continuar lección' : state.completedLessons[lesson.id] ? 'Practicar de nuevo' : 'Empezar lección',
    () => startPractice(exercises, lesson.id, pending?.id), 'primary-button');
  start.dataset.start = 'lesson'; start.dataset.lessonId = lesson.id; actions.append(start);
  if (pending) actions.append(el('p', 'lesson-resume', `${Object.keys(state.answers[pending.id] || {}).length} de ${exercises.length} respuestas guardadas`));
  detail.append(actions);
  const notes = el('details', 'lesson-notes'); notes.id = 'lessonNotes';
  notes.append(el('summary', '', 'Ver las palabras y la diferencia'));
  const notesContent = el('div', 'lesson-notes-content');
  const words = (lesson.wordIds || []).map(id => bootstrap.words.find(word => word.id === id)).filter(Boolean);
  const terms = el('div', 'lesson-word-links'); terms.setAttribute('aria-label', 'Consultar las palabras de esta lección');
  for (const word of words) {
    const term = button('', () => { selectedWord = word.id; showView('dictionary', { focus: true }); }, 'lesson-word-link');
    term.append(zh(word.zh), el('span', 'pinyin', reading(word))); terms.append(term);
  }
  notesContent.append(terms);
  const contrasts = (lesson.contrastIds || []).map(id => bootstrap.contrasts.find(pair => pair.id === id)).filter(Boolean);
  for (const contrast of contrasts) {
    const explanation = el('section', 'lesson-explanation');
    const heading = el('h3'); heading.append(zh(contrast.a), document.createTextNode(' / '), zh(contrast.b)); explanation.append(heading);
    if (contrast.explanation) explanation.append(el('p', 'contrast-explanation', contrast.explanation));
    explanation.append(button('Ver ejemplos', () => {
      selectedContrast = contrast.id; showView('compare', { focus: true });
    }, 'text-button'));
    notesContent.append(explanation);
  }
  if (!contrasts.length) {
    for (const word of words) {
      const usage = word.usage || word.usage_note || word.senses?.[0]?.usage;
      if (usage) { const line = el('p', 'lesson-usage'); line.append(zh(word.zh), document.createTextNode(` · ${typeof usage === 'string' ? usage : usage.note || ''}`)); notesContent.append(line); }
    }
  }
  notes.append(notesContent); detail.append(notes); course.append(detail); fragment.append(course);
}

function renderHsk(fragment) {
  const levelNumber = progress.getState().selectedLevel;
  const selector = el('div', 'level-selector');
  selector.setAttribute('role', 'group');
  selector.setAttribute('aria-label', 'Elegir nivel HSK directamente');
  for (const level of bootstrap.levels) {
    const control = button(`HSK ${level.id}`, () => {
      progress.selectLevel(Number(level.id));
      selectedUnit = null; selectedLesson = null;
      renderLearn();
      content.querySelector(`[data-level="${level.id}"]`)?.focus({ preventScroll: true });
      announcer.textContent = `HSK ${level.id} seleccionado. Contenido pendiente de validación.`;
    }, 'level-button');
    control.dataset.level = String(level.id);
    control.setAttribute('aria-pressed', String(Number(level.id) === levelNumber));
    selector.append(control);
  }
  fragment.append(selector);
  const level = bootstrap.levels.find(item => Number(item.id) === levelNumber);
  const units = level?.units || [];
  const lessons = units.flatMap(unit => unit.lessons || []);
  const available = lessons.filter(lesson => lesson.status === 'approved' && lesson.exerciseIds?.length);
  const completed = available.filter(lesson => progress.getState(bootstrap.dataVersion).completedLessons[lesson.id]);
  const overview = el('div', 'level-overview');
  const title = el('div');
  title.append(el('h2', '', `HSK ${levelNumber}`), el('p', '', 'Unidades y lecciones · Clasificación pendiente'));
  overview.append(title, el('span', 'count-pill', available.length ?
    `${completed.length} de ${available.length} lecciones disponibles completadas` : 'Lecciones en preparación'));
  fragment.append(overview);
  if (!units.length) {
    fragment.append(empty('Estamos preparando este nivel.', 'Todavía no hay unidades con contenido revisado. Puedes cambiar de nivel directamente arriba.'));
  } else {
    if (!units.some(unit => unit.id === selectedUnit)) { selectedUnit = units[0].id; selectedLesson = null; }
    const unit = units.find(item => item.id === selectedUnit);
    const layout = el('section', 'course-layout');
    layout.setAttribute('aria-label', `Unidades de HSK ${levelNumber}`);
    const list = el('div', 'unit-list');
    units.forEach((item, index) => {
      const row = button('', () => { selectedUnit = item.id; selectedLesson = null; renderLearn();
        content.querySelector('#unitTitle')?.focus({ preventScroll: true }); }, 'unit-row');
      row.dataset.unit = item.id;
      row.setAttribute('aria-pressed', String(item.id === selectedUnit));
      if (item.id === selectedUnit) row.classList.add('selected');
      const copy = el('div');
      copy.append(el('strong', '', item.title), el('small', '', `${item.lessons.length} lecciones · Preparación`));
      row.append(el('span', 'unit-index', String(index + 1).padStart(2, '0')), copy);
      list.append(row);
    });
    const panel = el('div', 'unit-panel');
    const unitTitle = el('h3', '', unit.title); unitTitle.id = 'unitTitle'; unitTitle.tabIndex = -1;
    panel.append(unitTitle, el('p', '', 'Estructura de trabajo. Estas lecciones aún no forman un currículo HSK validado.'));
    const lessonList = el('div', 'lesson-list');
    for (const lesson of unit.lessons) {
      const row = button('', () => { selectedLesson = lesson.id; renderLearn();
        content.querySelector('#lessonTitle')?.focus({ preventScroll: true }); }, 'lesson-row');
      row.dataset.lesson = lesson.id;
      row.setAttribute('aria-expanded', String(selectedLesson === lesson.id));
      if (selectedLesson === lesson.id) row.classList.add('selected');
      const copy = el('div');
      copy.append(el('strong', '', lesson.title), el('small', '', lesson.status === 'approved' ? 'Disponible' : 'Contenido pendiente de revisión'));
      row.append(copy, el('span', 'lesson-arrow', '›'));
      lessonList.append(row);
    }
    panel.append(lessonList);
    const lesson = unit.lessons.find(item => item.id === selectedLesson);
    if (lesson) {
      const detail = el('section', 'pending-detail');
      const lessonTitle = el('h3', '', lesson.title); lessonTitle.id = 'lessonTitle'; lessonTitle.tabIndex = -1;
      detail.append(lessonTitle);
      const exercises = bootstrap.exercises.filter(item => lesson.exerciseIds?.includes(item.id));
      if (lesson.status === 'approved' && exercises.length) {
        detail.append(button('Empezar lección', () => startPractice(exercises, lesson.id), 'primary-button'));
      } else {
        detail.append(el('p', '', ownerPolicy()
          ? 'Este apartado aún no tiene una lección con contenido HSK clasificado. Puedes trabajar las lecciones originales disponibles arriba.'
          : 'Se habilitará cuando el vocabulario, los ejemplos y los ejercicios tengan revisión lingüística y derechos documentados.'));
        const disabled = button('Lección en preparación', () => {}, 'primary-button'); disabled.disabled = true;
        detail.append(disabled);
      }
      panel.append(detail);
    }
    layout.append(list, panel); fragment.append(layout);
  }
  if (bootstrap.mode === 'private' && bootstrap.fixtures.length) {
    const lab = el('section', 'practice-invitation');
    const copy = el('div'); copy.append(el('h3', '', 'El laboratorio de matices'),
      el('p', '', 'Prueba la experiencia con tres situaciones: escoger un regalo, expresar una suposición y dar una impresión. Sin nivel HSK asignado.'));
    const start = button('Probar las 3 situaciones →', () => startPractice(bootstrap.fixtures, 'lab_v9'), 'primary-button');
    start.dataset.start = 'fixtures'; lab.append(copy, start); fragment.append(lab);
    const bank = button('Explorar ejercicios del banco auditado', () => startBank(), 'text-button'); bank.dataset.start = 'bank';
    const all = button('Inspeccionar las 30 actividades', () => startPractice(bootstrap.exercises, null), 'text-button');
    all.dataset.start = 'bank-all';
    const actions = el('div', 'button-row'); actions.append(bank, all); fragment.append(actions);
  }
  fragment.append(el('p', 'small-meta', `Referencia: ${bootstrap.standard?.id || 'Pendiente'}. No se ha importado una lista oficial ni asignado un nivel sin evidencia.`));
}

function empty(title, description) {
  const node = el('div', 'empty-state');
  node.append(el('strong', '', title), el('span', '', description));
  return node;
}

function renderDictionary() {
  const fragment = page('Diccionario', 'Busca por caracteres, pinyin o significado. Abre una palabra para consultar sus acepciones y ejemplos.', '词');
  const label = el('label', 'search-field');
  const input = el('input'); input.id = 'search'; input.type = 'search'; input.autocomplete = 'off'; input.spellcheck = false;
  input.placeholder = 'Por ejemplo: 觉得, juéde o impresión';
  label.append(el('span', '', 'Buscar una palabra'), input); fragment.append(label);
  const layout = el('div', 'tools-grid');
  const left = el('section');
  const summary = el('div', 'results-summary'); summary.setAttribute('role', 'status');
  const results = el('div', 'result-list'); results.id = 'wordResults';
  results.setAttribute('aria-label', 'Palabras encontradas');
  const detail = el('section', 'detail-panel'); detail.id = 'wordDetail'; detail.setAttribute('aria-label', 'Ficha de la palabra');
  left.append(summary, results); layout.append(left, detail); fragment.append(layout); finishPage(fragment);
  function updateResults() {
    const query = norm(input.value);
    const matches = wordIndex.filter(item => !query || item.terms.some(term => term.includes(query)));
    summary.textContent = `${matches.length} de ${wordIndex.length} palabras${bootstrap.mode === 'private' && !ownerPolicy() ? ' · Borradores' : ''}`;
    results.replaceChildren();
    if (!matches.length) {
      results.append(empty('No hay resultados.', bootstrap.words.length ? 'Prueba otra palabra, su pinyin o una traducción.' : 'Aún no hay entradas aprobadas para la versión pública.'));
      detail.replaceChildren(empty('Cada palabra tiene su ficha.', 'Busca una entrada para ver acepciones, ejemplos y palabras relacionadas.'));
      return;
    }
    if (!matches.some(item => item.word.id === selectedWord)) selectedWord = matches[0].word.id;
    for (const { word } of matches) {
      const row = button('', () => { selectedWord = word.id; updateResults();
        detail.querySelector('h2')?.focus({ preventScroll: true }); }, 'word-result');
      row.dataset.word = word.id;
      row.setAttribute('aria-pressed', String(word.id === selectedWord));
      if (word.id === selectedWord) row.classList.add('selected');
      const copy = el('div'); copy.append(zh(word.zh), el('small', '', gloss(word.senses?.[0] || {})));
      row.append(copy, el('span', 'pinyin', reading(word))); results.append(row);
    }
    renderWordDetail(detail, bootstrap.words.find(word => word.id === selectedWord));
  }
  input.addEventListener('input', updateResults); updateResults();
}

function renderWordDetail(panel, word) {
  panel.replaceChildren();
  if (!word) return;
  const heading = el('div', 'word-heading');
  const title = el('h2', 'zh', word.zh); title.lang = 'zh-Hans'; title.tabIndex = -1;
  heading.append(title, el('span', 'status-label', ownerPolicy() ? 'Edición original' : bootstrap.mode === 'private' ? 'Borrador' : 'Revisado'));
  panel.append(heading, el('p', 'word-pinyin', reading(word)));
  for (const [index, sense] of (word.senses || []).entries()) {
    const row = el('div', 'sense-row');
    const copy = el('div'); copy.append(el('div', 'sense-pos', partOfSpeech(sense.pos)), el('p', '', gloss(sense)));
    const pronId = sense.pronunciation_id;
    if ((word.readings || []).length > 1 && pronId) {
      const pronunciation = word.readings.find(item => item.id === pronId);
      if (pronunciation) copy.append(el('small', 'small-meta', `Lectura de esta acepción: ${pronunciation.pinyin}`));
    }
    row.append(el('span', 'sense-number', String(index + 1).padStart(2, '0')), copy); panel.append(row);
    if (sense.usage) copy.append(el('p', 'usage-note', textValue(sense.usage)));
  }
  if (word.usage || word.usage_note) {
    const section = el('section', 'detail-section'); section.append(el('h3', '', 'Cómo se usa'),
      el('p', 'usage-note', textValue(word.usage || word.usage_note))); panel.append(section);
  }
  if (word.register) panel.append(el('p', 'register-note', `Registro: ${textValue(word.register)}`));
  if (word.collocations?.length) {
    const section = el('section', 'detail-section'); section.append(el('h3', '', 'Combinaciones habituales'));
    const list = el('div', 'collocation-list');
    for (const collocation of word.collocations) {
      const item = el('div', 'collocation'); item.append(zh(typeof collocation === 'string' ? collocation : collocation.zh || collocation.phrase || ''));
      if (typeof collocation === 'object' && (collocation.translation || collocation.translation_es)) item.append(el('span', '', collocation.translation_es || collocation.translation));
      list.append(item);
    }
    section.append(list); panel.append(section);
  }
  const senseIds = (word.senses || []).map(sense => sense.id);
  const examples = (bootstrap.examples || []).filter(example => senseIds.includes(example.target_sense_id) || example.lexeme_id === word.id);
  examples.push(...(word.examples || []));
  const section = el('section', 'detail-section'); section.append(el('h3', '', 'Ejemplos en contexto'));
  if (!examples.length) section.append(el('p', 'small-meta', 'Todavía no hay ejemplos vinculados a esta entrada.'));
  const uniqueExamples = [...new Map(examples.map(example => [example.id || example.sentence_zh || example.zh, example])).values()];
  for (const example of uniqueExamples) {
    const row = el('div', 'example-line'); row.append(zh(example.sentence_zh || example.zh), el('p', '', example.translation_es || example.translation));
    if (example.pinyin || example.sentence_pinyin) row.insertBefore(el('p', 'example-pinyin', example.pinyin || example.sentence_pinyin), row.lastElementChild);
    if (example.note || example.context) row.append(el('p', 'example-note', example.note || example.context));
    section.append(row);
  }
  panel.append(section);
  const contrasts = bootstrap.contrasts.filter(pair => pair.word_id_a === word.id || pair.word_id_b === word.id);
  if (contrasts.length) {
    const relations = el('section', 'detail-section'); relations.append(el('h3', '', 'Palabras para comparar'));
    for (const contrast of contrasts) {
      relations.append(button(`${contrast.a} / ${contrast.b} · ${contrast.topic}`, () => {
        selectedContrast = contrast.id; showView('compare', { focus: true });
      }, 'relation-link'));
    }
    panel.append(relations);
  }
  const traditional = word.hanzi_traditional || word.traditional || word.model?.hanzi_traditional;
  panel.append(el('p', 'field-status', `Tradicional: ${traditional || 'sin verificar'} · HSK: ${word.hsk_level || 'sin clasificar'}`));
  if (bootstrap.mode === 'private' && !ownerPolicy()) panel.append(el('p', 'small-meta', `ID: ${word.id}. Pronunciación, acepciones y ejemplos pendientes de aprobación. Los campos ausentes no se han completado automáticamente.`));
  panel.append(reports.button({ targetType: 'word', targetId: word.id, title: `${word.zh} · ${reading(word)}`,
    preview: (word.senses || []).map(gloss).join('; ') }));
}

function renderCompare() {
  const fragment = page('Comparar palabras', 'Empieza por lo que quieres expresar. Cambia una palabra y observa cómo cambia la intención.', '辨');
  if (!bootstrap.contrasts.length) {
    fragment.append(empty('Las primeras comparaciones están en preparación.', 'Aquí aparecerán las diferencias de uso con sus situaciones y ejemplos.'));
    finishPage(fragment); return;
  }
  const layout = el('div', 'tools-grid');
  const list = el('section', 'result-list'); list.setAttribute('aria-label', 'Comparaciones disponibles');
  const detail = el('section', 'detail-panel'); detail.id = 'contrastDetail';
  if (!bootstrap.contrasts.some(item => item.id === selectedContrast)) selectedContrast = bootstrap.contrasts[0].id;
  for (const contrast of bootstrap.contrasts) {
    const row = button('', () => { selectedContrast = contrast.id; renderCompare();
      content.querySelector('#contrastTitle')?.focus({ preventScroll: true }); }, 'contrast-result');
    row.dataset.contrast = contrast.id; row.setAttribute('aria-pressed', String(contrast.id === selectedContrast));
    if (contrast.id === selectedContrast) row.classList.add('selected');
    const copy = el('div'); copy.append(zh(`${contrast.a} / ${contrast.b}`), el('small', '', contrast.topic));
    row.append(copy, el('span', 'lesson-arrow', '›')); list.append(row);
  }
  const contrast = bootstrap.contrasts.find(item => item.id === selectedContrast);
  const title = el('h2', 'contrast-heading'); title.id = 'contrastTitle'; title.tabIndex = -1;
  title.append(zh(contrast.a), el('span', 'divider', '/'), zh(contrast.b));
  detail.append(title, el('p', 'small-meta', contrast.topic));
  if (contrast.explanation) detail.append(el('p', 'contrast-explanation', contrast.explanation));
  const points = el('div', 'comparison-points');
  for (const key of ['a', 'b']) {
    const column = el('div'); column.append(el('h3', 'zh', contrast[key]), el('p', '', contrast[`sense_${key}`]),
      el('p', '', partOfSpeech(contrast[`pos_${key}`]))); points.append(column);
  }
  detail.append(points);
  const scenarios = bootstrap.scenarios.filter(item => item.contrast_id === contrast.id);
  if (scenarios.length) {
    const label = el('label', 'context-label', 'Elige una situación'); label.htmlFor = 'scenarioSelect';
    const select = el('select', 'scenario-select'); select.id = 'scenarioSelect';
    for (const scenario of scenarios) { const option = el('option', '', scenario.label); option.value = scenario.id; select.append(option); }
    const box = el('section', 'context-box');
    detail.append(label, select, box);
    function showContext() {
      const scenario = scenarios.find(item => item.id === select.value);
      box.replaceChildren();
      box.append(el('p', '', scenario.intent));
      const controls = el('div', 'variant-controls');
      const sentence = el('p', 'zh'); sentence.id = 'contextSentence'; sentence.lang = 'zh-Hans';
      const fit = el('p', 'fit-label'); fit.id = 'contextFit';
      const note = el('p'); note.id = 'contextNote'; note.setAttribute('aria-live', 'polite');
      const buttons = [];
      function change(key) {
        const [before, after] = scenario.sentence.split('〔词〕');
        sentence.replaceChildren(document.createTextNode(before), el('strong', 'context-target', scenario[key]), document.createTextNode(after || ''));
        fit.textContent = { preferred_in_context: 'Expresa mejor esta intención', possible_with_nuance: 'La frase funciona; el matiz cambia', requires_reformulation: 'Necesita cambiar la estructura' }[scenario[`fit_${key}`]] || 'Encaje pendiente de revisión';
        note.textContent = scenario[`note_${key}`];
        for (const control of buttons) control.setAttribute('aria-pressed', String(control.dataset.variant === key));
      }
      for (const key of ['a', 'b']) {
        const control = button(scenario[key], () => change(key), 'variant-button');
        control.dataset.variant = key; control.lang = 'zh-Hans'; buttons.push(control); controls.append(control);
      }
      box.append(controls, sentence, fit, note, el('p', 'context-translation', `${scenario.translation} · Traducción general del escenario`));
      if (scenario.comparison) box.append(el('p', 'context-comparison', scenario.comparison));
      change('a');
    }
    select.addEventListener('change', showContext); showContext();
    const exercises = bootstrap.exercises.filter(item => scenarios.some(scenario => scenario.id === item.scenario_id));
    if (exercises.length) detail.append(button('Practicar esta diferencia', () => startPractice(exercises, `lab_${contrast.id}`), 'primary-button'));
  } else detail.append(el('p', 'small-meta', 'Situaciones contrastivas pendientes. No se han generado ejemplos automáticamente.'));
  const cautions = contrast.cautions || [];
  if (cautions.length) detail.append(el('p', 'comparison-warning', cautions.join(' ')));
  if (bootstrap.mode === 'private' && !ownerPolicy()) detail.append(el('p', 'small-meta', 'Propuesta editorial: intención, gramática, naturalidad, restricciones y ejemplos pendientes de revisión.'));
  detail.append(reports.button({ targetType: 'contrast', targetId: contrast.id,
    title: `${contrast.a} / ${contrast.b} · ${contrast.topic}`,
    preview: `${contrast.a}: ${contrast.sense_a || ''} ${contrast.b}: ${contrast.sense_b || ''}` }));
  layout.append(list, detail); fragment.append(layout); finishPage(fragment);
}

function startPractice(exercises, lessonId = null, sessionId = null) {
  if (!exercises.length) return;
  const originalLesson = bootstrap.lessons.find(lesson => lesson.id === lessonId);
  const returnView = view === 'review' ? 'review' : originalLesson ? 'learn' : 'review';
  if (originalLesson) selectedOriginalLesson = lessonId;
  cleanupPractice?.(); cleanupPractice = null;
  const id = sessionId || `s_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  view = 'practice'; currentSession = id;
  document.body.classList.add('practice-mode');
  window.scrollTo({ top: 0, behavior: 'instant' });
  history.replaceState(null, '', `#practice/${id}`);
  document.title = 'HanYuMatiz · Práctica de matices';
  cleanupPractice = mountPractice(content, { exercises, bootstrap, progress, lessonId, sessionId: id,
    createReportButton: question => reports.button({ targetType: 'exercise', targetId: question.id,
      title: question.title, preview: `${question.context} ${question.sentence.replace('〔词〕', '____')} ${question.explanation}` }),
    onExit: () => showView(returnView, { focus: true }),
    onComplete: () => { announcer.textContent = 'Práctica terminada. Tus respuestas se han guardado en este navegador.'; },
  });
}

function startBank() {
  const ids = new Set(bootstrap.exercises.map(exercise => exercise.scenario_id));
  const history = Object.fromEntries(Object.entries(progress.getState(bootstrap.dataVersion).reviews).filter(([id]) => ids.has(id)));
  const plan = scheduler.schedule(bootstrap.exercises, history, scheduler.isoToday(), { limit: 8, early: true });
  const byId = new Map(bootstrap.exercises.map(exercise => [exercise.id, exercise]));
  const exercises = plan.exercises.map(item => byId.get(item.exercise_id)).filter(Boolean);
  startPractice(exercises, 'lab_bank');
}

function renderReview() {
  const fragment = page('Tu repaso', 'Vuelve a las intenciones que necesitan práctica. El progreso se conserva en este navegador.', '习');
  const state = progress.getState(bootstrap.dataVersion);
  const answers = Object.values(state.answers).flatMap(session => Object.values(session));
  const due = Object.entries(state.reviews).filter(([, entry]) => entry.due_day <= scheduler.isoToday());
  const counts = el('div', 'review-counts');
  const completedLessons = (bootstrap.lessons || []).filter(lesson => state.completedLessons[lesson.id]).length;
  for (const [value, label] of [[answers.length, 'Respuestas guardadas'], [bootstrap.lessons.length ? completedLessons : Object.keys(state.completedLessons).length, bootstrap.lessons.length ? 'Lecciones completadas' : 'Prácticas completadas'], [due.length, 'Intenciones para repasar']]) {
    const item = el('div'); item.append(el('strong', '', String(value)), el('span', '', label)); counts.append(item);
  }
  fragment.append(counts);
  const pending = Object.values(state.sessions).filter(session => !session.ended && session.exerciseIds.some(id => !state.answers[session.id]?.[id]));
  const all = new Map([...bootstrap.fixtures, ...bootstrap.exercises].map(exercise => [exercise.id, exercise]));
  if (pending.length) {
    fragment.append(el('h2', '', 'Continúa donde lo dejaste'));
    const list = el('div', 'review-list');
    for (const session of pending) {
      const exercises = session.exerciseIds.map(id => all.get(id)).filter(Boolean);
      if (exercises.length !== session.exerciseIds.length) continue;
      const row = el('div', 'review-row');
      const copy = el('div'); copy.append(el('strong', '', sessionName(session)),
        el('small', '', `${Object.keys(state.answers[session.id] || {}).length} de ${session.exerciseIds.length} preguntas respondidas`));
      row.append(copy, button('Continuar', () => startPractice(exercises, session.lessonId, session.id)));
      list.append(row);
    }
    fragment.append(list);
  } else fragment.append(empty('Tu siguiente práctica empieza aquí.', 'Después de responder, las intenciones trabajadas aparecerán en el repaso. Completar una actividad no acredita dominio del idioma.'));
  if (bootstrap.exercises.length) {
    const actions = el('div', 'button-row');
    const dueIds = new Set(due.map(([id]) => id));
    const fixtureDescriptors = bootstrap.fixtures.map(fixture => ({ id: fixture.id, scenario_id: fixture.scenario_id,
      kind: 'choice_preference', difficulty: 'intermedio', word_a: fixture.choices[0].zh, word_b: fixture.choices[1].zh }));
    const plan = scheduler.schedule([...bootstrap.exercises, ...fixtureDescriptors], state.reviews, scheduler.isoToday(), { limit: 8 });
    const exercises = plan.exercises.filter(item => dueIds.has(item.scenario_id)).map(item => all.get(item.exercise_id)).filter(Boolean);
    if (exercises.length) actions.append(button('Repasar estas intenciones', () => startPractice(exercises, null), 'primary-button'));
    const bank = button('Practicar otras situaciones', startBank); bank.dataset.start = 'bank'; actions.append(bank); fragment.append(actions);
  }
  const finished = Object.values(state.sessions).filter(session => session.ended).slice(-3).reverse();
  if (finished.length) {
    const completed = el('section', 'completed-practices'); completed.append(el('h2', '', 'Prácticas terminadas'));
    for (const session of finished) {
      const exercises = session.exerciseIds.map(id => all.get(id)).filter(Boolean);
      if (exercises.length !== session.exerciseIds.length) continue;
      const row = el('div', 'review-row'); const copy = el('div');
      copy.append(el('strong', '', sessionName(session)),
        el('small', '', `${session.exerciseIds.length} respuestas guardadas · Vuelve a sus explicaciones`));
      row.append(copy, button('Ver respuestas', () => startPractice(exercises, session.lessonId, session.id)));
      completed.append(row);
    }
    fragment.append(completed);
  }
  const privacy = el('section', 'privacy-note');
  privacy.append(el('p', '', progress.persistent ? 'Guardado local activo. Sin cuentas ni seguimiento externo. El repaso usa intervalos de práctica; todavía no es un sistema de dominio validado.' : 'Este navegador no permite guardar el progreso. Puedes seguir practicando durante esta sesión.'));
  const clear = button('Borrar mi progreso de este navegador', () => {
    if (window.confirm('Se borrarán tus respuestas, sesiones y repasos guardados en este navegador.')) {
      progress.clear(); renderReview(); announcer.textContent = 'Progreso borrado.';
    }
  }, 'text-button'); privacy.append(clear); fragment.append(privacy); finishPage(fragment);
}

function route() {
  const hash = location.hash.slice(1);
  if (hash.startsWith('practice/')) {
    const session = progress.getSession(hash.slice(9));
    if (session) {
      const all = new Map([...bootstrap.fixtures, ...bootstrap.exercises].map(exercise => [exercise.id, exercise]));
      const exercises = session.exerciseIds.map(id => all.get(id)).filter(Boolean);
      if (exercises.length === session.exerciseIds.length) { startPractice(exercises, session.lessonId, session.id); return; }
    }
  }
  showView(['learn', 'dictionary', 'compare', 'review'].includes(hash) ? hash : 'learn');
}

function sessionName(session) {
  return bootstrap.lessons.find(lesson => lesson.id === session.lessonId)?.title
    || (session.lessonId === 'lab_v9' ? 'Tres situaciones, tres matices' : 'Práctica de matices');
}

document.querySelectorAll('[data-view]').forEach(link => link.addEventListener('click', event => {
  event.preventDefault(); if (bootstrap) showView(link.dataset.view, { focus: true });
}));
document.querySelector('.brand').addEventListener('click', event => { event.preventDefault(); if (bootstrap) showView('learn', { focus: true }); });
window.addEventListener('hashchange', () => { if (bootstrap) route(); });
const about = document.querySelector('#about');
document.querySelector('#aboutButton').addEventListener('click', () => about.showModal());
document.querySelector('#closeAbout').addEventListener('click', () => about.close());

try {
  const response = await fetch('/api/bootstrap', { credentials: 'same-origin', cache: 'no-store' });
  if (!response.ok) throw new Error('No se pudo cargar el banco autorizado.');
  bootstrap = await response.json();
  bootstrap.fixtures ||= []; bootstrap.examples ||= []; bootstrap.relations ||= []; bootstrap.lessons ||= [];
  bootstrap.words ||= []; bootstrap.contrasts ||= []; bootstrap.scenarios ||= []; bootstrap.exercises ||= []; bootstrap.levels ||= [];
  reports = mountReports({ bootstrap });
  wordIndex = bootstrap.words.map(word => ({ word, terms: [word.zh, word.hanzi_traditional,
    ...(word.readings || []).map(item => item.pinyin), ...(word.senses || []).map(gloss)].filter(Boolean).map(norm) }));
  document.querySelector('#environment').textContent = bootstrap.delivery === 'standalone' ? 'Vista local' : bootstrap.mode === 'private' ? 'Edición de prueba' : 'Versión pública';
  document.querySelector('#aboutStatus').textContent = ownerPolicy()
    ? 'Las nuevas lecciones y ejemplos son originales, preparados para enseñar diferencias de uso. La revisión externa es opcional. Puedes reportar un error de matiz; el propietario evalúa los comentarios en privado y corrige el contenido.' : bootstrap.mode === 'private' ?
    'Este entorno tiene acceso restringido. El banco conserva los expedientes auditados P1–P12; los borradores siguen pendientes de revisión humana.' :
    'Esta versión muestra únicamente contenido habilitado por los controles editoriales. Las lecciones pendientes no están disponibles todavía.';
  route();
} catch (error) {
  content.replaceChildren(empty('No pudimos abrir HanYuMatiz.', 'Comprueba que has iniciado el servidor y que tu acceso al entorno privado está autorizado.'));
  document.querySelector('#environment').textContent = 'Sin conexión con el servidor';
}

Object.defineProperty(window, 'HanYuPlatform', { value: Object.freeze({ inspect: () => ({
  view, selectedLevel: progress.getState().selectedLevel, selectedUnit, selectedLesson, selectedOriginalLesson,
  progress: progress.getState(), mode: bootstrap?.mode, sessionId: currentSession,
}) }) });
