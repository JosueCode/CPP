/** Normalize existing editorial exercises without changing their answer keys.
 * A mismatch is about the requested intention, not a blanket grammar verdict.
 */
export const EXERCISE_KINDS = Object.freeze([
  'choice_preference', 'choice_structure', 'both_acceptable', 'recognize_validity',
]);

const text = value => typeof value === 'string' ? value : '';
const plain = value => text(value).replace(/<[^>]*>/g, '').trim();
const list = value => Array.isArray(value) ? value : [];

function readingFor(word, words) {
  const entry = words.find(item => item.zh === word || item.simplified === word);
  return text(entry?.readings?.[0]?.pinyin || entry?.pinyin);
}

function tokens(value) {
  if (!Array.isArray(value)) return undefined;
  return value.filter(item => Array.isArray(item) && typeof item[0] === 'string')
    .map(item => [item[0], text(item[1])]);
}

export function normalizeExercise(raw, bootstrap = {}) {
  if (!raw || typeof raw !== 'object' || !text(raw.id)) return null;
  const words = list(bootstrap.words);
  const fixture = Array.isArray(raw.choices) && Number.isInteger(raw.correct);
  const kind = fixture ? 'choice_preference' : (raw.kind || 'choice_preference');
  if (!EXERCISE_KINDS.includes(kind)) return null;
  const scenarioId = text(raw.scenarioId || raw.scenario_id || raw.id);
  const scenario = list(bootstrap.scenarios).find(item => item.id === scenarioId);
  const sentence = fixture ? `${text(raw.before)}〔词〕${text(raw.after)}`
    : text(raw.sentence || raw.template_zh || scenario?.sentence);
  // A fixture keeps its own progress ID. Borrow only the documented fit from
  // its explicit source link when both the intention and phrase still match.
  // Translation and explanation remain the fixture's original V9 text.
  const related = fixture && text(raw.related_scenario_id || raw.sourceScenarioId)
    ? list(bootstrap.scenarios).find(item => item.id === (raw.related_scenario_id || raw.sourceScenarioId)) : null;
  const fitScenario = scenario || (related && sentence === related.sentence
    && plain(raw.context) === plain(related.intent) ? related : null);
  const optionSource = fixture ? raw.choices : list(raw.options);
  const options = optionSource.map((option, index) => {
    const key = text(option.key) || (index === 0 ? 'a' : index === 1 ? 'b' : `option_${index}`);
    const word = option.word !== undefined ? option.word
      : fixture ? option.zh
      : key === 'a' ? raw.word_a || scenario?.a
      : key === 'b' ? raw.word_b || scenario?.b
      : null;
    const sourceFit = fitScenario && word === fitScenario.a ? fitScenario.fit_a
      : fitScenario && word === fitScenario.b ? fitScenario.fit_b : '';
    const fit = text(option.fit || sourceFit);
    return {
      key,
      label: text(option.label || option.zh),
      word: typeof word === 'string' ? word : null,
      pinyin: text(option.pinyin || option.py) || readingFor(word, words),
      fit,
      note: plain(option.note || (fitScenario && word === fitScenario.a ? fitScenario.note_a
        : fitScenario && word === fitScenario.b ? fitScenario.note_b : '')),
      validity: fit === 'preferred_in_context' || fit === 'possible_with_nuance'
        ? 'valid_in_context' : fit === 'requires_reformulation' ? 'requires_reformulation' : 'unreviewed',
    };
  });
  const answerKey = fixture ? options[raw.correct]?.key : text(raw.answerKey || raw.answer_key);
  if (options.length < 2 || options.length > 8 || options.some(option => !option.label)
      || new Set(options.map(option => option.key)).size !== options.length
      || !options.some(option => option.key === answerKey) || !sentence.includes('〔词〕')) return null;
  const prompt = text(raw.prompt || raw.prompt_es) || 'Elige la palabra que expresa esta intención.';
  const contrast = list(bootstrap.contrasts).find(item => item.id === fitScenario?.contrast_id)
    || list(bootstrap.contrasts).find(item => item.a === options[0]?.word && item.b === options[1]?.word);
  return {
    id: raw.id,
    scenarioId,
    title: text(raw.title || scenario?.label) || 'Una situación, dos matices',
    prompt,
    objective: text(raw.objective) || prompt,
    context: plain(raw.context || raw.intent_es || scenario?.intent),
    sentence,
    translation: text(raw.translation || scenario?.translation),
    options,
    answerKey,
    explanation: text(raw.explanation || raw.explanation_es || raw.explain),
    comparison: plain(raw.comparison || scenario?.comparison),
    contrastId: contrast?.id || null,
    relatedExample: list(contrast?.examples).find(example => example.variants?.a && example.variants?.b) || null,
    kind,
    status: raw.status === 'approved' ? 'approved' : 'draft',
    beforeTokens: tokens(raw.beforeTokens || raw.annotated?.before),
    afterTokens: tokens(raw.afterTokens || raw.annotated?.after),
  };
}

export function feedbackFor(exercise, selected) {
  const option = exercise.options.find(item => item.key === selected);
  if (!option) return null;
  // A word that completes an open sentence correctly earns credit. The older
  // recognise-validity tasks still ask learners to identify every valid option.
  const acceptedWord = exercise.kind === 'both_acceptable' && exercise.answerKey === 'both'
    && option.validity === 'valid_in_context';
  const correct = selected === exercise.answerKey || acceptedWord;
  const validityScope = !correct && exercise.answerKey === 'both' && option.validity === 'valid_in_context';
  const nuance = !correct && option.fit === 'possible_with_nuance';
  return {
    correct,
    type: correct ? 'target' : validityScope ? 'validity_scope' : nuance ? 'different_nuance' : 'review',
    title: correct ? exercise.answerKey === 'both'
      ? option.word ? 'Correcto. Aquí puedes usar las dos palabras.' : 'Las dos encajan en esta frase.'
      : 'Correcto.'
      : validityScope ? 'Esta palabra funciona; la otra también.'
      : option.fit === 'requires_reformulation' ? 'Esta palabra necesita otra estructura.'
      : nuance ? 'Válida, con otro matiz.' : 'Revisa esta intención.',
    explanation: exercise.explanation,
  };
}

export function makeSession(exercises, previous = {}) {
  const exerciseIds = list(exercises).map(exercise => typeof exercise === 'string' ? exercise : exercise.id);
  if (!exerciseIds.length || exerciseIds.some(id => !text(id)) || new Set(exerciseIds).size !== exerciseIds.length) {
    throw new TypeError('Una sesión necesita ejercicios con identificadores únicos.');
  }
  if (previous.dataVersion !== undefined && !/^[a-f0-9]{64}$/.test(previous.dataVersion)) {
    throw new TypeError('La versión del contenido debe ser un SHA256 canónico.');
  }
  const id = text(previous.id) || `session_${globalThis.crypto?.randomUUID?.() || `${Date.now()}_${Math.random().toString(36).slice(2)}`}`;
  return {
    id,
    lessonId: text(previous.lessonId) || null,
    exerciseIds,
    currentIndex: Number.isInteger(previous.currentIndex) && previous.currentIndex >= 0
      && previous.currentIndex < exerciseIds.length ? previous.currentIndex : 0,
    showPinyin: previous.showPinyin === true,
    showTranslation: previous.showTranslation === true,
    ended: previous.ended === true,
    ...(previous.dataVersion === undefined ? {} : { dataVersion: previous.dataVersion }),
    selections: previous.selections && typeof previous.selections === 'object' && !Array.isArray(previous.selections)
      ? Object.fromEntries(Object.entries(previous.selections).filter(([key, value]) => exerciseIds.includes(key) && typeof value === 'string')) : {},
  };
}
