# HanYuMatiz: lecciones originales y reportes privados

La navegación y la estética aprobadas se conservan. La pantalla Aprender prioriza
lecciones reales de uso antes del explorador HSK, sin atribuirles un nivel oficial.
Cada lección muestra una introducción breve y permite empezar sin leer una página
de teoría. Un selector reúne las ocho lecciones. Las palabras y las explicaciones
están en un apartado opcional, cerrado al entrar, con acceso al diccionario y a los ejemplos.
El contador de lecciones completadas depende de todas las respuestas guardadas en
la versión actual del contenido. No representa dominio del idioma.

Las opciones permanecen debajo de la frase en los ejercicios. Después de comprobar
una respuesta se muestra una explicación corta y un acceso a Reportar un error de matiz.
«Otro ejemplo» muestra una situación nueva con ambas frases traducidas, sin repetir
la explicación de la respuesta. «Ver todos los ejemplos» abre el par correspondiente
en Comparar. Las demostraciones históricas que no tienen un par publicado no
ofrecen este apoyo: no se inventan ejemplos ni enlaces.
En las frases del tipo `both_acceptable` se muestran las dos palabras y cualquiera
que sea válida recibe crédito. La opción «Las dos palabras» deja de ser una trampa
para quien eligió una palabra que completa bien la frase. Los ejercicios específicos
de reconocimiento de validez (`recognize_validity`) conservan su pregunta y sus opciones.
Una alternativa posible conserva el mensaje de cambio de matiz: no se presenta
automáticamente como una frase incorrecta.

## Comparar palabras

Un selector compacto y una búsqueda por caracteres, pinyin o español sustituyen
la lista lateral. En móvil, la búsqueda se despliega al solicitarla. El par muestra
su pronunciación y un resumen breve; no repite definiciones o categorías gramaticales.

Los 34 pares tienen tres casos originales adicionales: 102 casos nuevos y 204
frases traducidas. Junto con las 55 situaciones anteriores hay 157 casos para comparar.
Estos casos no se cuentan como ejercicios nuevos. Cada situación muestra la intención,
ambas versiones y una conclusión. El selector y los controles anterior/siguiente
permiten recorrer los ejemplos sin abandonar el par.

Las frases se muestran juntas en escritorio y apiladas en móvil. Una reformulación
nueva presenta la frase ya corregida con la indicación «Con otra construcción».
Si un escenario histórico contiene una sustitución que no encaja, esa frase no se
presenta como válida: se muestra la advertencia y la explicación.

## Reportar un error

Disponible en fichas de palabras, paneles de comparación y explicación de ejercicios.
El formulario muestra el contexto y referencia del contenido, pide motivo y comentario
(10–2.000 caracteres), permite contacto opcional (máximo 120 caracteres) y utiliza un
diálogo nativo con etiquetas, Escape, retorno de foco y estado anunciado.
El texto se inserta con textContent y nunca como HTML.

En la web, primero se obtiene el token CSRF del mismo origen y después se envía
`POST /api/reports` con `targetType`, `targetId`, `contentVersion`, `reason`, `comment`
y contacto opcional. Solo se confirma recepción después de una respuesta positiva
del servidor con `id` y estado `pending` o `received`. El estado pendiente indica
que el propietario aún debe evaluar el comentario. Un error conserva el texto y permite reintentar.
Los motivos son meaning, naturalness, grammar, translation, answer y other.

En el HTML autónomo (`bootstrap.delivery: standalone`) no hay solicitudes de reportes.
Guardar borrador conserva hasta 20 reportes en localStorage (`hymy.report-drafts.v1`).
Descargar reporte exporta un JSON con el contexto y la marca `local_draft_not_sent`.
La interfaz explica que no se ha enviado, incluso si el navegador impide guardarlo.
No hay bandeja pública ni comentarios visibles para otros estudiantes.

## Política editorial

`editorial.reviewPolicy: owner_reports` elimina los mensajes que exigían una revisión
externa por un lingüista. La interfaz habla de edición original y revisión del propietario,
sin atribuir aprobaciones expertas. El explorador HSK sigue mostrando los apartados
vacíos con honestidad. El expediente antiguo conserva su explicación cuando la
política nueva no está presente.

## Contrato de verificación

- Lección: `#originalLessonSelect`, `#lessonNotes`, `#originalLessonTitle`, `#lessonProgress`,
  `[data-start="lesson"][data-lesson-id]`.
- Comparar: `#contrastSearch`, `#comparisonSearchToggle`, `#contrastSelect`,
  `#comparisonExampleSelect`, `#comparisonPrevious`, `#comparisonNext`,
  `#comparisonCase`, `.comparison-version[data-variant]`, `#comparisonTakeaway`.
- Reporte: `[data-report][data-report-target]`, `#reportDialog`, `#reportReason`,
  `#reportComment`, `#reportContact`, `#reportSubmit`, `#reportExport`, `#reportStatus`.
- Continúan `#search`, `[data-word]`, `[data-view]`, `#choices`, `.choice` y `#primary`.
- `HanYuPlatform.inspect()` añade `selectedOriginalLesson`, conservando los campos previos.
- `mountPractice` acepta `createReportButton(question)` opcional para no afectar
  los usos anteriores del motor. El resultado que guarda el progreso utiliza la misma
  evaluación de respuestas que la explicación; una palabra válida en una frase abierta
  no se programa como fallo. Los intervalos y el almacenamiento siguen siendo los mismos.

El botón para empezar queda antes de la lectura opcional también en móvil; los botones permiten interacción táctil y por teclado.
Se respeta prefers-reduced-motion. El módulo nuevo `web/reports.js` debe incluirse
en la generación del HTML autónomo, que conservará la indicación de entrega local.
