#!/usr/bin/env python3
"""Regenerate the offline Chinese font from the current vocabulary and UI.

Only this maintenance command needs fontTools and an original Noto Serif CJK
font. Building or opening HanYuMatiz uses the committed subset directly.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE_FILES = ("data/vocabulary.json", "index.template.html", "assets/app.js")
DEFAULT_FONT = Path("/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc")
CJK_RANGES = (
    (0x3000, 0x303F),  # CJK punctuation
    (0x3400, 0x4DBF),  # Unified ideographs, extension A
    (0x4E00, 0x9FFF),  # Unified ideographs
    (0xF900, 0xFAFF),  # Compatibility ideographs
    (0xFF00, 0xFFEF),  # Fullwidth forms, including the exercise placeholder
    (0x20000, 0x323AF),  # Supplementary unified/compatibility ideographs
)
CHINESE_PUNCTUATION = {0x00B7, 0x2014, 0x2018, 0x2019, 0x201C, 0x201D, 0x2026}


def collect_codepoints(root: Path = ROOT) -> set[int]:
    """Read decoded JSON strings and literal CJK text in the HTML/JavaScript."""
    texts: list[str] = []

    def visit(value: object) -> None:
        if isinstance(value, str):
            texts.append(value)
        elif isinstance(value, dict):
            for key, item in value.items():
                visit(key)
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)

    visit(json.loads((root / SOURCE_FILES[0]).read_text(encoding="utf-8")))
    for filename in SOURCE_FILES[1:]:
        source = (root / filename).read_text(encoding="utf-8")
        texts.append(source)
        # Include escaped BMP characters if a future UI string uses \uXXXX.
        texts.extend(chr(int(match, 16)) for match in re.findall(r"\\u([0-9a-fA-F]{4})", source))
    points = {0xFF3F}
    for character in "".join(texts):
        point = ord(character)
        if point in CHINESE_PUNCTUATION or any(low <= point <= high for low, high in CJK_RANGES):
            points.add(point)
    return points


def select_font(path: Path):
    from fontTools.ttLib import TTCollection, TTFont

    if path.suffix.lower() in {".ttc", ".otc"}:
        collection = TTCollection(path, lazy=True)
        try:
            matches = [index for index, font in enumerate(collection.fonts)
                       if font["name"].getDebugName(1) == "Noto Serif CJK SC"]
            if len(matches) != 1:
                raise ValueError("La colección debe contener una sola familia Noto Serif CJK SC")
            index = matches[0]
        finally:
            collection.close()
        return TTFont(path, fontNumber=index, recalcTimestamp=False)
    font = TTFont(path, recalcTimestamp=False)
    if font["name"].getDebugName(1) != "Noto Serif CJK SC":
        font.close()
        raise ValueError("La fuente debe pertenecer a la familia Noto Serif CJK SC")
    return font


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--font", type=Path, default=DEFAULT_FONT,
                        help="Archivo original .ttc/.otc/.otf de Noto Serif CJK SC")
    parser.add_argument("--output", type=Path, default=ROOT / "assets/fonts/HanYuSong-Subset.otf")
    args = parser.parse_args()
    try:
        from fontTools import subset
        points = collect_codepoints()
        font = select_font(args.font)
        missing = points.difference(font.getBestCmap())
        if missing:
            raise ValueError("La fuente original no cubre: " + ", ".join(f"U+{point:04X}" for point in sorted(missing)))
        options = subset.Options()
        options.name_IDs = ["*"]
        options.name_languages = ["*"]
        options.name_legacy = True
        options.layout_features = ["*"]
        subsetter = subset.Subsetter(options=options)
        subsetter.populate(unicodes=points)
        subsetter.subset(font)
        # Distinguish the modified subset while retaining copyright/license data.
        names = {1: "HanYuSong", 2: "Regular", 3: "HanYuSong-Subset-Regular",
                 4: "HanYuSong Regular", 6: "HanYuSong-Regular",
                 16: "HanYuSong", 17: "Regular"}
        for record in font["name"].names:
            if record.nameID in names:
                record.string = names[record.nameID].encode(record.getEncoding())
        if "CFF " in font:
            cff = font["CFF "].cff
            cff.fontNames[0] = "HanYuSong-Regular"
            cff.topDictIndex[0].FamilyName = "HanYuSong"
            cff.topDictIndex[0].FullName = "HanYuSong Regular"
        args.output.parent.mkdir(parents=True, exist_ok=True)
        font.save(args.output)
        font.close()
        print(f"{args.output.name}: {args.output.stat().st_size:,} bytes; {len(points)} caracteres CJK/puntuación; cobertura completa")
        return 0
    except (ImportError, OSError, ValueError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
