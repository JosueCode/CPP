/* Run with: node tools/test_scheduler.cjs */
'use strict';

const assert = require('node:assert/strict');
const S = require('../assets/scheduler.js');
const DAY = '2026-10-10';
const tests = [];
const test = (name, fn) => tests.push({name, fn});
const exercise = (scenario, number, difficulty = 'inicial', pair = scenario) => ({
  id: `exercise_${scenario}_${number}`,
  scenario_id: scenario,
  kind: 'choice_preference',
  difficulty,
  word_a: `${pair}_a`,
  word_b: `${pair}_b`,
});
const progress = (attempts, dueDay = DAY) => ({
  attempts, correct: 0, streak: 0,
  last_day: attempts ? DAY : null,
  due_day: attempts ? dueDay : null,
});
const mixedBank = ['inicial', 'intermedio', 'avanzado'].flatMap((difficulty, tier) =>
  Array.from({length: 7}, (_, index) => exercise(`s${tier}_${index}`, 0, difficulty))
);
const countTiers = plan => plan.exercises.reduce((counts, item) => {
  counts[item.difficulty] = (counts[item.difficulty] || 0) + 1;
  return counts;
}, {});

test('Una situación con un ejercicio funciona y siempre conserva ese ejercicio', () => {
  const bank = [exercise('single', 0)];
  for (const attempts of [0, 1, 2, 20]) {
    const history = attempts ? {single: progress(attempts)} : {};
    const plan = S.schedule(bank, history, DAY);
    assert.equal(plan.exercises.length, 1);
    assert.equal(plan.exercises[0].exercise_id, 'exercise_single_0');
  }
});

test('Tres ejercicios rotan de principio a fin sin duplicar la situación', () => {
  const bank = [0, 1, 2].map(index => exercise('triple', index));
  const selected = [];
  for (let attempts = 0; attempts < 7; attempts++) {
    const plan = S.schedule(bank, attempts ? {triple: progress(attempts)} : {}, DAY);
    assert.equal(plan.exercises.length, 1);
    selected.push(plan.exercises[0].exercise_id);
  }
  assert.deepEqual(selected, [0, 1, 2, 0, 1, 2, 0].map(index => `exercise_triple_${index}`));
});

test('La sesión inicial respeta los cupos 4/3/1 con banco suficiente', () => {
  const plan = S.schedule(mixedBank, {}, DAY);
  assert.equal(plan.exercises.length, 8);
  assert.deepEqual(countTiers(plan), {inicial: 4, intermedio: 3, avanzado: 1});
  assert.equal(new Set(plan.exercises.map(item => item.scenario_id)).size, 8);
});

test('Una sesión de repaso aplica cupos 3/3/2 y prioriza el vencimiento', () => {
  const entry = S.update(undefined, true, '2026-10-09');
  const plan = S.schedule(mixedBank, {s0_0: entry}, DAY);
  assert.deepEqual(countTiers(plan), {inicial: 3, intermedio: 3, avanzado: 2});
  assert.equal(plan.exercises[0].scenario_id, 's0_0');
});

test('Los casos futuros se excluyen y el repaso anticipado los incluye', () => {
  const bank = [exercise('future', 0), exercise('new', 0), exercise('due', 0)];
  const history = {future: progress(1, '2026-10-11'), due: progress(1)};
  const regular = S.schedule(bank, history, DAY);
  assert.deepEqual(regular.exercises.map(item => item.scenario_id), ['due', 'new']);
  assert.equal(regular.eligible_count, 2);
  assert.equal(regular.not_due_count, 1);
  const early = S.schedule(bank, history, DAY, {early: true});
  assert.deepEqual(early.exercises.map(item => item.scenario_id), ['due', 'new', 'future']);
  assert.equal(early.not_due_count, 0);
});

test('El banco de una sola dificultad aprovecha el límite sin bloquear preguntas', () => {
  const bank = Array.from({length: 12}, (_, index) => exercise(`same_${index}`, 0, 'avanzado', 'repeated'));
  const plan = S.schedule(bank, {}, DAY);
  assert.equal(plan.exercises.length, 8);
  assert.equal(new Set(plan.exercises.map(item => item.scenario_id)).size, 8);
  assert.equal(S.schedule(bank, {}, DAY, {limit: 3}).exercises.length, 3);
});

test('Las respuestas correctas progresan por intervalos 1/3/7/14/30 días', () => {
  let entry;
  let day = DAY;
  for (const interval of [1, 3, 7, 14, 30, 30]) {
    entry = S.update(entry, true, day);
    assert.equal(entry.due_day, S.dayAdd(day, interval));
    assert.equal(entry.attempts, entry.correct);
    assert.equal(entry.streak, entry.correct);
    day = entry.due_day;
  }
  const missed = S.update(entry, false, day);
  assert.equal(missed.streak, 0);
  assert.equal(missed.due_day, day);
  assert.equal(missed.correct, entry.correct);
  assert.equal(missed.attempts, entry.attempts + 1);
});

test('Las fechas reales, los años bisiestos y el cambio de año se validan', () => {
  assert.equal(S.validDay('2024-02-29'), true);
  for (const day of ['2026-02-29', '2026-02-30', '2026-13-01', '2026-1-01', '', null]) {
    assert.equal(S.validDay(day), false);
  }
  assert.equal(S.dayAdd('2024-02-28', 1), '2024-02-29');
  assert.equal(S.dayAdd('2026-12-31', 1), '2027-01-01');
  assert.equal(S.isoToday(new Date(2026, 9, 10, 12)), DAY);
});

test('Se rechazan los historiales corruptos y las situaciones desconocidas', () => {
  const bank = [exercise('known', 0)];
  assert.equal(S.validateHistory({known: progress(1)}, bank, DAY), true);
  const invalid = [
    {unknown: progress(1)},
    {known: {...progress(1), correct: 2}},
    {known: {...progress(1), attempts: -1}},
    {known: {...progress(1), streak: 1}},
    {known: {...progress(1), extra: 'unexpected'}},
    {known: {...progress(1), last_day: '2026-10-11', due_day: '2026-10-11'}},
    {known: {...progress(1), due_day: '2026-11-11'}},
    {known: {...progress(0), due_day: DAY}},
    [], null,
  ];
  for (const history of invalid) {
    assert.equal(S.validateHistory(history, bank, DAY), false);
    assert.throws(() => S.schedule(bank, history, DAY));
  }
});

test('Las peticiones inválidas y los bancos vacíos producen errores explícitos', () => {
  const bank = [exercise('known', 0)];
  for (const options of [{limit: 0}, {limit: 9}, {limit: 1.5}, {early: 'yes'}]) {
    assert.throws(() => S.schedule(bank, {}, DAY, options));
  }
  assert.throws(() => S.schedule(bank, {}, '2026-02-30'));
  assert.throws(() => S.schedule([], {}, DAY));
  assert.throws(() => S.update(undefined, 'true', DAY));
  assert.throws(() => S.update(undefined, true, '2026-02-30'));
});

let failures = 0;
for (const {name, fn} of tests) {
  try {
    fn();
    process.stdout.write(`✓ ${name}\n`);
  } catch (error) {
    failures++;
    process.stderr.write(`✗ ${name}\n${error.stack}\n`);
  }
}
process.stdout.write(`Planificador: ${tests.length - failures}/${tests.length} comprobaciones correctas\n`);
process.exitCode = failures ? 1 : 0;
