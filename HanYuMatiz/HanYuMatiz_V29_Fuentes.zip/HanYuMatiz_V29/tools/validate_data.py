#!/usr/bin/env python3
"""Validate structural content integrity. This does not certify Chinese usage."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
HASH = re.compile(r"[0-9a-f]{64}\Z")
ID = re.compile(r"[a-z][a-z0-9_]*\Z")
FIT = {"preferred_in_context", "possible_with_nuance", "requires_reformulation"}
KINDS = {"choice_preference", "choice_structure", "both_acceptable", "recognize_validity"}
DIFFICULTIES = {"inicial", "intermedio", "avanzado"}
POS = {"verb", "noun", "adjective", "adverb", "preposition", "pronoun", "numeral", "classifier", "conjunction", "particle", "interjection"}


def canonical_sha256(value: object) -> str:
    text = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _unique_keys(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Clave JSON duplicada: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> object:
    if path.stat().st_size > 16 * 1024 * 1024:
        raise ValueError(f"{path.name}: supera 16 MiB")
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_unique_keys)


def validate(data: object, baseline: dict) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    def check(condition: bool, message: str) -> None:
        if not condition:
            errors.append(message)

    def text(value: object) -> bool:
        return isinstance(value, str) and bool(value.strip())

    def fields(row: dict, names: tuple[str, ...], at: str) -> None:
        for name in names:
            check(text(row.get(name)), f"{at}: {name} debe ser texto no vacío")

    def records(value: object, at: str) -> dict[str, dict]:
        if not isinstance(value, list) or not value:
            errors.append(f"{at}: debe ser una lista no vacía")
            return {}
        result = {}
        for index, row in enumerate(value):
            if not isinstance(row, dict):
                errors.append(f"{at}[{index}]: debe ser un objeto")
                continue
            identifier = row.get("id")
            if not isinstance(identifier, str) or not ID.fullmatch(identifier):
                errors.append(f"{at}[{index}]: id ausente o inválido")
                continue
            check(identifier not in result, f"{at}: id duplicado {identifier}")
            result[identifier] = row
        return result

    def syllables(value: object, zh: str, at: str) -> None:
        if not isinstance(value, list) or not value:
            errors.append(f"{at}: faltan sílabas")
            return
        check(len(value) == len(zh), f"{at}: debe haber una sílaba por carácter")
        for index, syllable in enumerate(value):
            if not isinstance(syllable, dict):
                errors.append(f"{at}[{index}]: sílaba inválida")
                continue
            pinyin, tone = syllable.get("pinyin"), syllable.get("tone")
            check(text(pinyin), f"{at}[{index}]: falta pinyin")
            check(type(tone) is int and 1 <= tone <= 5, f"{at}[{index}]: tono fuera de 1–5")
            if isinstance(pinyin, str):
                normalized = unicodedata.normalize("NFD", pinyin)
                marks = [c for c in normalized if c in "\u0304\u0301\u030c\u0300"]
                letters = unicodedata.normalize("NFC", "".join(c for c in normalized if c not in "\u0304\u0301\u030c\u0300"))
                check(bool(re.fullmatch(r"[a-zü]+", letters)), f"{at}[{index}]: pinyin debe ser una sílaba en letras minúsculas")
                expected = {1: "\u0304", 2: "\u0301", 3: "\u030c", 4: "\u0300", 5: None}.get(tone)
                check(marks == ([] if expected is None else [expected]), f"{at}[{index}]: marca tonal y tone no coinciden")

    if not isinstance(data, dict):
        return ["La raíz del vocabulario debe ser un objeto"], []
    check(data.get("project") == "HanYuMatiz", "project debe ser HanYuMatiz")
    fields(data, ("version", "sourceHash"), "raíz")
    for flag in ("public_use", "rights_approved", "linguistic_approved"):
        check(data.get(flag) is False, f"{flag}: esta aplicación solo admite borradores privados")
    words = records(data.get("words"), "words")
    contrasts = records(data.get("contrasts"), "contrasts")
    scenarios = records(data.get("scenarios"), "scenarios")
    exercises = records(data.get("exercises"), "exercises")
    seen_ids: set[str] = set()
    by_zh: dict[str, dict] = {}

    for identifier, word in words.items():
        fields(word, ("zh",), identifier)
        zh = word.get("zh", "")
        if not isinstance(zh, str):
            continue
        check(zh not in by_zh, f"{identifier}: grafía duplicada {zh}")
        by_zh[zh] = word
        check(type(word.get("reviewed")) is bool, f"{identifier}: reviewed debe ser booleano")
        level = word.get("hsk_level")
        check(level is None or (type(level) is int and 1 <= level <= 9), f"{identifier}: hsk_level debe ser null o 1–9")
        readings = records(word.get("readings"), f"{identifier}.readings")
        senses = records(word.get("senses"), f"{identifier}.senses")
        for reading_id, reading in readings.items():
            fields(reading, ("pinyin",), reading_id)
            values = reading.get("syllables")
            syllables(values, zh, reading_id)
            if isinstance(values, list) and all(isinstance(v, dict) and text(v.get("pinyin")) for v in values) and text(reading.get("pinyin")):
                clean = lambda s: re.sub(r"[\s'’\-]", "", unicodedata.normalize("NFC", s))
                check(clean(reading["pinyin"]) == clean("".join(v["pinyin"] for v in values)), f"{reading_id}: lectura y sílabas no coinciden")
        for sense_id, sense in senses.items():
            fields(sense, ("gloss", "pos"), sense_id)
            check(sense.get("pos") in POS, f"{sense_id}: categoría gramatical desconocida")
        for child_id in [identifier, *readings, *senses]:
            check(child_id not in seen_ids, f"ID repetido en el modelo: {child_id}")
            seen_ids.add(child_id)

    for identifier, contrast in contrasts.items():
        fields(contrast, ("a", "b", "word_id_a", "word_id_b", "sense_a", "sense_b", "pos_a", "pos_b", "topic", "method"), identifier)
        check(type(contrast.get("reviewed")) is bool, f"{identifier}: reviewed debe ser booleano")
        check(contrast.get("a") != contrast.get("b"), f"{identifier}: las dos palabras deben ser distintas")
        for side in ("a", "b"):
            word = words.get(contrast.get(f"word_id_{side}"))
            check(word is not None, f"{identifier}: word_id_{side} no existe")
            if word:
                check(word.get("zh") == contrast.get(side), f"{identifier}: palabra y word_id_{side} no coinciden")
                senses = word.get("senses", [])
                if isinstance(senses, list):
                    check(any(isinstance(s, dict) and s.get("gloss") == contrast.get(f"sense_{side}") and s.get("pos") == contrast.get(f"pos_{side}") for s in senses), f"{identifier}: sentido/pos_{side} no pertenece a la palabra")
        check(isinstance(contrast.get("cautions"), list), f"{identifier}: cautions debe ser una lista")
        check(isinstance(contrast.get("signals"), dict), f"{identifier}: signals debe ser un objeto")

    phonetics = data.get("phonetics")
    if not isinstance(phonetics, dict):
        errors.append("phonetics debe ser un objeto")
        phonetics = {}
    check(set(phonetics) == set(scenarios), "phonetics: debe cubrir exactamente los IDs de scenarios")
    for identifier, scenario in scenarios.items():
        fields(scenario, ("label", "intent", "sentence", "translation", "a", "b", "note_a", "note_b", "comparison", "contrast_id"), identifier)
        check(type(scenario.get("reviewed")) is bool, f"{identifier}: reviewed debe ser booleano")
        sentence = scenario.get("sentence")
        check(isinstance(sentence, str) and sentence.count("〔词〕") == 1, f"{identifier}: sentence necesita exactamente un marcador 〔词〕")
        contrast = contrasts.get(scenario.get("contrast_id"))
        check(contrast is not None, f"{identifier}: contrast_id no existe")
        if contrast:
            check(all(scenario.get(side) == contrast.get(side) for side in ("a", "b")), f"{identifier}: palabras u orden no coinciden con el contraste")
        pair_phonetics = phonetics.get(identifier, {})
        if not isinstance(pair_phonetics, dict):
            errors.append(f"{identifier}: phonetics inválido")
            pair_phonetics = {}
        for side in ("a", "b"):
            check(scenario.get(f"fit_{side}") in FIT, f"{identifier}: fit_{side} desconocido")
            zh = scenario.get(side, "")
            if not isinstance(zh, str):
                continue
            values = pair_phonetics.get(side)
            syllables(values, zh, f"phonetics.{identifier}.{side}")
            word = by_zh.get(zh)
            if word and isinstance(word.get("readings"), list):
                check(any(isinstance(r, dict) and r.get("syllables") == values for r in word["readings"]), f"{identifier}.{side}: fonética no coincide con ninguna lectura del diccionario")

    for collection in (contrasts, scenarios, exercises):
        for identifier in collection:
            check(identifier not in seen_ids, f"ID repetido en el modelo: {identifier}")
            seen_ids.add(identifier)
    for identifier, exercise in exercises.items():
        fields(exercise, ("scenario_id", "scenario_sha256", "prompt_es", "intent_es", "template_zh", "word_a", "word_b", "explanation_es", "origin", "status"), identifier)
        scenario = scenarios.get(exercise.get("scenario_id"))
        check(scenario is not None, f"{identifier}: scenario_id no existe")
        kind = exercise.get("kind")
        check(kind in KINDS, f"{identifier}: kind desconocido")
        check(exercise.get("difficulty") in DIFFICULTIES, f"{identifier}: difficulty desconocida")
        check(isinstance(exercise.get("scenario_sha256"), str) and bool(HASH.fullmatch(exercise["scenario_sha256"])), f"{identifier}: scenario_sha256 inválido")
        for flag in ("linguistic_review", "rights_review", "public_use"):
            check(exercise.get(flag) is False, f"{identifier}: {flag} debe seguir false en este prototipo")
        check(isinstance(exercise.get("evidence"), list), f"{identifier}: evidence debe ser una lista")
        options = exercise.get("options")
        keys: list[str] = []
        if not isinstance(options, list):
            errors.append(f"{identifier}: options debe ser una lista")
        else:
            for option in options:
                if not isinstance(option, dict) or not text(option.get("key")) or not text(option.get("label")):
                    errors.append(f"{identifier}: opción inválida")
                else:
                    keys.append(option["key"])
            expected_keys = ["a", "b", "both"] if kind in ("both_acceptable", "recognize_validity") else ["a", "b"]
            check(keys == expected_keys, f"{identifier}: claves/orden de options no corresponden a kind")
        check(exercise.get("answer_key") in keys, f"{identifier}: answer_key no corresponde a una opción")
        if scenario:
            check(exercise.get("template_zh") == scenario.get("sentence"), f"{identifier}: template_zh difiere del escenario")
            check(exercise.get("intent_es") == scenario.get("intent"), f"{identifier}: intent_es difiere del escenario")
            check(all(exercise.get(f"word_{side}") == scenario.get(side) for side in ("a", "b")), f"{identifier}: palabras u orden difieren del escenario")
            valid = [side for side in ("a", "b") if scenario.get(f"fit_{side}") in FIT - {"requires_reformulation"}]
            if kind in ("recognize_validity", "choice_structure", "both_acceptable"):
                expected_answer = "both" if len(valid) == 2 else valid[0] if len(valid) == 1 else None
                check(exercise.get("answer_key") == expected_answer, f"{identifier}: respuesta incompatible con fit_a/fit_b")
            if kind == "choice_preference":
                preferred = [side for side in ("a", "b") if scenario.get(f"fit_{side}") == "preferred_in_context"]
                check(len(preferred) == 1 and exercise.get("answer_key") == preferred[0], f"{identifier}: no hay una preferencia única para esta clave")
            actual_hash = canonical_sha256(scenario)
            inherited = baseline.get("scenarios", {}).get(scenario["id"], {})
            retained_original = actual_hash == inherited.get("canonical_sha256") and exercise.get("scenario_sha256") == inherited.get("imported_sha256")
            check(retained_original or exercise.get("scenario_sha256") == actual_hash, f"{identifier}: escenario modificado; actualizar scenario_sha256 en ambos ejercicios")
    source_hash = data.get("sourceHash")
    digests = data.get("sourceDigests")
    check(isinstance(source_hash, str) and bool(HASH.fullmatch(source_hash)), "sourceHash debe tener 64 dígitos hexadecimales")
    if not isinstance(digests, dict):
        errors.append("sourceDigests debe ser un objeto")
        digests = {}
    for name in ("p3_model", "p4_contrasts", "p5_scenarios", "p6_exercises"):
        check(isinstance(digests.get(name), str) and bool(HASH.fullmatch(digests[name])), f"sourceDigests.{name}: formato inválido")
    check(source_hash == digests.get("p6_exercises"), "sourceHash y sourceDigests.p6_exercises deben coincidir")
    actual_exercises = canonical_sha256(data.get("exercises"))
    inherited_hash = baseline.get("imported_source_hash")
    if source_hash == inherited_hash:
        check(actual_exercises == baseline.get("canonical_exercises_sha256"), "Ejercicios modificados con sourceHash heredado: generar un nuevo hash canónico para evitar reutilizar progreso incompatible")
        warnings.append("sourceHash y scenario_sha256 importados identifican versiones; su cálculo original no se pudo reproducir. Se verifican contra la línea base canónica independiente.")
    else:
        check(source_hash == actual_exercises, "El nuevo sourceHash debe ser el SHA-256 canónico de exercises")
    warnings.append("La validación es estructural. El contenido continúa como borrador lingüístico; los niveles HSK y los derechos no están aprobados.")
    return errors, warnings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data/vocabulary.json")
    args = parser.parse_args()
    try:
        data = load_json(args.data)
        baseline = load_json(ROOT / "data/integrity-baseline.json")
        errors, warnings = validate(data, baseline)
    except (OSError, ValueError, TypeError, KeyError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    for error in errors:
        print(f"ERROR: {error}", file=sys.stderr)
    for warning in warnings:
        print(f"AVISO: {warning}")
    if errors:
        return 1
    print("Datos válidos: " + ", ".join(f"{len(data[key])} {key}" for key in ("words", "contrasts", "scenarios", "exercises")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
