#!/usr/bin/env python3
"""Create HanYuSans, the offline Latin subset of Source Sans 3.

Only font maintenance needs fontTools and the original variable font. The
builder embeds the committed subset without downloading any resources.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
LATIN_RANGES = (
    (0x0020, 0x024F),  # Latin, Spanish and precomposed pinyin vowels
    (0x0300, 0x036F),  # Combining accents and tone marks
    (0x1E00, 0x1EFF),  # Additional Latin, including pinyin m with an acute tone
    (0x2000, 0x206F),  # General punctuation
    (0x2190, 0x21FF),  # Arrows supported by the original font
)
EXTRA_POINTS = {0x20AC, 0x2212, 0x25CB, 0x25CF}
REQUIRED_TEXT = "áéíóúüñÁÉÍÓÚÜÑ¿¡āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜńňǹḿ\u0300\u0301\u0304\u030c"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--font", type=Path, required=True,
                        help="Archivo original variable SourceSans3[wght].ttf")
    parser.add_argument("--output", type=Path, default=ROOT / "assets/fonts/HanYuSans-Latin.ttf")
    args = parser.parse_args()
    try:
        from fontTools import subset
        from fontTools.ttLib import TTFont

        font = TTFont(args.font, recalcTimestamp=False)
        if font["name"].getDebugName(16) != "Source Sans 3":
            raise ValueError("La fuente debe pertenecer a Source Sans 3")
        axes = [(axis.axisTag, axis.minValue, axis.maxValue) for axis in font["fvar"].axes]
        if axes != [("wght", 200.0, 900.0)]:
            raise ValueError("Se requiere la fuente variable romana con peso 200–900")
        cmap = font.getBestCmap()
        missing = {ord(character) for character in REQUIRED_TEXT}.difference(cmap)
        if missing:
            raise ValueError("La fuente no cubre el español/pinyin requerido: " +
                             ", ".join(f"U+{point:04X}" for point in sorted(missing)))
        points = {point for point in cmap if point in EXTRA_POINTS or
                  any(low <= point <= high for low, high in LATIN_RANGES)}
        options = subset.Options()
        options.name_IDs = ["*"]
        options.name_languages = ["*"]
        options.name_legacy = True
        options.layout_features = ["*"]
        subsetter = subset.Subsetter(options=options)
        subsetter.populate(unicodes=points)
        subsetter.subset(font)
        # Source is a Reserved Font Name: the modified subset has its own names.
        # Copyright, author and OFL fields are deliberately preserved.
        names = {
            1: "HanYuSans", 2: "ExtraLight", 3: "HanYuSans-Latin-3.052",
            4: "HanYuSans", 6: "HanYuSans-Roman", 16: "HanYuSans",
            17: "ExtraLight", 25: "HanYuSans",
        }
        for record in font["name"].names:
            if record.nameID in names:
                record.string = names[record.nameID].encode(record.getEncoding())
        args.output.parent.mkdir(parents=True, exist_ok=True)
        font.save(args.output)
        font.close()
        check = TTFont(args.output)
        if not points.issubset(check.getBestCmap()):
            raise ValueError("El subconjunto generado perdió caracteres solicitados")
        if any("Source" in record.toUnicode() for record in check["name"].names
               if record.nameID in names):
            raise ValueError("El subconjunto conserva un nombre de familia reservado")
        check.close()
        print(f"{args.output.name}: {args.output.stat().st_size:,} bytes; "
              f"{len(points)} caracteres; español y pinyin completos; pesos 200–900")
        return 0
    except (ImportError, OSError, ValueError, KeyError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
