#!/usr/bin/env python3
"""Build the dependency-free standalone page from editable sources."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import sys

from validate_data import ROOT, load_json, validate


def script_hash(text: str) -> str:
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    return "'sha256-" + base64.b64encode(digest).decode("ascii") + "'"


def render(root: Path = ROOT) -> str:
    data = load_json(root / "data/vocabulary.json")
    baseline = load_json(root / "data/integrity-baseline.json")
    errors, _warnings = validate(data, baseline)
    if errors:
        raise ValueError("Datos inválidos:\n" + "\n".join(errors))
    styles = (root / "assets/styles.css").read_text(encoding="utf-8")
    if styles.count("{{FONT_FACE}}") != 1:
        raise ValueError("styles.css debe contener un solo token FONT_FACE")
    styles += "\n" + (root / "assets/tools.css").read_text(encoding="utf-8")
    font = base64.b64encode((root / "assets/fonts/HanYuSans-Latin.ttf").read_bytes()).decode("ascii")
    face = "@font-face{font-family:HanYuSans;src:url(data:font/ttf;base64," + font + ") format('truetype');font-weight:200 900;font-style:normal;font-display:swap}"
    chinese_font = base64.b64encode((root / "assets/fonts/HanYuSong-Subset.otf").read_bytes()).decode("ascii")
    face += "@font-face{font-family:HanYuSong;src:url(data:font/otf;base64," + chinese_font + ") format('opentype');font-weight:400;font-style:normal;font-display:swap}"
    styles = styles.replace("{{FONT_FACE}}", face)
    scheduler = (root / "assets/scheduler.js").read_text(encoding="utf-8")
    app = (root / "assets/app.js").read_text(encoding="utf-8")
    if re.search(r"</style\b", styles, re.IGNORECASE):
        raise ValueError("styles.css contiene un cierre de style inseguro")
    for name, script in (("scheduler", scheduler), ("app", app)):
        if re.search(r"</script\b", script, re.IGNORECASE):
            raise ValueError(f"{name}.js contiene un cierre de script inseguro")
    # Escaping '<' prevents </script> and HTML parser ambiguities inside JSON.
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    landscape = (root / "assets/landscape.svg").read_text(encoding="utf-8")
    if re.search(r"<script\b|<foreignObject\b|(?:href|src)\s*=\s*[\"\'](?:https?:|//)", landscape, re.IGNORECASE):
        raise ValueError("La ilustración debe ser un SVG estático sin recursos externos")
    replacements = {
        "{{LANDSCAPE}}": landscape,
        "{{STYLES}}": styles,
        "{{PAYLOAD}}": payload,
        "{{SCHEDULER}}": scheduler,
        "{{APP}}": app,
        "{{SCRIPT_HASHES}}": " ".join(script_hash(s) for s in (scheduler, app)),
    }
    template = (root / "index.template.html").read_text(encoding="utf-8")
    for token in replacements:
        if template.count(token) != 1:
            raise ValueError(f"La plantilla debe contener exactamente una aparición de {token}")
    # One pass: token-like text in vocabulary is never treated as a template.
    rendered = re.sub(r"\{\{(?:STYLES|PAYLOAD|SCHEDULER|APP|SCRIPT_HASHES|LANDSCAPE)\}\}", lambda m: replacements[m.group()], template)
    scripts = re.findall(r"<script\b([^>]*)>(.*?)</script\s*>", rendered, re.IGNORECASE | re.DOTALL)
    executable = [body for attrs, body in scripts if not re.search(r'type\s*=\s*[\"\']application/json[\"\']', attrs, re.IGNORECASE)]
    if executable != [scheduler, app]:
        raise ValueError("La plantilla debe contener solo dos scripts ejecutables, con los tokens como cuerpo exacto para que coincidan los hashes CSP")
    return rendered


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Comprobar que index.html coincide con las fuentes sin escribirlo")
    parser.add_argument("--output", type=Path, default=ROOT / "index.html")
    args = parser.parse_args()
    try:
        rendered = render()
        if args.check:
            if not args.output.exists() or args.output.read_text(encoding="utf-8") != rendered:
                raise ValueError(f"{args.output.name} no está actualizado; ejecutar python3 tools/build.py")
            print(f"{args.output.name} coincide con las fuentes; hashes CSP verificados")
        else:
            args.output.write_text(rendered, encoding="utf-8")
            print(f"Generado {args.output.name}: {len(rendered.encode('utf-8')):,} bytes; dos scripts con SHA-256 CSP")
    except (OSError, ValueError, TypeError, KeyError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
