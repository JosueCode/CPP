#!/usr/bin/env python3
"""Exercise the generated standalone app in Chromium and save visual previews.

Run: python3 tools/test_ui.py
Requires the Python Playwright package and Chromium. A local HTTP origin enables
the storage checks; the app itself is loaded with set_content and needs no server.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
from pathlib import Path
import re
import sys
from tempfile import TemporaryDirectory
from threading import Thread
import traceback
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
TABS = ("aprender", "buscar", "comparar", "simular", "practicar")
PREVIEW_NAMES = ("aprender", "diccionario", "comparar", "contexto", "practicar")
VIEWPORTS = ((1440, 900), (1366, 768), (1280, 720), (1024, 768),
             (768, 1024), (390, 844), (375, 812), (360, 740), (320, 568))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def audit_csp(html: str) -> dict:
    payload_match = re.search(r'<script\b[^>]*\bid="payload"[^>]*>(.*?)</script\s*>', html, re.S | re.I)
    require(payload_match is not None, "Falta el JSON de contenido")
    data = json.loads(payload_match.group(1))
    meta = re.search(r'<meta\b[^>]*http-equiv="Content-Security-Policy"[^>]*>', html, re.I)
    require(meta is not None, "Falta la política CSP")
    policy = re.search(r'\bcontent="([^"]*)"', meta.group()).group(1)
    executable = []
    for attrs, script in re.findall(r'<script\b([^>]*)>(.*?)</script\s*>', html, re.S | re.I):
        if not re.search(r'type\s*=\s*[\"\']application/json[\"\']', attrs, re.I):
            executable.append(script)
    require(len(executable) == 2, f"Se esperaban dos scripts ejecutables; encontrados {len(executable)}")
    for index, script in enumerate(executable, start=1):
        digest = base64.b64encode(hashlib.sha256(script.encode("utf-8")).digest()).decode("ascii")
        require(f"'sha256-{digest}'" in policy, f"El hash CSP del script {index} no coincide")
    script_policy = next((part.strip() for part in policy.split(";") if part.strip().startswith("script-src ")), "")
    require("'unsafe-inline'" not in script_policy and "'unsafe-eval'" not in script_policy, "La política de scripts ha relajado la verificación CSP")
    require("connect-src 'none'" in policy and "font-src data:" in policy, "La página autónoma admite conexiones o fuentes externas")
    return data


class OriginHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        if self.path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return
        body = b'<!doctype html><html><head><title>HanYuMatiz test origin</title></head><body></body></html>'
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_args) -> None:
        pass


class UiChecks:
    def __init__(self, browser, html: str, data: dict, origin: str | None, screenshots: Path | None, report_path: Path | None = None):
        self.context = browser.new_context(viewport={"width": 1440, "height": 900}, timezone_id="Asia/Shanghai")
        self.html = html
        self.data = data
        self.origin = origin
        self.screenshots = screenshots
        self.report_path = report_path or ROOT / "docs/VALIDACION_V29.json"
        self.errors: list[str] = []
        self.requests: list[str] = []
        self.results: list[dict] = []
        self.responsive_cases: list[dict] = []
        self.picker_cases: list[dict] = []
        self.landing_queries: list[dict] = []
        self.practice_cases: list[dict] = []
        self.desktop_bank_cases: list[dict] = []
        self.zoom_cases: list[dict] = []
        self.curriculum_cases: list[dict] = []
        self.previews: list[str] = []
        self.page = self.new_page()
        self.storage_available = bool(self.page.evaluate("""() => {
          try { const key = '__hanyumatiz_ui_test__'; localStorage.setItem(key, '1');
            localStorage.removeItem(key); return true; } catch { return false; }
        }"""))

    def new_page(self, initial_hash: str | None = None, reduced_motion: bool = False):
        page = self.context.new_page()
        page.set_default_timeout(6000)
        if reduced_motion:
            page.emulate_media(reduced_motion="reduce")
        if self.origin:
            try:
                page.goto(self.origin, wait_until="load", timeout=6000)
            except Exception as error:
                # Browser policies can prohibit local navigation. Keep the
                # standalone UI checks useful and report storage as unavailable.
                print(f"AVISO: origen HTTP local no disponible: {str(error).splitlines()[0]}")
                self.origin = None
                page.close()
                return self.new_page(initial_hash, reduced_motion)
        if initial_hash is not None:
            page.evaluate("hash => history.replaceState(null, '', hash)", initial_hash)
        # Bootstrap navigation belongs to the harness, not the offline app.
        page.on("pageerror", lambda error: self.errors.append(str(error)))
        page.on("console", lambda message: self.errors.append(message.text) if message.type == "error" else None)
        page.on("request", lambda request: self.requests.append(request.url))
        page.on("dialog", lambda dialog: dialog.accept())
        page.set_content(self.html, wait_until="load")
        page.evaluate("() => document.fonts.ready")
        return page

    def enter(self, tab: str = "buscar", page=None) -> None:
        page = page or self.page
        require(page.locator("#landing").is_visible(), "La portada debe ofrecer el acceso al aprendizaje")
        # The comparison entry now belongs to the real demonstration instead
        # of a separate four-pair catalogue on the cover.
        entry = page.locator("#demo-comparison") if tab == "comparar" else page.locator(f'[data-enter="{tab}"]').first
        entry.click()
        page.wait_for_function("tab => location.hash === '#' + tab", arg=tab)
        require(page.locator("#app-shell").is_visible(), "Entrar no muestra la aplicación")
        require(not page.locator("#landing").is_visible(), "La portada permanece delante de la aplicación")
        require(page.locator(f"#view-{tab}").is_visible(), f"El acceso a {tab} muestra otro panel")
        target = "#exercise h3" if tab == "practicar" else f"#h-{tab}"
        require(page.locator(target).evaluate("node => document.activeElement === node"), "Entrar no mueve el foco al contenido")

    def home(self, page=None) -> None:
        page = page or self.page
        if page.locator('#landing').is_visible():
            page.locator('#landing-title').focus()
            return
        if page.locator("#practice-back").is_visible():
            page.locator("#practice-back").click()
        control = page.locator("#home-link")
        if not control.is_visible():
            control = page.locator("#app-shell .brand")
        control.click()
        require(page.locator("#landing").is_visible(), "Volver al inicio no muestra la portada")
        require(page.locator("#landing-title").evaluate("node => document.activeElement === node"), "Volver a la portada pierde el foco")

    def inspect(self, page=None) -> dict:
        result = (page or self.page).evaluate("() => window.HanYuMatizP10?.inspect()")
        require(isinstance(result, dict), "La aplicación no arrancó; revisar scripts y CSP")
        return result

    def require_heading_in_view(self, selector: str, page=None) -> None:
        """The sticky header must leave the focused content heading visible."""
        page = page or self.page
        page.wait_for_function("""selector => {
          const heading = document.querySelector(selector).getBoundingClientRect();
          const activePractice = document.body.classList.contains('practice-active');
          const header = document.querySelector(activePractice ? '.practice-stage > header' : '.app-rail').getBoundingClientRect();
          const isPracticeTitle = selector === '#h-practicar';
          if (isPracticeTitle) return heading.top >= 0 && heading.bottom <= innerHeight + 1;
          return heading.top >= Math.max(0, header.bottom) - 1 && heading.bottom <= innerHeight + 1;
        }""", arg=selector)

    def navigate(self, tab: str, page=None) -> None:
        """Use a real navigation control; practice has its own compact header."""
        page = page or self.page
        if page.locator('#landing').is_visible():
            self.enter('buscar', page)
        if page.locator('#practice-back').is_visible():
            page.locator('#practice-back').click()
        selector = page.locator('#mobile-tool-select')
        if selector.is_visible():
            selector.select_option(tab)
        else:
            page.locator(f'#tab-{tab}').click()
        page.wait_for_function("screen => HanYuMatizP10.inspect().screen === screen", arg=tab)

    def practice_menu(self, page=None, opened=True) -> None:
        page = page or self.page
        visible = page.locator('#practice-menu').is_visible()
        if opened and not visible:
            page.locator('#practice-menu-open').click()
        elif not opened and visible:
            page.keyboard.press('Escape')

    def capture(self, page, filename: str, full_page=False, locator=None, native=False) -> None:
        if not self.screenshots:
            return
        self.screenshots.mkdir(parents=True, exist_ok=True)
        preview = self.screenshots / filename
        if native:
            # Playwright's CSS viewport clip crops a native-zoom screenshot
            # in this Chromium. CDP captures the complete rendered surface.
            protocol = page.context.new_cdp_session(page)
            try:
                result = protocol.send('Page.captureScreenshot', {'format': 'png', 'fromSurface': True, 'captureBeyondViewport': False})
                preview.write_bytes(base64.b64decode(result['data']))
            finally:
                protocol.detach()
        elif locator is not None:
            locator.screenshot(path=str(preview), animations='disabled')
        else:
            page.screenshot(path=str(preview), full_page=full_page, animations='disabled')
        path = str(preview.relative_to(ROOT)) if preview.is_relative_to(ROOT) else str(preview)
        if path not in self.previews:
            self.previews.append(path)

    def check(self, label: str, action) -> None:
        try:
            action()
            self.results.append({"check": label, "passed": True})
            print(f"OK  {label}")
        except Exception as error:
            self.results.append({"check": label, "passed": False, "error": str(error)})
            print(f"ERROR  {label}: {error}", file=sys.stderr)
            traceback.print_exc(limit=2)

    def startup(self) -> None:
        page = self.page
        state = self.inspect()
        for field, collection in (("words", "words"), ("contrasts", "contrasts"), ("scenarios", "scenarios"), ("exercises", "exercises")):
            require(state[field] == len(self.data[collection]), f"Contador incorrecto: {field}")
        require(state["attempts"] == 0, "La sesión inicial debe estar vacía")
        require(not state["saved"], "El guardado debe ser opcional")
        require(state["screen"] == "inicio", "Sin enlace directo, la aplicación debe abrir en la portada")
        require(self.data == json.loads((ROOT / 'data/vocabulary.json').read_text(encoding='utf-8')), 'El documento compilado altera el banco lingüístico')
        require(page.locator("#landing").is_visible(), "Falta la portada inicial")
        require(not page.locator("#app-shell").is_visible(), "La aplicación aparece antes de elegir una entrada")
        page.locator('a[href="#primeros-pasos"]').first.click()
        page.wait_for_function("""() => {const rect = document.getElementById('primeros-pasos').getBoundingClientRect();
          const target = Math.min(rect.top + scrollY, document.documentElement.scrollHeight - innerHeight);
          return scrollY >= target - 1 && rect.bottom > 0; }""")
        require(page.locator("#landing").is_visible(), "Cómo funciona sale de la portada en vez de explicar el uso")
        self.enter()
        require(not self.errors, "Errores al arrancar: " + "; ".join(self.errors))

    def demonstration(self) -> None:
        """Check the contextual choice and its own comparison, without saving it."""
        page = self.page
        self.home()
        scenario = next(scene for scene in self.data["scenarios"] if scene["id"] == "scn_p5_004")
        initial_state = self.inspect()
        initial_hash = page.evaluate("location.hash")
        initial_storage = page.evaluate("() => Object.fromEntries(Object.keys(localStorage).sort().map(key => [key, localStorage.getItem(key)]))") if self.storage_available else None
        choices = page.locator('[data-demo-word]')
        check = page.locator("#demo-check")
        retry = page.locator("#demo-retry")
        feedback = page.locator("#landing-demo-note")

        def sentence() -> str:
            return page.locator("#landing-demo-sentence").evaluate("node => {const copy = node.cloneNode(true); copy.querySelectorAll('rt').forEach(rt => rt.remove()); return copy.textContent;}")

        def require_blank() -> None:
            text = sentence()
            require(text.startswith("这件外套") and text.endswith("你。"), "La demostración no usa la situación real de la prenda")
            require(scenario["a"] not in text and scenario["b"] not in text, "La demostración empieza con la respuesta ya elegida")
            require(page.locator("#landing-demo-sentence .demo-blank, #landing-demo-sentence .demo-placeholder").count() == 1, "Falta el espacio visible para completar la frase")
            require(choices.evaluate_all("nodes => nodes.map(node => node.getAttribute('aria-pressed'))") == ["false", "false"], "La demostración no deja ambas opciones sin seleccionar")
            require(check.is_visible() and check.is_disabled(), "La comprobación inicial debe esperar una elección")
            require(not feedback.is_visible(), "La explicación se muestra antes de comprobar")
            require(not retry.is_visible() and not page.locator("#demo-continue").is_visible(), "Las acciones de continuación aparecen antes de responder")

        def require_no_history_change() -> None:
            state = self.inspect()
            require(state["attempts"] == initial_state["attempts"] and state["saved"] == initial_state["saved"], "La demostración modifica el progreso de práctica")
            require(page.evaluate("location.hash") == initial_hash, "Elegir o comprobar en la portada cambia de ruta")
            if self.storage_available:
                actual_storage = page.evaluate("() => Object.fromEntries(Object.keys(localStorage).sort().map(key => [key, localStorage.getItem(key)]))")
                require(actual_storage == initial_storage, "La demostración escribe datos de progreso en el navegador")

        require_blank()
        require(choices.count() == 2, "La demostración debe ofrecer exactamente las dos palabras del contraste")
        require(page.locator("#landing-demo-translation").inner_text() == scenario["translation"], "La traducción de la demostración difiere del contenido")
        for choice in ("a", "b"):
            button = page.locator(f'[data-demo-word="{choice}"]')
            require(scenario[choice] in button.inner_text(), "Las opciones de la demostración no corresponden al contraste")
            pinyin = "".join(item["pinyin"] for item in self.data["phonetics"][scenario["id"]][choice])
            require(pinyin in button.inner_text(), "Una opción de la demostración carece de la pronunciación real")
            button.click()
            require(choices.evaluate_all("nodes => nodes.map(node => node.getAttribute('aria-pressed'))") == (["true", "false"] if choice == "a" else ["false", "true"]), "La selección de la demostración no es exclusiva")
            require(sentence() == scenario["sentence"].replace("〔词〕", scenario[choice]), "Elegir una palabra no completa la frase correcta")
            require(check.is_enabled(), "La elección no habilita la comprobación")
            require(not feedback.is_visible(), "La selección revela la explicación antes de comprobar")
        check.click()
        require(feedback.is_visible(), "Comprobar no revela la explicación")
        require(page.locator("#demo-feedback-title").inner_text() == "适合 encaja aquí.", "La respuesta adecuada no explica el resultado")
        require(page.locator("#demo-feedback-title").evaluate("node => document.activeElement === node"), "Comprobar no mueve el foco a la explicación")
        require(scenario["note_b"] in page.locator("#demo-feedback-text").inner_text(), "La explicación correcta no procede de la situación real")
        require(choices.evaluate_all("nodes => nodes.every(node => node.disabled)"), "La demostración permite cambiar una respuesta ya comprobada")
        require(not check.is_visible() and retry.is_visible() and page.locator("#demo-continue").is_visible(), "Faltan las acciones después de responder")
        require_no_history_change()
        retry.click()
        require_blank()
        require(choices.first.evaluate("node => document.activeElement === node"), "Reintentar no devuelve el foco a la primera opción")
        # Enter verifies the same native button flow without a pointer.
        choices.first.press("Enter")
        check.press("Enter")
        require(page.locator("#demo-feedback-title").inner_text() == "Con 合适 cambia la frase.", "La reformulación se presenta como un error genérico")
        explanation = page.locator("#demo-feedback-text").inner_text()
        require(scenario["note_a"] in explanation and "这件外套对你来说很合适。" in explanation, "La explicación omite la reformulación que permite usar 合适")
        require_no_history_change()
        page.locator("#demo-continue").click()
        page.wait_for_function("() => location.hash === '#practicar' && HanYuMatizP10.inspect().screen === 'practicar'")
        require(page.locator("#exercise h3").evaluate("node => document.activeElement === node"), "Continuar desde la demostración no lleva el foco a la pregunta")
        require(self.inspect()["attempts"] == initial_state["attempts"], "Entrar a práctica cuenta la demostración como un intento")
        self.home()
        retry.click()
        require_blank()
        pair = next(pair for pair in self.data["contrasts"] if pair["id"] == scenario["contrast_id"])
        require(page.locator("#preview-pairs").count() == 0, "El antiguo catálogo de muestra sigue ocupando la portada")
        page.locator("#demo-comparison").click()
        page.wait_for_function("() => location.hash === '#comparar' && HanYuMatizP10.inspect().screen === 'comparar'")
        require(page.locator("#pair-detail .contrast-sign strong").all_text_contents() == [pair["a"], pair["b"]], "El enlace de la demostración no abre su propio contraste 合适/适合")
        require(page.locator("#h-comparar").evaluate("node => document.activeElement === node"), "Entrar al contraste de la demostración pierde el foco")
        page.evaluate("history.back()")
        page.wait_for_function("() => location.hash === '#inicio' && HanYuMatizP10.inspect().screen === 'inicio'")
        require(page.locator("#landing-title").evaluate("node => document.activeElement === node"), "Volver del contraste pierde el foco de la portada")
        self.enter()

    def dictionary(self) -> None:
        page = self.page
        self.navigate("buscar")
        page.fill("#word-search", self.data["words"][0]["zh"])
        page.fill("#word-search", "")
        seen = []
        for word in self.data["words"]:
            actual = page.locator(".lex-glyph-zh").evaluate("node => {const copy=node.cloneNode(true);copy.querySelectorAll('rt').forEach(n=>n.remove());return copy.textContent;}")
            require(actual == word["zh"], f"Paginación: se esperaba {word['zh']}, aparece {actual}")
            seen.append(actual)
            page.click("#lex-entry-next")
        require(len(set(seen)) == len(self.data["words"]), "La paginación repite entradas antes de cerrar el recorrido")
        require(page.locator(".lex-glyph-zh").evaluate("node => {const copy=node.cloneNode(true);copy.querySelectorAll('rt').forEach(n=>n.remove());return copy.textContent;}") == self.data["words"][0]["zh"], "La paginación no vuelve al inicio")
        page.click("#lex-entry-prev")
        require(page.locator(".lex-glyph-zh").evaluate("node => {const copy=node.cloneNode(true);copy.querySelectorAll('rt').forEach(n=>n.remove());return copy.textContent;}") == self.data["words"][-1]["zh"], "Anterior no vuelve a la última entrada")
        page.click("#lex-entry-next")
        for query in ("觉得", "juede", "juéde", "jue de", "jue2de5"):
            page.fill("#word-search", query)
            require(page.locator(".lex-result-word").all_text_contents() == ["觉得"], f"La búsqueda {query!r} no encuentra 觉得")
        page.click("#lex-entry-next")
        require(page.locator("#word-search").input_value() == "", "El paginador no limpia el filtro")
        word_index = next(i for i, word in enumerate(self.data["words"]) if word["zh"] == "觉得")
        expected_next = self.data["words"][(word_index + 1) % len(self.data["words"])]["zh"]
        require(page.locator(".lex-glyph-zh").evaluate("node => {const copy=node.cloneNode(true);copy.querySelectorAll('rt').forEach(n=>n.remove());return copy.textContent;}") == expected_next, "Siguiente quedó atrapado en los resultados de búsqueda")
        page.fill("#word-search", "considerar")
        require("认为" in page.locator(".lex-result-word").all_text_contents(), "Falla la búsqueda por significado español")
        page.fill("#word-search", "completamenteinexistente")
        require(page.locator("#word-detail .empty").count() == 1, "Falta el estado vacío del diccionario")
        page.fill("#word-search", "")
        if page.locator("#lex-browse").get_attribute("aria-expanded") != "true":
            page.click("#lex-browse")
        require(page.locator(".lex-result").count() == len(self.data["words"]), "El índice no muestra todas las palabras")
        page.locator(".lex-result").nth(1).click()
        require(page.locator("#lex-entry-next").evaluate("node => document.activeElement === node"), "Se pierde el foco al elegir una entrada")

    def landing_search(self) -> None:
        """Use the cover's real search, including its keyboard and empty flows."""
        page = self.page
        initial_attempts = self.inspect()["attempts"]
        initial_saved = self.inspect()["saved"]
        initial_storage = page.evaluate("() => Object.fromEntries(Object.keys(localStorage).sort().map(key => [key, localStorage.getItem(key)]))") if self.storage_available else None
        for query, expected, method in (
            ("  觉得  ", "觉得", "submit"),
            ("juéde", "觉得", "keyboard"),
            ("jue2de5", "觉得", "keyboard"),
            ("considerar", "认为", "submit"),
            ("completamenteinexistente", None, "keyboard"),
            ("   ", None, "submit"),
        ):
            self.home()
            field = page.locator("#landing-search")
            require(field.is_visible(), "La portada no ofrece un buscador de vocabulario visible")
            require(field.get_attribute("maxlength") == "120", "El buscador de portada no limita la consulta")
            field.fill(query)
            if method == "keyboard":
                field.press("Enter")
            else:
                page.locator("#landing-search-submit").click()
            page.wait_for_function("() => location.hash === '#buscar' && HanYuMatizP10.inspect().screen === 'buscar'")
            require(page.locator("#view-buscar").is_visible() and not page.locator("#landing").is_visible(), "Buscar desde la portada no abre el diccionario")
            require(page.locator("#word-search").input_value() == query.strip(), "La búsqueda de portada no conserva la consulta en el diccionario")
            if expected is not None:
                require(expected in page.locator(".lex-result-word").all_text_contents(), f"La búsqueda de portada {query!r} no encuentra {expected}")
                require(page.locator(".lex-definition-main").evaluate("node => document.activeElement === node"), "Una búsqueda con resultados pierde el foco de su definición")
                self.require_heading_in_view(".lex-definition-main")
            elif query.strip():
                require(page.locator("#word-detail .empty").count() == 1 and page.locator(".lex-result").count() == 0, "La búsqueda de portada sin coincidencias no presenta el estado vacío")
                require(page.locator("#word-search").evaluate("node => document.activeElement === node"), "Una búsqueda sin coincidencias no permite corregir la consulta con el teclado")
            else:
                require(page.locator(".lex-result").count() == len(self.data["words"]), "Abrir el diccionario sin consulta omite entradas")
                require(page.locator("#word-search").evaluate("node => document.activeElement === node"), "La consulta vacía no enfoca el buscador del diccionario")
            state = self.inspect()
            require(state["attempts"] == initial_attempts and state["saved"] == initial_saved, "La búsqueda de portada modifica el progreso de práctica")
            self.landing_queries.append({"query": query.strip(), "input": method, "passed": True})
        self.home()
        examples = page.locator("[data-landing-query]")
        require(examples.count() > 0, "La portada no ofrece un ejemplo que se pueda buscar")
        example_queries = examples.evaluate_all("nodes => nodes.map(node => node.dataset.landingQuery)")
        for index, query in enumerate(example_queries):
            page.locator("[data-landing-query]").nth(index).click()
            page.wait_for_function("() => location.hash === '#buscar' && HanYuMatizP10.inspect().screen === 'buscar'")
            require(page.locator("#word-search").input_value() == query.strip(), "Un ejemplo de portada no ejecuta su consulta real")
            require(page.locator(".lex-result").count() > 0, f"El ejemplo {query!r} de la portada no encuentra vocabulario")
            self.landing_queries.append({"query": query.strip(), "input": "example", "passed": True})
            self.home()
        if self.storage_available:
            actual_storage = page.evaluate("() => Object.fromEntries(Object.keys(localStorage).sort().map(key => [key, localStorage.getItem(key)]))")
            require(actual_storage == initial_storage, "Consultar vocabulario desde la portada escribe datos de progreso")
        self.enter()

    def comparisons(self) -> None:
        page = self.page
        self.navigate("comparar")
        page.fill("#pair-search", "")
        for index, pair in enumerate(self.data["contrasts"]):
            page.click("#pair-browse")
            require(page.locator(".contrast-result").count() == len(self.data["contrasts"]), "El catálogo omite comparaciones")
            page.locator(".contrast-result").nth(index).click()
            require(page.locator("#pair-detail .contrast-sign strong").all_text_contents() == [pair["a"], pair["b"]], f"Contraste incorrecto: {pair['a']}/{pair['b']}")
            require(page.locator("#h-comparar").evaluate("node => document.activeElement === node"), "Se pierde el foco al elegir un contraste")
            meanings = page.locator("#pair-detail .contrast-meaning")
            require(meanings.count() == 2 and meanings.locator(".contrast-meaning-word").all_text_contents() == [pair["a"], pair["b"]], "El comparador no identifica ambas palabras en paralelo")
            require(meanings.locator(".contrast-sense").all_text_contents() == [pair["sense_a"], pair["sense_b"]], "El comparador altera los significados auténticos")
            expected_scenes = [scene for scene in self.data["scenarios"] if scene["contrast_id"] == pair["id"]]
            require(page.locator("#pair-detail .contrast-scene-sentence").all_text_contents() == [scene["sentence"].replace("〔词〕", "…") for scene in expected_scenes], "Los accesos a contexto no muestran las frases reales de este contraste")
        page.fill("#pair-search", "tiao xuan")
        require(any("挑选" in result for result in page.locator(".contrast-result-zh").all_text_contents()), "Comparar no busca por pinyin")
        page.fill("#pair-search", "completamenteinexistente")
        require(page.locator("#pair-detail .empty").count() == 1, "Falta el estado vacío de comparación")
        page.fill("#pair-search", "")

    def contexts(self) -> None:
        page = self.page
        self.navigate("simular")
        picker = page.locator("#scene-picker")
        require(not picker.is_visible(), "El selector de situaciones ocupa la vista antes de abrirlo")
        require(page.locator("#scene-browse").is_visible(), "No hay una acción visible para cambiar de situación")
        for index, scenario in enumerate(self.data["scenarios"]):
            page.click("#scene-browse")
            require(picker.is_visible() and picker.evaluate("node => node.open"), "Cambiar de situación no abre el diálogo nativo")
            require(page.locator("#scene-search").evaluate("node => document.activeElement === node"), "Abrir situaciones no enfoca su buscador")
            require(page.locator("#scene-search").get_attribute("maxlength") == "120", "El buscador no limita la consulta")
            page.fill("#scene-search", "")
            items = page.locator("#scene-list .list-item")
            require(items.count() == len(self.data["scenarios"]), "Faltan situaciones en el selector")
            item = items.nth(index)
            require(item.locator(".scene-item-title").inner_text() == scenario["label"], "La situación no se identifica primero por su nombre en español")
            pair_text = item.locator(".scene-item-pair").inner_text()
            require(scenario["a"] in pair_text and scenario["b"] in pair_text, "La situación no muestra su par de palabras")
            item.focus()
            item.press("Enter")
            require(not picker.is_visible(), "Elegir una situación deja abierto el selector")
            require(page.locator("#scene-detail h3").inner_text() == scenario["label"], "Seleccionar una situación muestra otra")
            require(page.locator("#h-simular").evaluate("node => document.activeElement === node"), "Elegir una situación no devuelve el foco al contenido")
            for choice in ("b", "a"):
                page.click("#scene-swap")
                selected = page.locator("#scene-detail .choice-row button").evaluate_all("nodes => nodes.map(n => n.getAttribute('aria-pressed'))")
                require(selected == (["false", "true"] if choice == "b" else ["true", "false"]), "Intercambiar no cambia la opción activa")
                sentence = page.locator("#scene-detail .sentence-box").evaluate("node => {const copy = node.cloneNode(true); copy.querySelectorAll('rt').forEach(rt => rt.remove()); return copy.textContent;}")
                require(scenario[choice] in sentence, "La frase no refleja la sustitución")
                require(page.locator("#scene-swap").evaluate("node => document.activeElement === node"), "Intercambiar pierde el foco")
                analysis = page.locator("#scene-detail .context-analysis")
                if analysis.count() and analysis.get_attribute("open") is None:
                    analysis.locator("summary").click()
                versions = page.locator("#scene-detail .context-version")
                require(versions.count() == 2, "La situación no permite comparar las dos versiones")
                for version_index, word_key in enumerate(("a", "b")):
                    version = versions.nth(version_index)
                    require(version.locator(".context-version-word").inner_text() == scenario[word_key], "Una versión de contexto identifica otra palabra")
                    version_sentence = version.locator(".context-version-sentence").evaluate("node => {const copy=node.cloneNode(true);copy.querySelectorAll('rt').forEach(rt=>rt.remove());return copy.textContent;}")
                    require(version_sentence == scenario["sentence"].replace("〔词〕", scenario[word_key]), "La comparación de contexto cambia la oración de los datos")
                    require(version.locator(".context-version-note").inner_text() == scenario[f"note_{word_key}"], "La nota de una versión corresponde a otra opción")
        selected_label = page.locator("#scene-detail h3").inner_text()
        selected_sentence = page.locator("#scene-detail .sentence-box").inner_text()
        page.click("#scene-browse")
        page.fill("#scene-search", "tiao xuan")
        require(page.locator("#scene-list .list-item").count() > 0, "En contexto no busca por pinyin")
        require(page.locator("#scene-detail h3").inner_text() == selected_label, "Filtrar cambia la situación elegida antes de confirmarla")
        page.fill("#scene-search", "completamenteinexistente")
        require(page.locator("#scene-list .list-item").count() == 0 and page.locator("#scene-list .empty").count() == 1, "Falta el estado vacío dentro del selector de situaciones")
        require(page.locator("#scene-detail .empty").count() == 0, "Una búsqueda vacía borra la situación que ya estaba seleccionada")
        require(page.locator("#scene-detail h3").inner_text() == selected_label and page.locator("#scene-detail .sentence-box").inner_text() == selected_sentence, "Una búsqueda sin resultados cambia la situación actual")
        page.click("#scene-picker-close")
        require(not picker.is_visible(), "Cerrar no oculta el selector de situaciones")
        require(page.locator("#scene-browse").evaluate("node => document.activeElement === node"), "Cerrar el selector no devuelve el foco a su botón")
        page.click("#scene-browse")
        page.fill("#scene-search", "tiao xuan")
        page.keyboard.press("Escape")
        require(not picker.is_visible(), "Escape no cierra el selector de situaciones")
        require(page.locator("#scene-browse").evaluate("node => document.activeElement === node"), "Escape no devuelve el foco a su botón")
        require(page.locator("#scene-detail h3").inner_text() == selected_label and page.locator("#scene-detail .sentence-box").inner_text() == selected_sentence, "Cancelar el selector modifica la situación o la palabra elegida")
        page.click("#scene-browse")
        page.fill("#scene-search", "")
        page.locator("#scene-list .list-item").last.focus()
        page.keyboard.press("Tab")
        # Native Chromium dialogs can give the browser chrome a focus stop
        # between the last and first controls; this reports body as active.
        # A background link or input must never become active, and the next
        # Tab must return to the modal when that browser stop is encountered.
        require(picker.evaluate("node => node.contains(document.activeElement) || document.activeElement === document.body"), "El teclado escapa del selector modal hacia un control de fondo")
        if not picker.evaluate("node => node.contains(document.activeElement)"):
            page.keyboard.press("Tab")
        require(picker.evaluate("node => node.contains(document.activeElement)"), "El recorrido del teclado no vuelve a los controles del selector")
        page.mouse.click(5, 5)
        require(not picker.is_visible(), "Tocar fuera del selector no lo cierra")
        require(page.locator("#scene-browse").evaluate("node => document.activeElement === node"), "Cerrar desde el fondo no devuelve el foco a su botón")
        require(page.locator("#scene-detail h3").inner_text() == selected_label, "Cerrar desde el fondo cambia la situación")
        page.click("#scene-browse")
        page.evaluate("history.back()")
        page.wait_for_function("() => location.hash === '#comparar' && HanYuMatizP10.inspect().screen === 'comparar'")
        require(not picker.is_visible(), "El selector queda abierto sobre otra vista al retroceder")
        require(page.locator("#h-comparar").evaluate("node => document.activeElement === node"), "Retroceder desde el selector deja el foco en una vista oculta")
        page.evaluate("history.forward()")
        page.wait_for_function("() => location.hash === '#simular' && HanYuMatizP10.inspect().screen === 'simular'")
        require(page.locator("#scene-detail h3").inner_text() == selected_label, "Avanzar en el historial pierde la situación elegida")

    def navigation(self) -> None:
        page = self.page
        require(page.locator(".tabs").get_attribute("aria-orientation") == "horizontal", "La navegación superior no declara su orientación horizontal")
        for tab in TABS:
            self.navigate(tab)
            require(page.locator(".skip-link").get_attribute("href") == f"#h-{tab}", "El enlace para saltar al contenido apunta a otro panel")
            require(page.locator(f"#tab-{tab}").get_attribute("aria-selected") == "true", "Pestaña activa sin estado accesible")
            require(page.locator(".view:visible").count() == 1, "Hay varios paneles visibles")
        page.locator("#practice-back").click()
        page.locator("#tab-buscar").focus()
        page.keyboard.press("ArrowRight")
        require(page.locator("#tab-comparar").evaluate("node => document.activeElement === node"), "Flecha derecha no navega entre pestañas")
        page.keyboard.press("ArrowLeft")
        require(page.locator("#tab-buscar").evaluate("node => document.activeElement === node"), "Flecha izquierda no vuelve a la pestaña anterior")
        page.keyboard.press("ArrowLeft")
        require(page.locator("#tab-aprender").evaluate("node => document.activeElement === node"), "Flecha izquierda no abre Aprender")
        page.keyboard.press("ArrowLeft")
        require(page.locator("#exercise h3").evaluate("node => document.activeElement === node"), "Activar práctica con flechas deja el foco en navegación oculta")
        page.locator("#practice-back").click()
        page.locator("#tab-practicar").focus()
        page.keyboard.press("ArrowRight")
        require(page.locator("#tab-aprender").evaluate("node => document.activeElement === node"), "Flecha derecha no recorre la navegación desde la última pestaña")
        page.keyboard.press("End")
        require(page.locator("#tab-practicar").get_attribute("aria-selected") == "true" and page.locator("#exercise h3").evaluate("n => document.activeElement === n"), "End no entra en práctica con foco visible")
        page.locator("#practice-back").click()
        page.locator("#tab-practicar").focus()
        page.keyboard.press("Home")
        require(page.locator("#tab-aprender").get_attribute("aria-selected") == "true", "Home no selecciona la primera pestaña")
        self.home()
        self.enter("comparar")
        page.locator("#app-shell .brand").click()
        require(page.locator("#landing").is_visible(), "La marca no permite volver a la portada")
        self.enter("practicar")
        for direction, expected in (("back", "inicio"), ("back", "comparar"), ("forward", "inicio"), ("forward", "practicar")):
            page.evaluate(f"history.{direction}()")
            page.wait_for_function("screen => location.hash === '#' + screen && HanYuMatizP10.inspect().screen === screen", arg=expected)
            target = "#landing-title" if expected == "inicio" else "#exercise h3" if expected == "practicar" else f"#h-{expected}"
            require(page.locator(target).is_visible(), f"El historial no muestra {expected}")
            require(page.locator(target).evaluate("node => document.activeElement === node"), f"El historial deja el foco en una vista anterior a {expected}")
            if expected != "inicio":
                self.require_heading_in_view(target)
        for tab in TABS:
            linked = self.new_page(initial_hash=f"#{tab}")
            require(self.inspect(linked)["screen"] == tab, f"El enlace directo a {tab} no abre su panel")
            require(linked.locator(f"#view-{tab}").is_visible(), f"El enlace directo a {tab} deja el contenido oculto")
            require(not linked.locator("#landing").is_visible(), "El enlace directo deja visible la portada")
            linked.close()

    def practice_and_storage(self) -> None:
        """Answer, review and retry without double counting local progress."""
        page = self.page
        self.navigate('practicar')
        expected_ids = self.inspect()['sessionIds']
        require(len(expected_ids) == 8, 'La sesión general no contiene ocho preguntas reales')
        by_id = {exercise['id']: exercise for exercise in self.data['exercises']}
        by_scenario = {scene['id']: scene for scene in self.data['scenarios']}
        require(page.locator('#session-map .session-step').evaluate_all('nodes => nodes.map(n => n.dataset.exerciseId)') == expected_ids, 'El mapa no representa la sesión programada')
        require(page.locator('#session-map .session-step:disabled').count() == 7, 'El mapa permite saltar a preguntas pendientes')
        self.practice_menu()
        progress = page.locator('.study-progress')
        if progress.get_attribute('open') is None:
            progress.locator('summary').click()
        if self.storage_available:
            page.locator('#save').click()
            require(self.inspect()['saved'], 'El guardado opcional no se activa')
        else:
            require(page.locator('#save').is_disabled(), 'Guardar queda activo sin almacenamiento')
        self.practice_menu(opened=False)

        def without_pinyin(locator):
            return locator.evaluate("node => {const n=node.cloneNode(true);n.querySelectorAll('rt').forEach(rt=>rt.remove());return n.textContent;}")

        def snapshot():
            return page.evaluate("() => Object.fromEntries(Object.keys(localStorage).sort().map(k => [k,localStorage.getItem(k)]))") if self.storage_available else None

        def comparison(exercise):
            scene = by_scenario[exercise['scenario_id']]
            require(page.locator('#practice-feedback .answer-version').count() == 2, 'La explicación omite una versión de la frase')
            for key in ('a', 'b'):
                version = page.locator(f'#practice-feedback .answer-version[data-choice="{key}"]')
                require(scene['sentence'].replace('〔词〕', scene[key]) in without_pinyin(version), 'Una versión cambia la oración auténtica')
                require(scene[f'note_{key}'] in version.text_content(), 'La nota de una versión cambia el contenido lingüístico')
            require(scene['comparison'] in page.locator('#practice-feedback').text_content(), 'La explicación omite la comparación original')

        missed = by_id[expected_ids[0]]
        for index, exercise_id in enumerate(expected_ids):
            exercise = by_id[exercise_id]
            scene = by_scenario[exercise['scenario_id']]
            require(page.locator('#session-position').text_content() == f'Pregunta {index+1} de {len(expected_ids)}', 'El encabezado indica otra pregunta')
            require(page.locator('#bar').evaluate('n => n.parentElement.getAttribute("aria-valuenow")') == str(index), 'El progreso accesible no coincide con respuestas completadas')
            require(page.locator('#exercise h3.practice-scenario').inner_text() == exercise['prompt_es'], 'La práctica cambia el objetivo auténtico')
            require(page.locator('#exercise .intent').text_content() == exercise['intent_es'], 'La práctica altera el contexto auténtico')
            require(page.locator('#session-map .session-step.current').get_attribute('data-exercise-id') == exercise_id, 'El mapa marca otra pregunta')
            options = page.locator('#exercise .option')
            require(options.count() == len(exercise['options']), 'Falta una opción auténtica')
            for option, button in zip(exercise['options'], options.all()):
                require(option['label'] in without_pinyin(button), 'El control presenta otra respuesta')
            require(page.locator('#practice-check').is_disabled(), 'Comprobar se habilita antes de seleccionar')
            require(page.locator('#practice-feedback').count() == 0, 'La corrección aparece antes de contestar')
            correct = next(i for i, option in enumerate(exercise['options']) if option['key'] == exercise['answer_key'])
            chosen = next(i for i, option in enumerate(exercise['options']) if option['key'] != exercise['answer_key']) if index == 0 else correct
            key = exercise['options'][chosen]['key']
            if index == 0:
                page.locator('#h-practicar').focus()
                page.keyboard.press(str(chosen + 1))
            else:
                options.nth(chosen).click()
            require(options.nth(chosen).get_attribute('aria-pressed') == 'true', 'Seleccionar no informa su estado')
            selected_words = (scene['a'], scene['b']) if key == 'both' else (scene[key],)
            require(all(word in without_pinyin(page.locator('#practice-sentence .practice-sentence-slot')) for word in selected_words), 'La selección no permite probar la frase')
            require(self.inspect()['attempts'] == index, 'Seleccionar registra un intento sin comprobar')
            if index == 0:
                self.practice_menu()
                progress.locator('summary').focus()
                page.keyboard.press('Enter')
                require(progress.get_attribute('open') is None, 'Enter no cierra el detalle de progreso')
                page.keyboard.press('Enter')
                require(progress.get_attribute('open') is not None, 'Enter no abre el detalle de progreso')
                require(self.inspect()['attempts'] == 0 and page.locator('#practice-feedback').count() == 0, 'Usar el menú comprueba una respuesta')
                page.keyboard.press('Escape')
                require(page.locator('#practice-menu-open').evaluate('n => document.activeElement === n'), 'Cerrar el menú pierde el foco')
                page.locator('#practice-translation').click()
                require(page.locator('#practice-translation').get_attribute('aria-pressed') == 'true', 'La ayuda de traducción no declara su estado')
                require(page.locator('#exercise .practice-translation').inner_text() == scene['translation'], 'La ayuda cambia la traducción')
                page.locator('#practice-pinyin').click()
                readings = page.locator('#practice-sentence rt')
                require(readings.count() > 0 and readings.first.is_visible(), 'La ayuda de pinyin no muestra lecturas')
                expected = ''.join(part['pinyin'] for word_key in (('a', 'b') if key == 'both' else (key,)) for part in self.data['phonetics'][scene['id']][word_key])
                require(''.join(readings.all_text_contents()).replace(' ', '') == expected, 'La ayuda cambia el pinyin auténtico')
                page.locator('#practice-pinyin').click()
                page.locator('#practice-translation').click()
                require(not readings.first.is_visible() and not page.locator('#exercise .practice-translation').is_visible(), 'Las ayudas no se pueden ocultar')
                page.locator('#h-practicar').focus()
                page.keyboard.press('Enter')
            else:
                page.locator('#practice-check').click()
            require(self.inspect()['attempts'] == index + 1, 'Comprobar no registra exactamente un intento')
            require(page.locator('#m-matches').text_content() == str(index), 'Las coincidencias no reflejan la clave real')
            require(page.locator('#practice-feedback .practice-feedback-title').evaluate('n => document.activeElement === n'), 'Comprobar no enfoca el resultado')
            require(page.locator('#exercise .option:enabled').count() == 0, 'Se puede contestar dos veces la misma pregunta')
            comparison(exercise)
            require(page.locator(f'#session-map .session-step[data-exercise-id="{exercise_id}"]').evaluate("n => n.classList.contains('answered')"), 'El mapa pierde una respuesta')
            if index == 0:
                detail = page.locator('#practice-feedback .practice-full-explanation')
                require(detail.get_attribute('open') is None, 'La explicación extensa se abre sin pedirla')
                detail.locator('summary').focus()
                page.keyboard.press('Enter')
                require(detail.get_attribute('open') is not None and detail.locator('.practice-explanation').inner_text() == exercise['explanation_es'], 'El teclado no revela la explicación auténtica')
                page.keyboard.press('Enter')
                require(detail.get_attribute('open') is None and self.inspect()['attempts'] == 1, 'Cerrar la explicación contesta o avanza')
                self.practice_menu()
                page.locator('#session-map .session-step').nth(1).click()
                self.practice_menu(opened=False)
                require(page.locator('#practice-check').is_disabled() and page.locator('#practice-feedback').count() == 0, 'Cambiar a la pendiente arrastra el resultado anterior')
                self.practice_menu()
                page.locator('#session-map .session-step').first.click()
                self.practice_menu(opened=False)
                comparison(exercise)
                require(self.inspect()['attempts'] == 1, 'Revisar duplica intentos')
            page.locator('#practice-next').click()
        require(page.locator('#exercise .session-result').count() == 8, 'Resultados omite preguntas reales')
        require(page.locator('#m-scenes').text_content() == '8', 'La sesión duplica situaciones')
        require(page.locator('#exercise .practice-summary-title').is_visible(), 'La pantalla final no muestra resultados')
        summary_storage = snapshot()
        page.locator(f'#exercise .session-result[data-exercise-id="{missed["id"]}"]').click()
        comparison(missed)
        require(self.inspect()['attempts'] == 8, 'Revisar resultados registra otro intento')
        self.practice_menu()
        page.locator(f'#session-map .session-step[data-exercise-id="{expected_ids[-1]}"]').click()
        self.practice_menu(opened=False)
        page.locator('#practice-next').click()
        require(self.inspect()['attempts'] == 8 and snapshot() == summary_storage, 'Revisar altera progreso guardado')
        page.locator('#practice-retry-missed').click()
        require(self.inspect()['sessionIds'] == [missed['id']], 'El repaso incluye preguntas acertadas')
        correct = next(i for i, option in enumerate(missed['options']) if option['key'] == missed['answer_key'])
        page.locator('#exercise .option').nth(correct).click()
        require(self.inspect()['attempts'] == 8, 'Elegir en repaso registra un intento')
        page.locator('#practice-check').click()
        require(self.inspect()['attempts'] == 9 and page.locator('#m-matches').text_content() == '8', 'El repaso no registra exactamente una respuesta nueva')
        comparison(missed)
        page.locator('#practice-next').click()
        require(page.locator('#exercise .session-result').count() == 1, 'El resultado del repaso pierde su pregunta')
        require(page.locator('#practice-retry-missed').count() == 0 or not page.locator('#practice-retry-missed').is_visible(), 'Ofrece fallos cuando todo coincide')
        reloaded = self.new_page()
        state = self.inspect(reloaded)
        require(state['attempts'] == (9 if self.storage_available else 0) and state['saved'] == self.storage_available, 'Recargar no respeta la opción de guardado')
        self.enter('practicar', reloaded)
        self.practice_menu(reloaded)
        details = reloaded.locator('.study-progress')
        if details.get_attribute('open') is None:
            details.locator('summary').click()
        reloaded.locator('#forget').click()
        require(reloaded.locator('#forget-confirm').is_visible(), 'Borrar no permite revisar la decisión')
        reloaded.locator('#forget-cancel').click()
        require(self.inspect(reloaded)['attempts'] == state['attempts'], 'Cancelar borrado pierde progreso')
        reloaded.locator('#forget').click()
        reloaded.locator('#forget-accept').click()
        require(self.inspect(reloaded)['attempts'] == 0 and not self.inspect(reloaded)['saved'], 'Borrar no reinicia el historial')
        reloaded.close()
        page.close()
        self.page = self.new_page()
        self.enter()

    def reduced_motion(self) -> None:
        page = self.new_page(reduced_motion=True)
        try:
            require(page.evaluate("matchMedia('(prefers-reduced-motion: reduce)').matches"), "No se pudo simular la preferencia de movimiento reducido")
            require(page.locator(".hero-copy").evaluate("node => getComputedStyle(node).animationName === 'none'"), "La portada conserva animaciones con la preferencia de movimiento reducido")
            page.locator('[data-demo-word="b"]').click()
            require(page.locator('[data-demo-word="b"]').get_attribute("aria-pressed") == "true", "La demostración deja de funcionar con movimiento reducido")
            page.locator("#demo-check").click()
            require(page.locator("#landing-demo-note").is_visible(), "La comprobación deja de funcionar con movimiento reducido")
            page.locator("#demo-retry").click()
            require(page.locator("#demo-check").is_disabled(), "Reintentar con movimiento reducido no reinicia la respuesta")
            self.enter("buscar", page)
            self.navigate("simular", page)
            page.click("#scene-swap")
            require(page.locator("#scene-detail .choice-row button").nth(1).get_attribute("aria-pressed") == "true", "Cambiar la palabra falla con movimiento reducido")
            self.home(page)
        finally:
            page.close()

    def curriculum(self) -> None:
        """Use difficulty filters and real lessons without inventing HSK levels."""
        page = self.page
        self.navigate('aprender')
        exercises = self.data['exercises']
        scenes = {scene['id']: scene for scene in self.data['scenarios']}
        pairs = {pair['id']: pair for pair in self.data['contrasts']}
        level = page.locator('#learn-level')
        require(level.is_visible() and level.evaluate('n => n.tagName') == 'SELECT', 'La dificultad no se puede elegir directamente')
        require(set(level.locator('option').evaluate_all('nodes => nodes.map(n => n.value)')) == {'all', 'inicial', 'intermedio', 'avanzado'}, 'El filtro no distingue las dificultades reales')
        require(not re.search(r'HSK\s*[1-6]', level.inner_text(), re.I), 'Las dificultades se presentan como niveles HSK no validados')
        for difficulty in ('inicial', 'intermedio', 'avanzado', 'all'):
            level.select_option(difficulty)
            eligible = [ex for ex in exercises if difficulty == 'all' or ex['difficulty'] == difficulty]
            expected_scenes = {ex['scenario_id'] for ex in eligible}
            expected_units = {scenes[sid]['contrast_id'] for sid in expected_scenes}
            units = page.locator('#learn-unit-list [data-learn-unit]')
            actual_units = set(units.evaluate_all('nodes => nodes.map(n => n.dataset.learnUnit)'))
            require(actual_units <= set(pairs), 'Aprender inventa una unidad sin contraste real')
            require(expected_units <= actual_units, f'Aprender omite unidades de {difficulty}')
            visible_lessons = set()
            for unit_id in expected_units:
                page.locator(f'#learn-unit-list [data-learn-unit="{unit_id}"]').click()
                buttons = page.locator('#learn-unit-detail [data-start-lesson]')
                ids = set(buttons.evaluate_all('nodes => nodes.map(n => n.dataset.startLesson)'))
                expected = {sid for sid in expected_scenes if scenes[sid]['contrast_id'] == unit_id}
                require(ids == expected, 'Una unidad muestra lecciones inventadas o de otra dificultad')
                visible_lessons |= ids
            require(visible_lessons == expected_scenes, 'El filtro pierde situaciones practicables')
            self.curriculum_cases.append({'difficulty': difficulty, 'units_with_questions': len(expected_units), 'lessons': len(expected_scenes), 'questions': len(eligible), 'passed': True})
        # A real lesson contains two questions from one scenario, counted as
        # two attempts and one distinct situation. Return preserves the filter.
        level.select_option('inicial')
        eligible = [ex for ex in exercises if ex['difficulty'] == 'inicial']
        scene_id = eligible[0]['scenario_id']
        unit_id = scenes[scene_id]['contrast_id']
        page.locator(f'#learn-unit-list [data-learn-unit="{unit_id}"]').click()
        page.locator(f'[data-start-lesson="{scene_id}"]').click()
        require(self.inspect()['screen'] == 'practicar', 'Empezar lección no entra en la actividad')
        expected = {ex['id'] for ex in eligible if ex['scenario_id'] == scene_id}
        require(set(self.inspect()['sessionIds']) == expected and len(expected) == 2, 'La lección cambia sus preguntas auténticas')
        by_id = {ex['id']: ex for ex in exercises}
        before = self.inspect()['attempts']
        for exercise_id in self.inspect()['sessionIds']:
            exercise = by_id[exercise_id]
            key = exercise['answer_key']
            page.locator(f'#exercise .option[data-choice="{key}"]').click()
            page.locator('#practice-check').click()
            page.locator('#practice-next').click()
        require(self.inspect()['attempts'] == before + 2 and page.locator('#exercise .session-result').count() == 2, 'La lección no registra dos respuestas reales')
        page.locator('#practice-back').click()
        require(self.inspect()['screen'] == 'aprender' and level.input_value() == 'inicial', 'Volver de práctica pierde la dificultad elegida')
        require(page.locator(f'#learn-unit-list [data-learn-unit="{unit_id}"]').get_attribute('aria-pressed') == 'true', 'Volver de práctica pierde la unidad')
        level.select_option('all')
        progress_text = page.locator('#learn-progress').inner_text()
        require('1' in progress_text and '15' in progress_text, 'Dos preguntas de una situación inflan el progreso de situaciones')
        self.practice_menu_cleanup(page)

    def practice_menu_cleanup(self, page) -> None:
        """Leave the shared origin with no saved history for independent checks."""
        if self.storage_available:
            page.evaluate("() => Object.keys(localStorage).filter(k => k.startsWith('hanyumatiz:')).forEach(k => localStorage.removeItem(k))")
        page.close()
        self.page = self.new_page()
        self.enter()

    def practice_geometry(self, page, ordinary=False) -> dict:
        """Assert the rendered activity, not CSS declarations or auto-scroll."""
        metrics = page.evaluate("""() => {
          const rect = n => {const r=n.getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height};};
          const body=document.body,root=document.documentElement,region=document.getElementById('practice-scroll');
          const header=document.querySelector('.practice-stage > header'),footer=document.getElementById('practice-actions');
          const action=document.getElementById('practice-check')||document.getElementById('practice-next')||document.querySelector('#practice-actions button');
          const hit = n => {const r=n.getBoundingClientRect(),x=(r.left+r.right)/2,y=(r.top+r.bottom)/2,at=document.elementFromPoint(x,y);return !!at&&(at===n||n.contains(at));};
          return {width:innerWidth,height:innerHeight,scrollY,documentHeight:Math.max(root.scrollHeight,body.scrollHeight),documentWidth:root.scrollWidth,
            header:rect(header),footer:rect(footer),region:{...rect(region),scrollTop:region.scrollTop,scrollHeight:region.scrollHeight,clientHeight:region.clientHeight,overflow:getComputedStyle(region).overflowY,tabindex:region.getAttribute('tabindex'),name:region.getAttribute('aria-label')||region.getAttribute('aria-labelledby')},
            action:action?{...rect(action),hit:hit(action),id:action.id}:null,
            phrase:document.getElementById('practice-sentence')?rect(document.getElementById('practice-sentence')):null,
            heading:document.querySelector('#exercise h3')?rect(document.querySelector('#exercise h3')):null,
            options:[...document.querySelectorAll('#exercise .option')].map(n=>({...rect(n),hit:hit(n)}))};
        }""")
        require(metrics['documentWidth'] <= metrics['width'] + 1, f"La actividad desborda horizontalmente: {metrics}")
        require(metrics['documentHeight'] <= metrics['height'] + 1 and metrics['scrollY'] == 0, f"La actividad permite scroll del documento: {metrics}")
        require(metrics['header']['top'] >= -1 and metrics['header']['bottom'] <= metrics['region']['top'] + 1, 'La cabecera tapa la lectura')
        require(metrics['footer']['bottom'] <= metrics['height'] + 1 and metrics['footer']['top'] >= metrics['region']['bottom'] - 1, 'La barra inferior tapa el ejercicio')
        require(metrics['region']['clientHeight'] > 0 and metrics['region']['tabindex'] == '0' and metrics['region']['name'], 'La región de lectura no es accesible con teclado y nombre')
        require(metrics['region']['overflow'] in ('auto', 'scroll'), 'El contenido extenso no dispone de scroll interno')
        action = metrics['action']
        require(action and action['height'] >= 40 and action['left'] >= -1 and action['right'] <= metrics['width'] + 1 and action['top'] >= -1 and action['bottom'] <= metrics['height'] + 1 and action['hit'], f"La acción esencial está oculta, cubierta o comprimida: {action}")
        for option in metrics['options']:
            require(option['height'] >= 44 and option['left'] >= -1 and option['right'] <= metrics['width'] + 1, f'Una respuesta está comprimida o desborda: {option}')
            if ordinary:
                require(option['top'] >= metrics['region']['top'] - 1 and option['bottom'] <= metrics['region']['bottom'] + 1 and option['hit'], f'Una pregunta ordinaria obliga a buscar una respuesta: {option}')
        if ordinary:
            require(metrics['region']['scrollHeight'] <= metrics['region']['clientHeight'] + 1, f"Una pregunta ordinaria necesita scroll interno en escritorio: {metrics['region']}")
            for field in ('phrase', 'heading'):
                box = metrics[field]
                require(box and box['top'] >= metrics['region']['top'] - 1 and box['bottom'] <= metrics['region']['bottom'] + 1, f'La cabecera o frase queda fuera del ejercicio: {field}={box}')
        return metrics

    def responsive(self) -> None:
        """Nine exact viewport sizes, all tools and native situation picker."""
        for width, height in VIEWPORTS:
            page = self.new_page()
            page.set_viewport_size({'width': width, 'height': height})
            try:
                dimensions = page.evaluate('({content:document.documentElement.scrollWidth,viewport:innerWidth})')
                require(dimensions['content'] <= width + 1, f'Portada desborda en {width}x{height}')
                for selector in ('#landing-search', '#landing-search-submit'):
                    box = page.locator(selector).bounding_box()
                    require(box and box['x'] >= -1 and box['x'] + box['width'] <= width + 1, f'Buscador de portada fuera de pantalla: {width}x{height}')
                self.responsive_cases.append({'width': width, 'height': height, 'panel': 'inicio', 'passed': True})
                if width in (1440, 390, 320):
                    self.capture(page, f'00-portada-{width}x{height}.png', full_page=True)
                self.enter('buscar', page)
                for tab, name in zip(TABS, PREVIEW_NAMES):
                    self.navigate(tab, page)
                    dimensions = page.evaluate('({content:document.documentElement.scrollWidth,viewport:innerWidth})')
                    require(dimensions['content'] <= width + 1, f'{tab} desborda en {width}x{height}')
                    require(page.locator(f'#view-{tab}').is_visible(), f'{tab} no aparece en {width}x{height}')
                    if tab != 'practicar':
                        if width <= 760:
                            control = page.locator('#mobile-tool-select')
                            box = control.bounding_box()
                            require(control.is_visible() and control.input_value() == tab and box and box['x'] >= -1 and box['x'] + box['width'] <= width + 1, 'La navegación móvil no permite cambiar de herramienta')
                        else:
                            nav = page.locator('.tabs .tab').evaluate_all('nodes => nodes.map(n => {const r=n.getBoundingClientRect();return {left:r.left,right:r.right,top:r.top};})')
                            require(len(nav) == 5 and max(n['top'] for n in nav) - min(n['top'] for n in nav) <= 1 and all(n['left'] >= -1 and n['right'] <= width + 1 for n in nav), 'Las cinco herramientas no forman una navegación accesible')
                        self.require_heading_in_view(f'#h-{tab}', page)
                    if tab == 'aprender':
                        level_box = page.locator('#learn-level').bounding_box()
                        require(level_box and level_box['y'] >= 0 and level_box['y']+level_box['height'] <= height+1, 'Cambiar dificultad requiere buscar el control mediante scroll')
                        if width <= 760:
                            unit_select = page.locator('#learn-unit-select')
                            require(unit_select.is_visible(), 'El teléfono obliga a recorrer una lista larga de unidades')
                            last_unit = unit_select.locator('option').last.get_attribute('value')
                            unit_select.select_option(last_unit)
                            require(self.inspect(page)['learning']['unit'] == last_unit, 'El selector directo no abre la unidad elegida')
                    if tab == 'simular':
                        page.locator('#scene-browse').click()
                        dialog = page.locator('#scene-picker')
                        box = dialog.bounding_box()
                        require(box and box['x'] >= -1 and box['y'] >= -1 and box['x'] + box['width'] <= width + 1 and box['y'] + box['height'] <= height + 1, 'El selector sale del viewport')
                        require(page.locator('#scene-list .list-item').count() == len(self.data['scenarios']), 'El selector oculta situaciones')
                        last = page.locator('#scene-list .list-item').last
                        last.click(trial=True)
                        lastbox = last.bounding_box()
                        require(lastbox and lastbox['y'] >= box['y'] - 1 and lastbox['y'] + lastbox['height'] <= box['y'] + box['height'] + 1, 'La última situación queda inaccesible')
                        self.picker_cases.append({'width': width, 'height': height, 'situations_accessible': len(self.data['scenarios']), 'passed': True})
                        if width in (1440, 390, 320):
                            self.capture(page, f'08-selector-{width}x{height}.png')
                        page.keyboard.press('Escape')
                        require(page.locator('#scene-browse').evaluate('n => document.activeElement===n'), 'Cancelar el selector pierde el foco')
                    if tab == 'practicar':
                        self.practice_geometry(page, ordinary=width >= 1024)
                        self.practice_menu(page)
                        menu = page.locator('#practice-menu')
                        menu_box = menu.bounding_box()
                        require(menu_box and menu_box['x'] >= -1 and menu_box['y'] >= -1 and menu_box['x']+menu_box['width'] <= width+1 and menu_box['y']+menu_box['height'] <= height+1, 'El menú de sesión sale de pantalla')
                        close_box = page.locator('#practice-menu-close').bounding_box()
                        require(close_box and close_box['y'] >= menu_box['y'] and close_box['y']+close_box['height'] <= menu_box['y']+menu_box['height'], 'El menú oculta su cierre')
                        last_step = page.locator('#session-map .session-step').last
                        last_step.scroll_into_view_if_needed()
                        last_box = last_step.bounding_box()
                        require(last_box and last_box['y'] >= menu_box['y']-1 and last_box['y']+last_box['height'] <= menu_box['y']+menu_box['height']+1, 'No se puede consultar el último paso de sesión')
                        if width in (1440, 390, 320):
                            self.capture(page, f'09-menu-sesion-{width}x{height}.png')
                        self.practice_menu(page, opened=False)
                        require(page.locator('#practice-menu-open').evaluate('n => document.activeElement===n'), 'Cerrar el menú pierde el foco')
                    self.responsive_cases.append({'width': width, 'height': height, 'panel': tab, 'content_width': dimensions['content'], 'passed': True})
                    if width in (1440, 390, 320):
                        self.capture(page, f'{TABS.index(tab)+1:02d}-{name}-{width}x{height}.png', full_page=tab != 'practicar')
            finally:
                page.close()

    def practice_viewports(self) -> None:
        """Short/long/three-choice questions, feedback, transitions and results."""
        by_id = {exercise['id']: exercise for exercise in self.data['exercises']}
        scenes = {scene['id']: scene for scene in self.data['scenarios']}
        def length(ex):
            return len(ex['prompt_es']) + len(ex['intent_es']) + len(ex['template_zh'])
        ordered = sorted(self.data['exercises'], key=length)
        three = next(ex for ex in ordered if len(ex['options']) == 3)
        ids = list(dict.fromkeys([ordered[0]['id'], ordered[-1]['id'], three['id']] + [ex['id'] for ex in ordered]))[:8]
        require(len(ids) == 8, 'No hay ocho preguntas reales para medir transiciones')
        for width, height in VIEWPORTS:
            page = self.new_page(initial_hash='#practicar')
            page.set_viewport_size({'width': width, 'height': height})
            try:
                page.evaluate('ids => HanYuMatizP10.startPractice(ids, {title:"Sesión de comprobación"})', ids)
                require(self.inspect(page)['sessionIds'] == ids, 'La sesión medida no usa las preguntas reales pedidas')
                measurements = []
                for index, exercise_id in enumerate(ids):
                    exercise = by_id[exercise_id]
                    require(self.inspect(page)['exerciseId'] == exercise_id, 'Avanzar muestra otra pregunta')
                    require(page.locator('#exercise h3.practice-scenario').count() == 1, 'La siguiente pregunta se acumula bajo la anterior')
                    try:
                        initial = self.practice_geometry(page, ordinary=width >= 1024)
                    except AssertionError as error:
                        raise AssertionError(f'{width}x{height}, pregunta {index+1} ({exercise_id}), antes de responder: {error}') from error
                    require(initial['region']['scrollTop'] == 0, 'La pregunta nueva conserva el scroll interno anterior')
                    if index in (0, 1, len(ids)-1):
                        self.capture(page, f'practica-{width}x{height}-pregunta-{index+1:02d}.png')
                    # Smaller screens may use their clearly named internal
                    # region. Normal desktop questions must need none of it.
                    for button in page.locator('#exercise .option').all():
                        button.click(trial=True)
                        box = button.bounding_box()
                        region = page.locator('#practice-scroll').bounding_box()
                        footer = page.locator('#practice-actions').bounding_box()
                        require(box and region and footer and box['y'] >= region['y'] - 1 and box['y'] + box['height'] <= footer['y'] + 1, 'Scroll interno no permite alcanzar una opción sin superposición')
                    if index == 1:
                        for help_id in ('practice-pinyin', 'practice-translation'):
                            page.locator('#'+help_id).click()
                            require(page.locator('#'+help_id).get_attribute('aria-pressed') == 'true', 'La ayuda no declara su estado')
                        self.practice_geometry(page)
                    choice = next(option for option in exercise['options'] if option['key'] != exercise['answer_key']) if index == 0 else next(option for option in exercise['options'] if option['key'] == exercise['answer_key'])
                    button = page.locator(f'#exercise .option[data-choice="{choice["key"]}"]')
                    button.click()
                    before = page.evaluate('scrollY')
                    page.locator('#practice-check').click()
                    require(page.evaluate('scrollY') == before == 0, 'Comprobar produce un salto del documento')
                    require(page.locator('#practice-feedback .practice-feedback-title').evaluate('n => document.activeElement===n'), 'La retroalimentación pierde el foco')
                    try:
                        answered = self.practice_geometry(page, ordinary=width >= 1024 and index != 1)
                    except AssertionError as error:
                        raise AssertionError(f'{width}x{height}, pregunta {index+1} ({exercise_id}), respuesta con explicación colapsada: {error}') from error
                    require(page.locator('#exercise .option').count() == len(exercise['options']), 'La corrección hace desaparecer respuestas necesarias')
                    feedback = page.locator('#practice-feedback').inner_text()
                    require(feedback.strip() and page.locator('#practice-action-status').text_content().strip(), 'El resultado depende solo del color')
                    if index in (0, 1, len(ids)-1):
                        self.capture(page, f'practica-{width}x{height}-respuesta-{index+1:02d}.png')
                    expanded = None
                    if index == 1:
                        detail = page.locator('#practice-feedback .practice-full-explanation')
                        detail.locator('summary').focus()
                        page.keyboard.press('Enter')
                        require(detail.get_attribute('open') is not None, 'El teclado no abre la explicación larga')
                        require(exercise['explanation_es'] in detail.text_content(), 'La explicación completa altera el banco')
                        for key in ('a', 'b'):
                            version = detail.locator(f'.answer-version[data-choice="{key}"]')
                            require(scenes[exercise['scenario_id']][f'note_{key}'] in version.text_content(), 'La revelación omite una nota original')
                        region = page.locator('#practice-scroll')
                        region.focus()
                        page.keyboard.press('End')
                        page.wait_for_function("""() => {const n=document.getElementById('practice-scroll');
                          return n.scrollHeight <= n.clientHeight + 1 || n.scrollTop+n.clientHeight >= n.scrollHeight-2;}""", timeout=2000)
                        expanded = self.practice_geometry(page)
                        if expanded['region']['scrollHeight'] > expanded['region']['clientHeight'] + 1:
                            require(expanded['region']['scrollTop'] > 0, 'El teclado no puede recorrer la explicación interna')
                            require(expanded['region']['scrollTop'] + expanded['region']['clientHeight'] >= expanded['region']['scrollHeight'] - 2, 'El final de la explicación no es alcanzable')
                        self.capture(page, f'practica-{width}x{height}-explicacion-larga.png')
                    measurements.append({'exercise_id': exercise_id, 'position': index+1, 'ordinary': initial, 'answered': answered, 'expanded': expanded})
                    if index == 1:
                        for help_id in ('practice-pinyin', 'practice-translation'):
                            page.locator('#'+help_id).click()
                            require(page.locator('#'+help_id).get_attribute('aria-pressed') == 'false', 'No se pueden cerrar las ayudas tras responder')
                    page.locator('#practice-next').click()
                    require(page.evaluate('scrollY') == 0, 'Cambiar pregunta desplaza el documento')
                    if index < len(ids)-1:
                        require(page.locator('#exercise h3.practice-scenario').evaluate('n => document.activeElement===n'), 'Avanzar no enfoca la nueva pregunta')
                        require(page.locator('#practice-scroll').evaluate('n => n.scrollTop') == 0, 'Avanzar no restablece solo la región de lectura')
                require(page.locator('#exercise .session-result').count() == len(ids), 'La pantalla final no permite revisar toda la sesión')
                self.practice_geometry(page)
                require(page.locator('#practice-retry-missed').is_visible(), 'Resultados pierde el repaso del fallo real')
                self.capture(page, f'practica-{width}x{height}-resultados.png')
                self.practice_cases.append({'width': width, 'height': height, 'questions': len(ids), 'states': measurements, 'passed': True})
            finally:
                page.close()

    def zoom(self, playwright, browser_path: str) -> None:
        """Native Chromium 200% zoom via a temporary profile, not CSS scaling."""
        require(self.origin is not None, 'Zoom nativo requiere el origen HTTP local de la prueba')
        with TemporaryDirectory(prefix='hanyumatiz-zoom-', dir='/tmp') as directory:
            profile = Path(directory)/'Default'
            profile.mkdir()
            zoom_level = math.log(2)/math.log(1.2)
            # Chromium reads the host preference for this local test origin.
            # The legacy partition key is accepted by the installed Chromium;
            # the DPR/viewport assertions below verify the actual zoom applied.
            (profile/'Preferences').write_text(json.dumps({'partition': {
                'default_zoom_level': zoom_level,
                'per_host_zoom_levels': {'x': {urlsplit(self.origin).hostname: {
                    'zoom_level': zoom_level, 'last_modified': '0'}}}}}))
            context = playwright.chromium.launch_persistent_context(directory, executable_path=browser_path, headless=True, no_viewport=True, timezone_id='Asia/Shanghai', args=['--no-sandbox', '--window-size=1440,987'])
            try:
                page = context.pages[0]
                page.set_default_timeout(6000)
                page.goto(self.origin, wait_until='load')
                page.on('pageerror', lambda error: self.errors.append(str(error)))
                page.on('console', lambda message: self.errors.append(message.text) if message.type == 'error' else None)
                page.on('request', lambda request: self.requests.append(request.url))
                page.set_content(self.html, wait_until='load')
                page.evaluate('() => document.fonts.ready')
                page.evaluate("() => HanYuMatizP10.startPractice(JSON.parse(document.getElementById('payload').textContent).exercises.slice(0,2).map(e=>e.id),{title:'Zoom'})")
                zoom = page.evaluate('({innerWidth,innerHeight,outerWidth,outerHeight,dpr:devicePixelRatio,visualScale:visualViewport.scale})')
                require(zoom['dpr'] == 2 and zoom['visualScale'] == 1 and zoom['innerWidth'] * 2 == zoom['outerWidth'], f'Chromium no activó zoom nativo200%: {zoom}')
                self.practice_geometry(page)
                for help_id in ('practice-pinyin', 'practice-translation'):
                    page.locator('#'+help_id).click()
                for option in page.locator('#exercise .option').all():
                    option.click()
                    self.practice_geometry(page)
                page.locator('#practice-check').click()
                detail = page.locator('#practice-feedback .practice-full-explanation')
                detail.locator('summary').click()
                page.locator('#practice-scroll').focus()
                page.keyboard.press('End')
                page.wait_for_function("""() => {const n=document.getElementById('practice-scroll');
                  return n.scrollHeight <= n.clientHeight + 1 || n.scrollTop+n.clientHeight >= n.scrollHeight-2;}""", timeout=2000)
                metrics = self.practice_geometry(page)
                if metrics['region']['scrollHeight'] > metrics['region']['clientHeight'] + 1:
                    require(metrics['region']['scrollTop'] > 0, 'Zoom200% no permite leer el contenido interno')
                self.capture(page, 'practica-zoom-nativo-200.png', native=True)
                page.locator('#practice-next').click()
                self.practice_geometry(page)
                require(page.locator('#exercise h3.practice-scenario').evaluate('n => document.activeElement===n'), 'Zoom200% pierde foco al avanzar')
                self.zoom_cases.append({'zoom_percent': 200, 'native_browser_zoom': True, 'viewport': zoom, 'expanded': metrics, 'passed': True})
            finally:
                context.close()

    def desktop_bank(self) -> None:
        """Every existing question must fit each of the three desktop targets."""
        for width, height in VIEWPORTS[:3]:
            page = self.new_page(initial_hash='#practicar')
            page.set_viewport_size({'width': width, 'height': height})
            measurements = []
            try:
                for exercise in self.data['exercises']:
                    page.evaluate('id => HanYuMatizP10.startPractice([id], {title:"Consulta del banco"})', exercise['id'])
                    require(self.inspect(page)['exerciseId'] == exercise['id'], 'La pregunta medida no corresponde al banco')
                    metrics = self.practice_geometry(page, ordinary=True)
                    # Check every real answer, including the longer "both"
                    # option, without permitting Playwright to rescue layout.
                    for index in range(len(exercise['options'])):
                        page.locator('#exercise .option').nth(index).click()
                        self.practice_geometry(page, ordinary=True)
                    measurements.append({'exercise_id': exercise['id'], 'options': len(exercise['options']), 'region': metrics['region'], 'action': metrics['action']})
                self.desktop_bank_cases.append({'width': width, 'height': height, 'questions': len(measurements), 'measurements': measurements, 'passed': True})
            finally:
                page.close()

    def runtime(self) -> None:
        require(not self.errors, "Errores de JavaScript/CSP/consola: " + "; ".join(self.errors))
        app_requests = [url for url in self.requests if not (self.origin and url == self.origin + "favicon.ico")]
        require(not app_requests, "La página autónoma realizó solicitudes inesperadas: " + ", ".join(app_requests))

    def run(self, playwright=None, browser_path='/usr/bin/chromium', only=None) -> bool:
        try:
            for label, action in (
                ("Portada, entrada y contadores del contenido", self.startup),
                ("Lección de entrada: respuesta, reformulación, teclado y contraste propio", self.demonstration),
                ("Búsqueda desde la portada: chino, pinyin, español, ejemplos, consulta vacía y sin coincidencias", self.landing_search),
                ("Diccionario: recorrido completo, búsqueda y foco", self.dictionary),
                ("Comparaciones: catálogo completo, pinyin y foco", self.comparisons),
                ("Situaciones: selector, quince casos, pinyin, cancelación y foco", self.contexts),
                ("Navegación: portada, enlaces directos, historial, teclado y foco", self.navigation),
                ("Práctica: ocho situaciones, ayudas, comparación, revisión, repaso de matices y progreso local", self.practice_and_storage),
                ("Aprender: dificultad, unidades y lecciones reales, regreso y progreso por situación", self.curriculum),
                ("Demostración y navegación con movimiento reducido", self.reduced_motion),
                ("Responsive: nueve resoluciones exactas, seis vistas y selector de situaciones", self.responsive),
                ("Actividad: ocho preguntas en nueve resoluciones, respuesta, ayudas, explicación interna y resultados", self.practice_viewports),
                ("Banco completo: treinta preguntas y todas sus opciones dentro de tres viewports de escritorio", self.desktop_bank),
                ("Zoom nativo de Chromium200%, lectura interna y controles persistentes", lambda: self.zoom(playwright, browser_path)),
                ("Sin errores de ejecución ni solicitudes externas", self.runtime),
            ):
                if only is None or any(value.casefold() in label.casefold() for value in only):
                    self.check(label, action)
            require(bool(self.results), 'El filtro no seleccionó ninguna prueba; no se declara aprobado un recorrido sin ejecutar')
            report = {
                "passed": sum(result["passed"] for result in self.results),
                "total": len(self.results),
                "csp_verified": True,
                "storage_available": self.storage_available,
                "storage_tested": self.storage_available and any(result['passed'] and result['check'].startswith('Práctica:') for result in self.results),
                "index_sha256": hashlib.sha256(self.html.encode("utf-8")).hexdigest(),
                "content": {key: len(self.data[key]) for key in ("words", "contrasts", "scenarios", "exercises")},
                "checks": self.results,
                "responsive_combinations_tested": len(self.responsive_cases),
                "responsive": self.responsive_cases,
                "scenario_picker_widths_tested": len(self.picker_cases),
                "scenario_picker": self.picker_cases,
                "landing_search_queries_tested": len(self.landing_queries),
                "landing_search": self.landing_queries,
                "practice_viewports_tested": len(self.practice_cases),
                "practice": self.practice_cases,
                "desktop_bank": self.desktop_bank_cases,
                "curriculum": self.curriculum_cases,
                "zoom": self.zoom_cases,
                "limits": ["Comprobado en Chromium de escritorio automatizado; no sustituye pruebas en Safari, Firefox o dispositivos físicos.", "Viewport sin barras móviles del navegador; la composición usa altura dinámica pero su aparición en dispositivos físicos requiere prueba manual."],
                "screenshots": self.previews,
                "runtime_errors": self.errors,
                "app_requests": self.requests,
            }
            report_path = self.report_path
            report_path.parent.mkdir(parents=True, exist_ok=True)
            report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            print(f"Resultado: {report['passed']}/{report['total']}; {len(self.responsive_cases)} combinaciones responsive; almacenamiento comprobado: {self.storage_available}")
            print(f"Informe: {report_path.relative_to(ROOT) if report_path.is_relative_to(ROOT) else report_path}")
            return all(result["passed"] for result in self.results)
        finally:
            self.context.close()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", default="/usr/bin/chromium", help="Ruta del ejecutable Chromium")
    parser.add_argument("--screenshots", type=Path, default=ROOT / "screenshots/v29", help="Directorio de vistas previas")
    parser.add_argument("--report", type=Path, default=ROOT / "docs/VALIDACION_V29.json", help="Informe JSON de esta ejecución")
    parser.add_argument("--no-screenshots", action="store_true", help="Omitir capturas de pantalla")
    parser.add_argument("--only", action='append', help="Ejecutar solo checks cuyo título contenga este texto; repetible para diagnóstico")
    args = parser.parse_args()
    server = None
    try:
        from playwright.sync_api import sync_playwright

        html = (ROOT / "index.html").read_text(encoding="utf-8")
        data = audit_csp(html)
        print("OK  Hashes CSP de los dos scripts")
        origin = None
        try:
            server = ThreadingHTTPServer(("127.0.0.1", 0), OriginHandler)
            Thread(target=server.serve_forever, daemon=True).start()
            origin = f"http://127.0.0.1:{server.server_port}/"
        except OSError as error:
            print(f"AVISO: servidor de origen local no disponible: {error}")
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path=args.browser, headless=True, args=["--no-sandbox"])
            try:
                checks = UiChecks(browser, html, data, origin, None if args.no_screenshots else args.screenshots, args.report)
                return 0 if checks.run(playwright, args.browser, args.only) else 1
            finally:
                browser.close()
    except (ImportError, OSError, ValueError, AssertionError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    finally:
        if server:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    raise SystemExit(main())
