# Contenido de HanYuMatiz

El vocabulario se edita en `data/vocabulary.json`. `index.html` es una entrega generada que se puede abrir directamente, sin servidor, conexión ni dependencias. No edites los datos dentro de ese HTML: se sobrescribirían en la próxima compilación.

Esta reorganización conserva el contenido recibido: **32 palabras, 14 contrastes, 15 situaciones y 30 ejercicios**. No se han añadido palabras ni cambiado claves lingüísticas. La validación de estructura y programación no equivale a revisar que una expresión china sea natural.

## Estado de revisión

- Las 32 palabras, los 14 contrastes y las 15 situaciones tienen `reviewed: false`.
- Los 30 ejercicios siguen como `editorial_draft`, con `linguistic_review`, `rights_review` y `public_use` en `false`, sin fuentes de evidencia ni revisor asignado.
- Todos los niveles `hsk_level` son `null`: no hay clasificación HSK verificada.
- El uso público, la aprobación lingüística y la aprobación de derechos del conjunto siguen en `false`.

Antes de incorporar contenido nuevo, conviene revisar el par con un especialista en chino y registrar referencias, ejemplos, autoría y condiciones de uso. Compartir una traducción española o un tema no demuestra que dos palabras puedan sustituirse. Evita convertir una preferencia de matiz en una afirmación de que la otra palabra es incorrecta en general.

La palabra 行 tiene varias lecturas y sentidos. El esquema actual enumera ambos por separado; aún no relaciona cada sentido con su lectura. Esa relación requiere una futura mejora del modelo y de la ficha, además de revisión editorial. No se ha inventado esa correspondencia en esta entrega.

## Estructura de los datos

| Colección | Qué contiene | Relaciones y condiciones |
| --- | --- | --- |
| `words` | `id`, `zh`, `readings`, `senses`, `reviewed`, `hsk_level` | IDs únicos y permanentes. `readings` incluye `pinyin` y una lista `syllables` con `pinyin` y `tone` por carácter. `senses` tiene `id`, `gloss` y `pos`. |
| `contrasts` | Dos palabras `a` y `b`, su explicación y su tema | `word_id_a` y `word_id_b` apuntan a `words`; `sense_a/b` y `pos_a/b` deben corresponder a sentidos de esas palabras. `signals` expresa hipótesis editoriales; `cautions` explica sus límites. |
| `scenarios` | Intención, oración incompleta y comparación de las dos versiones | `contrast_id` apunta a un contraste. `a/b` mantiene el mismo orden. `sentence` contiene una vez `〔词〕`. Incluye `fit_a/b`, `note_a/b`, `comparison`, `translation` y `reviewed`. |
| `phonetics` | Las sílabas para las versiones `a` y `b` de cada situación | Un objeto por ID de situación, con sílabas que coinciden con una lectura de cada palabra en el diccionario. |
| `exercises` | Preguntas, opciones, respuesta y explicación | `scenario_id` apunta a una situación y `scenario_sha256` identifica su versión. La oración, intención y palabras deben coincidir con ella. Una situación puede tener uno o varios ejercicios, o existir solo en el catálogo de contextos. |
| `sourceHash` | Versión del banco utilizada por el almacenamiento local | Se conserva para mantener la compatibilidad del progreso actual. Al modificar ejercicios debe cambiar. |
| `sourceDigests` | Identificadores de las etapas de la entrega original | `p6_exercises` debe coincidir con `sourceHash`. Las demás claves son referencias históricas, no hashes recalculados de las colecciones actuales. |

Un ID identifica una entrada estable. No cambies IDs existentes para ajustar el diseño ni reutilices uno para una palabra o situación distinta. Un ejemplo de patrón para nuevas entradas es `lex_<nombre>`, `pro_<nombre>_1`, `sen_<nombre>_<sentido>`, `cmp_<par>` y `scn_<tema>_<numero>`. El validador admite letras minúsculas, números y guiones bajos.

Los tonos se representan con números de **1 a 5**, donde 5 es el tono neutro. El pinyin usa marcas diacríticas coherentes con el número. Las sílabas mantienen el orden de los caracteres; no se infiere la pronunciación a partir de la grafía.

### Qué significa `fit`

| Valor | Lectura de la hipótesis editorial |
| --- | --- |
| `preferred_in_context` | Opción preferida para la intención concreta. |
| `possible_with_nuance` | Admisible, con un matiz diferente. |
| `requires_reformulation` | Necesita reformular esta construcción; no implica que la palabra sea incorrecta en otros contextos. |

### Ejercicios por situación

El banco recibido contiene dos ejercicios por situación. El planificador admite uno o varios y los alterna en el orden de la colección; conserva el progreso por `scenario_id`, de modo que una sesión incluye como máximo una pregunta de cada situación. Una situación sin ejercicios sigue disponible en «En contexto». Cada ejercicio tiene dificultad `inicial`, `intermedio` o `avanzado`.

El ejercicio principal puede ser:

- `choice_preference`: opciones `a`, `b`; la respuesta corresponde a la única opción preferida en ese contexto.
- `choice_structure`: opciones `a`, `b`; solo una entra sin reformular la construcción.
- `both_acceptable`: opciones `a`, `b`, `both`; ambas caben y la clave es `both`.

También puede añadirse un ejercicio `kind: recognize_validity`, con opciones `a`, `b`, `both`. La clave indica qué versiones caben sin reformular, según `fit_a/b`. Las etiquetas de las opciones deben expresar el alcance de la pregunta, por ejemplo «Solo…» y «Ambas funcionan sin cambiar la estructura», cuando corresponda. Una misma clave no siempre representa una preferencia de matiz.

`answer_key` debe coincidir con una clave de `options`. `template_zh`, `intent_es`, `word_a` y `word_b` repiten deliberadamente datos de la situación; el validador comprueba que no se desincronicen.

## Ampliar el banco

1. Añade cada palabra a `words` con lectura, sílabas, sentidos y un ID nuevo. No inventes niveles HSK: conserva `null` si no hay clasificación revisada. Una palabra puede existir solo en el diccionario.
2. Para enseñar una distinción, crea el contraste usando IDs de palabras existentes y sus sentidos. Explica el matiz, las colocaciones o la estructura que hacen pertinente la comparación.
3. Añade situaciones específicas al contraste, con intención explícita, traducción orientativa, ambas notas y una sola posición `〔词〕`.
4. Añade la fonética de ambas versiones a `phonetics`. En palabras con varias lecturas, usa la del contexto concreto.
5. Añade los ejercicios que permitan evaluar el criterio elegido. Una situación aún sin preguntas puede quedarse en el catálogo de contextos. Mantén explicación, clave y estados de revisión coherentes. Registra evidencia y revisor cuando estén disponibles; la publicación y el soporte para contenido aprobado requieren una tarea de lanzamiento separada, no cambiar banderas para evitar las comprobaciones.
6. Si cambias o añades ejercicios o sus situaciones, actualiza las referencias de versión con el comando siguiente. Si solo amplías el diccionario y el banco de práctica no cambia, conserva `sourceHash`.
7. Valida, genera la entrega y prueba la palabra o situación nueva en el navegador.

### Versiones de contenido y progreso

La entrega importada tiene `sourceHash` y `sourceDigests.p6_exercises` iguales a:

```text
e7d1807f5c29ddcafef71a62b19d5c659a3f2fe27b5206091937c223a43a3d0c
```

No se pudo reproducir ese valor calculando SHA-256 de la colección `exercises` visible con las serializaciones JSON habituales. Tampoco se pudieron reproducir los `scenario_sha256` a partir de las situaciones visibles. Pueden proceder de documentos de etapas anteriores que no están en este archivo. Por ello se conservan como **identificadores de versión heredados**, sin afirmar que verifiquen criptográficamente estas colecciones.

`data/integrity-baseline.json` registra los SHA-256 canónicos reales del contenido recibido y los identificadores heredados. El SHA-256 canónico inicial de los ejercicios visibles es:

```text
6abf222804ffe2d5d9433c030db019f3d0012a4dbd6dba760603428147e41bc1
```

El validador compara contra esa línea base independiente. Rechaza cambios de ejercicios que intenten conservar la versión importada y rechaza cambios de situación sin actualizar las referencias. **No edites la línea base para hacer pasar un cambio.** A partir de la siguiente versión se usa JSON UTF-8, claves ordenadas, sin espacios entre claves y valores, sin escapes ASCII innecesarios y sin salto de línea final como representación canónica para SHA-256.

Tras editar el banco, ejecuta desde la carpeta del proyecto:

```bash
python3 - <<'PY'
import json
from pathlib import Path
from tools.validate_data import canonical_sha256

path = Path('data/vocabulary.json')
data = json.loads(path.read_text(encoding='utf-8'))
scenarios = {scenario['id']: scenario for scenario in data['scenarios']}
for exercise in data['exercises']:
    exercise['scenario_sha256'] = canonical_sha256(scenarios[exercise['scenario_id']])
data['sourceHash'] = canonical_sha256(data['exercises'])
data['sourceDigests']['p6_exercises'] = data['sourceHash']
path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Nueva versión de práctica:', data['sourceHash'])
PY
```

Este comando normaliza las referencias del banco entero y cambia su versión. El navegador usará un espacio de almacenamiento nuevo; el progreso de la versión anterior no se migrará a claves nuevas ni se atribuirá automáticamente al contenido modificado. Los cambios exclusivamente visuales conservan `sourceHash` y el formato del historial.

## Validar y generar

Solo hace falta Python 3; no hay paquetes externos que instalar.

```bash
python3 tools/validate_data.py
python3 tools/build.py
python3 tools/build.py --check
```

Para verificar cambios del planificador, con Node.js disponible:

```bash
node tools/test_scheduler.cjs
```

Son diez comprobaciones de rotación con bancos de uno o tres ejercicios por situación, cupos de sesión, vencimientos, repaso anticipado, límites, progresión de intervalos y rechazo de fechas o historiales inválidos. Node.js se usa para desarrollo y pruebas; la aplicación final sigue sin necesitarlo.

El validador comprueba IDs, relaciones entre palabras, contrastes y situaciones, pinyin y tonos, cobertura de fonética, consistencia de plantillas, opciones y respuestas y versiones del contenido. Sus avisos recuerdan el estado editorial; no son una certificación lingüística ni legal.

El generador combina `index.template.html`, `assets/styles.css`, `assets/scheduler.js`, `assets/app.js` y los datos. Vuelve a calcular las dos firmas SHA-256 de los scripts para la política CSP y escapa `<` en el JSON embebido para que los datos no puedan cerrar su bloque `script`. `--check` comprueba la igualdad exacta entre las fuentes y la entrega sin escribirla.

Después abre `index.html`, busca las palabras nuevas, recorre sus comparaciones y situaciones y responde ambos tipos de pregunta. Comprueba también el comportamiento en una pantalla estrecha y el guardado voluntario de progreso. Para una comprobación compartida por HTTP puede usarse `python3 -m http.server 8080`; el funcionamiento habitual sigue siendo abrir el HTML directamente.
