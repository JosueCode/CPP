# Tipografía de V29

El texto latino de la interfaz usa **HanYuSans**, un subconjunto variable de Source Sans 3, de Adobe. Sus formas y pesos permiten diferenciar navegación, títulos, explicaciones y pinyin dentro de una misma familia. El archivo es romano y conserva el eje de peso original de 200 a 900.

Fuente original y licencia consultadas:

- https://github.com/google/fonts/tree/main/ofl/sourcesans3
- https://github.com/adobe-fonts/source-sans

`assets/fonts/HanYuSans-Latin.ttf` contiene los caracteres latinos, signos, diacríticos y vocales necesarios para el español y el pinyin, incluidas las combinaciones de tono. También incluye los signos de puntuación y las flechas disponibles en la fuente original. No incorpora caracteres chinos ni pretende sustituir iconos gráficos.

La fuente se distribuye bajo **SIL Open Font License 1.1**, con el aviso completo en `assets/fonts/SOURCE-SANS-OFL.txt`. La licencia reserva el nombre «Source». Como el subconjunto modifica la fuente original, los nombres internos de familia, estilo, identificador, nombre completo, PostScript y prefijo variable se han actualizado a HanYuSans. Se conservan los metadatos de copyright, autoría y licencia de Adobe. HanYuSans es el nombre de esta modificación, no una fuente atribuida como original al proyecto.

Los caracteres chinos usan **HanYuSong**, un subconjunto de Noto Serif CJK SC Regular, también bajo SIL Open Font License 1.1. El archivo original del entorno es `/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc`; se selecciona la familia SC por su nombre. El subconjunto se distribuye en `assets/fonts/HanYuSong-Subset.otf`, con nombres propios y los metadatos de autoría y licencia conservados. `assets/fonts/NOTO-OFL.txt` recoge el aviso de copyright y la licencia. Proyecto: https://github.com/notofonts/noto-cjk

HanYuSong incluye los caracteres chinos y la puntuación presentes en `data/vocabulary.json`, `index.template.html` y `assets/app.js`, además de `＿` (U+FF3F), utilizado al practicar. Esto permite mostrar el vocabulario y los ejemplos sin depender de las fuentes chinas instaladas en el dispositivo.

`tools/build.py` incrusta ambas fuentes en el HTML mediante el único token `FONT_FACE` de `assets/styles.css`. No hace falta instalar herramientas ni descargar fuentes para generar la página o abrir la entrega: el constructor utiliza los subconjuntos guardados. El HTML permite fuentes `data:` en su CSP y no realiza peticiones externas.

## Pinyin y tonos

V29 alinea la lectura de las palabras por carácter con `ruby` y `rt`. Utiliza exclusivamente las sílabas presentes en el banco; no genera pinyin para frases completas. Las lecturas de índices y comparación conservan el texto original y colorean las mismas sílabas: tono 1 rojo, 2 naranja, 3 verde, 4 azul y neutro gris. Las marcas escritas de tono permiten leer la pronunciación sin depender del color. En el paisaje oscuro se utilizan variantes claras para mantener contraste.

## Mantenimiento de las fuentes

Solo la regeneración de los subconjuntos requiere fontTools y las fuentes originales. Para regenerar HanYuSans:

```sh
python3 -m pip install fonttools
python3 tools/subset_latin.py --font '/ruta/a/SourceSans3[wght].ttf'
```

El script comprueba la familia original, el eje 200–900, la cobertura del español y el pinyin y los nombres internos de la modificación. Para ampliar HanYuSong al añadir textos chinos:

```sh
python3 tools/subset_cjk.py --font /ruta/a/NotoSerifCJK-Regular.ttc
python3 tools/build.py
```

`subset_cjk.py --font` también acepta la fuente original `.otf` de la familia SC. Si se omite, utiliza la ruta del sistema indicada arriba. Comprueba la cobertura y detiene la generación si falta algún carácter solicitado.
