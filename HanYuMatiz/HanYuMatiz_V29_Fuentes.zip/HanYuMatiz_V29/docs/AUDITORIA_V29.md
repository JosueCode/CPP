# Auditoría de contenido y arquitectura académica — V29

Auditoría de solo lectura realizada antes de la implementación V29 sobre `data/vocabulary.json`, `data/integrity-baseline.json`, `assets/app.js`, `assets/scheduler.js`, `index.template.html`, `assets/styles.css` y `docs/CONTENIDO.md`. Las primeras secciones documentan la V28 recibida y el contrato propuesto durante la auditoría. La sección final registra la implementación V29 observada después en las fuentes. Las afirmaciones de implementación no equivalen a una validación final en navegador; esta se documentará por separado en `docs/VALIDACION_V29.json`.

## Contenido disponible

- 32 palabras; 14 contrastes; 15 situaciones; 30 ejercicios.
- 2 ejercicios reales por situación: uno principal y otro de reconocimiento de validez.
- 11 contrastes tienen situaciones y ejercicios. 3 contrastes son únicamente consultables.
- Dificultad editorial de los ejercicios: inicial, 12 preguntas en 6 situaciones y 6 contrastes; intermedio, 8 preguntas en 4 situaciones y 3 contrastes; avanzado, 10 preguntas en 5 situaciones y 3 contrastes. Un contraste (`必须 / 需要`) contiene situaciones de dos dificultades; por ello la suma de contrastes por filtro supera las 11 unidades únicas.
- Tipos: 15 `recognize_validity`, 6 `both_acceptable`, 5 `choice_structure`, 4 `choice_preference`.
- Las 32 entradas tienen `hsk_level: null`. No existe un currículo HSK, un estándar HSK declarado ni clasificación revisada.
- Las banderas de aprobación lingüística, de derechos y de uso público permanecen en `false`. Todas las palabras, comparaciones y situaciones están pendientes de revisión. Los ejercicios son `editorial_draft`.
- La fonética existente cubre las dos palabras candidatas de cada situación; no cubre el pinyin de la frase completa. No se debe inventar esa fonética.
- 5 palabras existen solo en el diccionario: 以为, 认识, 知道, 行 y 花. 行 tiene dos lecturas y dos sentidos, sin relación explícita entre lectura y acepción.

| Par | Tema disponible | Situaciones | Dificultad editorial |
| --- | --- | ---: | --- |
| 选择 / 挑选 | Elección y selección | 1 | intermedio: 1 |
| 理解 / 明白 | Comprensión | 2 | intermedio: 2 |
| 可能 / 也许 | Posibilidad y conjetura | 1 | inicial: 1 |
| 经常 / 常常 | Frecuencia | 1 | inicial: 1 |
| 关键 / 重要 | Importancia frente a factor decisivo | 1 | inicial: 1 |
| 发现 / 发觉 | Descubrimiento y toma de conciencia | 0 | Sin ejercicios |
| 情况 / 状况 | Estado y circunstancia | 0 | Sin ejercicios |
| 马上 / 立刻 | Inmediatez | 1 | inicial: 1 |
| 协助 / 帮助 | Ayuda y asistencia | 1 | inicial: 1 |
| 感觉 / 觉得 | percibir o sentir algo / expresar una impresión u opinión personal | 1 | inicial: 1 |
| 提高 / 改善 | Elevar un nivel frente a mejorar una condición | 2 | avanzado: 2 |
| 感觉 / 认为 | percibir o sentir algo / considerar o sostener una opinión | 0 | Sin ejercicios |
| 合适 / 适合 | Adecuación y función gramatical | 2 | avanzado: 2 |
| 必须 / 需要 | Necesidad frente a obligación | 2 | intermedio: 1, avanzado: 1 |

Los contrastes sin situaciones son 发现 / 发觉, 情况 / 状况 y 感觉 / 认为. Pueden abrirse en el comparador; no deben presentar un botón para iniciar una lección inexistente. La etiqueta larga de coincidencia editorial en dos contrastes ya se sustituye en la V28 por sus dos sentidos mediante `comparisonTitle`; ese título es una presentación de campos existentes, no contenido lingüístico nuevo.

## Pantallas y componentes implementados en V28

- Inicio: portada ilustrada, búsqueda real y demostración de la situación `scn_p5_004`. La demostración tiene una clave y retroalimentación reales, pero no modifica el historial.
- Diccionario: búsqueda por caracteres, español y pinyin; índice; paginación; hanzi; pronunciación; sentido y función; otras acepciones y lecturas cuando existen; un ejemplo de situación cuando existe; enlaces a comparaciones y contexto.
- Comparador: catálogo y búsqueda, dos palabras en paralelo, matriz de significado/función/registro, cautelas y acceso a las situaciones disponibles.
- En contexto: selector modal de 15 situaciones, cambio de palabra en la frase, interpretación provisional de la sustitución, dos versiones y notas editoriales.
- Practicar: agenda adaptativa, mapa lateral de preguntas, ejercicio, selección, comprobación, retroalimentación, resumen, revisión y repetición de los matices que no coinciden con la clave.
- Aprender, nivel, unidad y lección no existen como pantallas o entidades académicas en V28. Los datos sí permiten organizar una navegación temática sin redactar nuevos ejercicios.

La navegación existente usa `#inicio`, `#buscar`, `#comparar`, `#simular` y `#practicar`. `switchTab` alterna vistas; `showLanding` alterna inicio y aplicación; las rutas responden a `hashchange`. Hay navegación de pestañas con flechas, Home y End. Los enlaces internos actualizan la palabra, comparación o situación seleccionada antes de cambiar de vista.

## Estado de sesiones y progreso existente

- Estado de sesión en memoria: `session` (ejercicios), `sessionIndex`, `responses` indexado por `exercise.id`, `selected`, `sessionCount` y ayudas de pinyin/traducción.
- `prepareSession` reemplaza la sesión y reinicia respuestas. `renderTrainer` reemplaza el contenido de `#exercise`; la V28 no acumula las preguntas una debajo de otra.
- Sesión ordinaria: `S.schedule` selecciona hasta 8 ejercicios, como máximo uno por situación, con rotación entre ejercicios de una misma situación según el número de intentos.
- La comprobación llama `S.update` una sola vez por respuesta nueva y guarda `{key, ok}` en `responses`. Volver a una respuesta en el mapa no vuelve a registrar el intento.
- Se puede revisar una respuesta registrada y el primer paso pendiente. No se puede saltar arbitrariamente preguntas no respondidas.
- El resumen usa respuestas de la sesión actual. La repetición de no coincidencias crea una sesión nueva con los ejercicios reales afectados.
- Historial longitudinal: `history[scenario_id] = {attempts, correct, streak, last_day, due_day}`. El formato no identifica ejercicios concretos ni guarda una marca de lección completada.
- Guardado voluntario, solo en el navegador. El espacio de almacenamiento usa `hanyumatiz:internal-p7:` y el prefijo de `sourceHash`. No hay cuentas, nube, sincronización ni backend.
- La agenda es una heurística, no un SRS validado, prueba de nivel ni medida de dominio del idioma.

La clave importada del banco y las referencias de situación son identificadores heredados. `integrity-baseline.json` conserva hashes canónicos reales para impedir cambios encubiertos de contenido. El rediseño debe conservar datos, IDs, claves, fonética, respuestas, `sourceHash`, esquema de historial y planificador, salvo una modificación técnica explícita que no altere su significado.

## Causas del desplazamiento de V28

La práctica sigue el flujo vertical del documento. El encabezado de la aplicación es fijo en el flujo mediante `position: sticky`, pero la altura de actividad no se limita al espacio restante del viewport. Además del título de sección y progreso, cada pregunta añade metadatos, nombre de situación, instrucción, intención, frase, ayudas, opciones de al menos 70 px, acciones y atajos. La retroalimentación añade sus dos versiones y explicación antes de las acciones. El botón de comprobar o siguiente está al final de ese bloque.

El mapa lateral se abre inicialmente en escritorio y tiene ocho pasos de al menos 67 px, más gestión de sesión y progreso. `align-items: start` no impide que esa columna contribuya a la altura de la página. Los márgenes de 16–22 px entre bloques y la frase con `line-height: 1.95` añaden altura. En móvil se traslada la columna lateral debajo del ejercicio; la pantalla continúa siendo un documento largo.

La solución debe separar la actividad del área de consulta: encabezado de actividad compacto, región central flexible y barra de acciones persistente en un contenedor `100dvh`. La pregunta y retroalimentación esencial deben sustituirse por estado; las explicaciones extensas se revelan en una región secundaria accesible. Si altura pequeña o zoom exige desplazamiento, debe estar en una región central identificable y no ocultar las opciones o acciones con recorte.

## Contrato propuesto durante la auditoría de Aprender

### Jerarquía auténtica

`Aprender → Dificultad del ejercicio → Unidad temática (contraste) → Lección (situación) → Sesión (sus 2 ejercicios existentes) → Resultados de esa sesión`.

La dificultad utiliza exclusivamente `exercise.difficulty`. Se presentan «Todas», «Inicial», «Intermedio» y «Avanzado» con una aclaración visible: «La dificultad es editorial; no equivale a un nivel HSK». No se deben llamar HSK 1–6, introducir una versión HSK de manera implícita ni atribuir un nivel de dominio al usuario.

Una unidad tiene el ID estable del contraste, las dos palabras y un título derivado de `comparisonTitle(contrast)`. Una lección tiene el ID, nombre e intención de una situación existente. Al filtrar dificultad, la unidad muestra solo situaciones que tienen un ejercicio con esa dificultad. En el banco actual ambos ejercicios de cada situación comparten dificultad. Los contrastes sin ejercicios se distinguen como «Comparaciones sin lecciones», con acceso al comparador y sin CTA de práctica.

Los niveles HSK futuros requieren primero declarar el estándar, incorporar clasificación revisada y definir un currículo. La arquitectura debe permitir otra taxonomía en el futuro sin renderizar niveles, unidades o porcentajes ficticios hoy.

### Elementos y rutas propuestos

| Elemento | Contrato |
| --- | --- |
| Ruta y vista | `#aprender`, `#tab-aprender`, `#view-aprender`, `#h-aprender` |
| Selector | `select#learn-level`, valores `all`, `inicial`, `intermedio`, `avanzado`; etiqueta «Dificultad del ejercicio» |
| Índice de unidades | `#learn-unit-list`, botones `[data-learn-unit="<contrast.id>"]` |
| Unidad seleccionada | `#learn-unit-detail`; muestra título, palabras, lecciones y estado auténtico |
| Entrar a una lección | `[data-start-lesson="<scenario.id>"]` |
| Consultar la situación | `[data-lesson-context="<scenario.id>"]` |
| Progreso | `#learn-progress`; cuenta situaciones practicadas, nunca maestría o completitud ficticia |
| Nota de currículo | `#learn-curriculum-note`; estado del contenido y ausencia de clasificación HSK |
| Regreso de práctica | `#practice-back`; vuelve a Aprender con filtro y unidad de origen retenidos |

Estado UI mínimo: `learnLevel = 'all'`, `learnUnit = contrast.id`, `lessonOrigin = {contrastId, scenarioId}` para sesión dirigida o `null` para práctica adaptativa. Cambiar un filtro conserva la unidad si sigue disponible y selecciona una unidad existente si no. Un selector nativo permite acceso inmediato a cualquier dificultad sin atravesar una columna de otras dificultades.

### Sesiones dirigidas y preservación

`startDirectedLesson(scenarioId)` debe comprobar que la situación existe, obtener sus dos ejercicios reales y llamar `prepareSession`. Los datos, tipos, opciones y claves se usan sin cambios. Dos respuestas en esa sesión generan dos intentos legítimos para la misma situación mediante `S.update`, tal como ya permite el formato. Las respuestas transitorias permanecen separadas por `exercise.id`. La práctica adaptativa conserva su selección de 8 situaciones, rotación y agenda.

La sesión dirigida de dos ejercicios es una organización del contenido recibido; no valida la calidad lingüística ni obliga a representar una lección como aprobada. El resultado «N de 2 coincidencias» describe exclusivamente las respuestas de esa sesión. Regresar a Aprender conserva su contexto y actualiza el número de situaciones practicadas.

### Progreso real calculable

Una situación ha sido practicada si `history[scenario.id]?.attempts > 0`. Para una unidad o dificultad: `vistas = situaciones filtradas que tienen attempts > 0`, `total = situaciones filtradas disponibles`. La etiqueta exacta recomendable es «N de M situaciones practicadas» o «N de M lecciones practicadas». No utilizar «N lecciones completadas», «HSK superado», «dominio» ni porcentaje de aprendizaje.

Una situación practicada puede tener una o dos preguntas distintas respondidas; el historial no distingue esos casos. `correct / attempts` mide coincidencias con la clave provisional a través de intentos, no lecciones finalizadas ni conocimiento adquirido. No utilizar `streak` como una racha diaria porque es una racha de coincidencias por situación.

Guardar, dejar de guardar, borrar y trabajar sin almacenamiento deben seguir funcionando. Las ayudas no registran intentos. Abrir o revisar una lección, contexto o comparación no modifica el historial hasta comprobar una respuesta nueva.

## Limitaciones que deben permanecer visibles

- No hay currículo HSK implementado ni clasificación validada.
- No hay lecciones o ejercicios para 3 de los 14 contrastes.
- El banco y sus claves siguen pendientes de revisión lingüística y editorial.
- No hay pinyin validado de las frases completas.
- No hay persistencia de finalización por ejercicio, unidad o lección; el progreso es por situación practicada.
- No hay cuentas ni sincronización.
- La lectura asociada a cada acepción de 行 aún no está modelada.

## Comprobaciones necesarias para la implementación

1. Abrir cada dificultad directamente y comprobar 6, 4 y 5 situaciones respectivamente; Todas suma 15, no 16.
2. Comprobar 11 unidades únicas practicables, 3 comparaciones consultables sin lecciones y ningún nivel HSK inventado.
3. Iniciar una lección y comprobar que sus dos IDs de ejercicio corresponden a la situación elegida.
4. Resolver ambos ejercicios; verificar 2 intentos nuevos, resultado de sesión correcto y solo 1 situación nueva practicada.
5. Revisar una respuesta sin aumentar intentos; regresar a la unidad con filtro conservado.
6. Repetir una no coincidencia usando el ejercicio real y actualizando el historial una sola vez.
7. Seguir usando la sesión adaptativa original, las ayudas, búsquedas y rutas con Back/Forward.
8. Verificar guardado opcional, recarga, rechazo de historial inválido y borrado.
9. Verificar pregunta, opciones, retroalimentación esencial y acciones dentro del viewport normal, además de acceso a toda explicación extensa mediante desplazamiento interno o revelación explícita.

Estas pruebas fueron requisitos identificados en la auditoría previa; este apartado no las declara ejecutadas. El estado final debe consultarse en el informe de validación independiente.


## Implementación V29 observada en las fuentes

Esta sección describe `assets/app.js`, `index.template.html`, `assets/styles.css` y `assets/tools.css` tras la reconstrucción. Se distingue de la propuesta histórica anterior. Su comprobación de navegador está registrada por separado en el estado final y en VALIDACION_V29.json.

### Aprender y currículo realmente presentado

- Se incorporó `#aprender` a las rutas, las cinco pestañas de herramientas y el selector móvil `#mobile-tool-select`.
- `#learn-level` ofrece acceso directo a `all`, `inicial`, `intermedio` y `avanzado`. La etiqueta es «Dificultad del ejercicio» y una nota explica que los niveles HSK no están asignados ni validados.
- Se presentan las 14 unidades derivadas de los contrastes reales. 11 tienen lecciones practicables; 3 permanecen exclusivamente de consulta. El índice no inventa unidades futuras.
- La lista conserva las 14 unidades al cambiar dificultad. Cada unidad muestra «N situaciones», «Otra dificultad» si tiene casos en otro filtro, o «Consulta» si no tiene situaciones. No se confunden «Otra dificultad» y contenido inexistente.
- `#learn-unit-select` permite elegir una unidad directamente, especialmente en móvil, además del índice `[data-learn-unit]` de escritorio. No exige recorrer otras dificultades para llegar a una unidad.
- `unitLessons` selecciona situaciones reales del contraste con ejercicios de la dificultad elegida. Las lecciones usan el nombre y la intención existentes; `[data-start-lesson]` inicia sus dos IDs de ejercicio originales y `[data-lesson-context]` abre su situación en contexto.
- Las unidades sin ejercicios del filtro no presentan un botón de práctica ficticio. Ofrecen consultar la comparación y un mensaje que distingue ausencia de dificultad de ausencia de lecciones.
- Al cambiar dificultad se conserva la unidad si tiene ejercicios de ese filtro; si no, se selecciona una unidad existente que sí los tiene. Entrar a una sesión dirigida fija la unidad de origen; regresar conserva la selección en memoria.

### Progreso y sesión dirigida

`#learn-progress` muestra el total global real «N de 15 situaciones practicadas», incluso cuando hay un filtro de dificultad. La unidad muestra su cuenta local de situaciones disponibles y practicadas. Una situación se marca como practicada si su historial tiene `attempts > 0`; no se presenta como completada o dominada. El historial se vuelve a representar al registrar un intento y al regresar a Aprender.

La función implementada es `startPractice(ids, {title, origin})`. Valida entre 1 y 8 IDs existentes y distintos. Cuando existe origen, comprueba que la situación pertenezca al contraste indicado y que los ejercicios pertenezcan a esa situación. Una lección del banco actual aporta dos ejercicios reales. `practiceOrigin` retiene contraste y situación; `learnLevel` y `learnUnit` conservan la selección durante la sesión.

La agenda ordinaria sigue pasando por `S.schedule` con límite 8 y conserva un ejercicio por situación. `startSession` elimina el origen dirigido. Cada nueva comprobación sigue utilizando `S.update`, el mismo espacio de almacenamiento y el mismo formato de historial. La revisión de una respuesta usa `responses[exercise.id]` y no vuelve a actualizar el historial. El resultado de dos ejercicios es un resultado de sesión; el historial longitudinal continúa sin representar finalización por ejercicio o lección.

La API de inspección técnica conserva `window.HanYuMatizP10.inspect` y añade datos de sesión, respuesta, selección académica y origen. Expone `startPractice` para iniciar únicamente ejercicios existentes. Estas funciones ayudan a comprobar los IDs reales; no constituyen contenido pedagógico nuevo.

### Práctica reconstruida como actividad

- El encabezado general y el pie de consulta dejan de ocupar espacio durante la actividad. La sesión usa `.practice-stage`, una retícula de `100dvh` con encabezado compacto, región central flexible y barra inferior.
- `#practice-scroll` es la única región central desplazable cuando la altura, el zoom o el detalle extenso lo requieren. Tiene nombre accesible, foco de teclado y aviso `#practice-scroll-hint` calculado a partir de su altura real con `ResizeObserver`.
- `#practice-actions` está fuera de `#exercise`, dentro de la barra inferior. Comprobar, continuar, resultados y repetir se representan allí; la explicación no puede empujarlos al final del documento.
- El nombre de situación pasa al encabezado compacto. La pregunta conserva `prompt_es`, la intención conserva `intent_es` y la frase conserva `template_zh`; se eliminan las repeticiones de título y consigna de V28.
- Las opciones se mantienen junto a la frase. Después de responder conservan la elección y la clave, con texto de estado además del color.
- La retroalimentación esencial muestra coincidencia, clave provisional y comparación existente. Las dos versiones, notas y explicación completa permanecen disponibles en un `details`; se revelan sin eliminar contenido.
- El mapa de sesión y los controles de progreso se trasladan a `dialog#practice-menu`. Se cierra con Escape y devuelve foco al control de apertura; no contribuye a la altura ordinaria de la actividad.
- `renderTrainer` reemplaza la pregunta anterior. Conserva el desplazamiento interno al seleccionar o abrir ayudas, y lo reinicia al avanzar o mostrar resultados. El foco se gestiona dentro de la región central mediante `focusInPractice`.
- El resultado tiene un estado visual independiente (`data-phase="summary"`), enumera las respuestas reales, permite revisarlas y repetir los ejercicios que no coinciden con la clave.

Estas reglas implementan la estructura solicitada; la ausencia de desplazamiento principal y la visibilidad de opciones y acciones deben verificarse por rectángulos de renderizado en el navegador, no deducirse únicamente del CSS.

### Integración de las herramientas

La portada incorpora acceso directo a Aprender y mantiene búsqueda, demostración e ilustración originales. El diccionario conserva los datos y conexiones con una jerarquía de consulta propia. El comparador sustituye la matriz administrativa de V28 por dos columnas de significado y función, manteniendo cautelas, registro y ejemplos reales. En contexto presenta primero situación, frase y nota seleccionada; un control «Ver las dos versiones» revela el análisis completo. Los datos lingüísticos no se han reescrito para estos layouts.

La identidad se comparte mediante sello rectangular, fondo de papel cálido, tinta, jade, cinabrio y reglas dobles. La tipografía china sigue siendo Song legible; la escritura continúa simplificada. El pinyin existente usa `ruby` donde debe alinearse y la convención rojo/naranja/verde/azul/gris para los tonos 1/2/3/4/neutro, conservando los diacríticos como señal adicional. No se genera fonética de frases completas ausente del banco.

### Estado de comprobación

La comparación de archivos con el ZIP entregado de V28 confirma que `data/vocabulary.json` y `assets/scheduler.js` permanecen idénticos. Esta es una comprobación de conservación de fuentes, no una prueba de funcionamiento.

La campaña final se completó en Chromium: 15/15 comprobaciones, las nueve resoluciones solicitadas, 54 combinaciones de vista y tamaño, 72 pasos de práctica, el banco completo en tres escritorios y zoom nativo al 200 %. [VALIDACION_V29.json](VALIDACION_V29.json) conserva geometría real, resultados, 97 capturas, el SHA-256 del HTML y sus límites. Pasaron filtros, sesión dirigida, regreso, progreso, revisión y repaso sin duplicar intentos. Safari, Firefox y dispositivos físicos no se probaron. La prueba de interfaz no valida el contenido lingüístico ni convierte la dificultad editorial en nivel HSK.
