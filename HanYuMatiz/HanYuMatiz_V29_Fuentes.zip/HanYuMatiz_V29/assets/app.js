/* HanYuMatiz P10 (hardened), standalone, data never approved for commercial release. */
'use strict';
(()=>{
const rawPayload=document.getElementById('payload').textContent;
if(rawPayload.length>16*1024*1024)throw Error('Payload excede límite');
const DATA=JSON.parse(rawPayload);
if(DATA.public_use!==false||DATA.linguistic_approved!==false||DATA.rights_approved!==false)throw Error('Demo contract is not valid');
const S=window.HanYuScheduler;
if(!S)throw Error('Adaptive module unavailable');
const get=id=>document.getElementById(id);
const el=(tag,cls,content)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(content!==undefined)n.textContent=String(content);return n;};
const add=(parent,...nodes)=>{nodes.forEach(n=>parent.append(n));return parent;};
function pill(text,kind=''){return el('span','tiny-tag '+kind,text)}
function para(text,cls=''){return el('p',cls,text)}
function ruby(word,syllables,size=''){
 const wrap=el('span',size);wrap.lang='zh-Hans'; const chars=Array.from(word);
 if(!Array.isArray(syllables)||chars.length!==syllables.length){wrap.textContent=word;return wrap;}
 chars.forEach((char,i)=>{const r=el('ruby'),pronunciation=el('rt','t'+syllables[i].tone,syllables[i].pinyin);pronunciation.lang='zh-Latn-pinyin';add(r,document.createTextNode(char),pronunciation);wrap.append(r)});
 return wrap;
}
function pinyinText(value,cls=''){
 const wrap=el('span',cls);wrap.lang='zh-Latn-pinyin';
 const syllables=value?.syllables;
 if(!Array.isArray(syllables)||syllables.map(s=>s.pinyin).join('')!==value.pinyin){wrap.textContent=value?.pinyin||'';return wrap;}
 syllables.forEach(s=>wrap.append(el('span','tone t'+s.tone,s.pinyin)));return wrap;
}
const words=DATA.words,contrasts=DATA.contrasts,scenarios=DATA.scenarios,exercises=DATA.exercises;
const byId=new Map(words.map(x=>[x.id,x]));
const byZh=new Map(words.map(x=>[x.zh,x]));
const LIST_LIMIT=40;
const listLimits={word:LIST_LIMIT,pair:LIST_LIMIT,scene:LIST_LIMIT};
function appendMore(container,total,key,redraw){
 const old=container.parentNode.querySelector(':scope > .load-more');if(old)old.remove();
 if(total<=listLimits[key])return;
 const b=el('button','load-more',`Mostrar más (${Math.min(total,listLimits[key])} de ${total})`);b.type='button';
 b.onclick=()=>{const start=listLimits[key];listLimits[key]+=LIST_LIMIT;redraw();container.querySelectorAll('button')[start]?.focus()};container.parentNode.append(b);
}
const STORAGE_LIMIT=1024*1024;
for(const id of ['word-search','pair-search','scene-search'])get(id).maxLength=120;
const announce=(msg)=>{get('a11y-announcement').textContent=msg;};
const exerciseById=new Map(exercises.map(x=>[x.id,x]));
const current={word:words[0].id,pair:contrasts[0].id,scene:scenarios[0].id,sceneOption:'a'};
function reading(w){return w.readings[0]}
function wordRuby(zh){const w=byZh.get(zh);return w?ruby(zh,reading(w).syllables):el('span','',zh)}
function empty(container,message){container.replaceChildren(el('p','empty',message))}
const MODES=['aprender','buscar','comparar','simular','practicar'];
const MODE_TITLES={aprender:'Aprender',buscar:'Diccionario',comparar:'Comparar',simular:'En contexto',practicar:'Practicar'};
let activeScreen='inicio';
function enterContent(node){
 if(!node||window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
 node.classList.remove('content-enter');
 void node.offsetWidth;
 node.classList.add('content-enter');
}
function setRoute(id){
 if(window.location.hash==='#'+id)return;
 try{window.history.pushState(null,'','#'+id)}catch{window.location.hash=id;}
}
function closeForgetConfirmation(){const box=get('forget-confirm');if(box)box.hidden=true;}
function showLanding(focusHeading=false,updateRoute=true){
 const wasChoosingScene=closeScenePicker(false);
 closePracticeMenu(false);
 const changed=activeScreen!=='inicio';activeScreen='inicio';
 get('app-shell').hidden=true;get('landing').hidden=false;
 document.body.classList.remove('in-app','practice-active');closeForgetConfirmation();
 document.querySelector('.skip-link').setAttribute('href','#landing-title');
 document.title='HanYuMatiz · El chino, con matices';
 if(updateRoute)setRoute('inicio');
 if(changed){enterContent(get('landing'));window.scrollTo(0,0);}
 if(focusHeading||wasChoosingScene)get('landing-title').focus({preventScroll:true});
}
function switchTab(id,focusHeading=false,updateRoute=true){
 if(id==='inicio'){showLanding(focusHeading,updateRoute);return;}
 if(!MODES.includes(id))return;
 const wasChoosingScene=closeScenePicker(false);
 closePracticeMenu(false);
 const changed=activeScreen!==id;activeScreen=id;
 get('landing').hidden=true;get('app-shell').hidden=false;
 document.body.classList.add('in-app');closeForgetConfirmation();
 document.body.classList.toggle('practice-active',id==='practicar');
 if(get('mobile-tool-select'))get('mobile-tool-select').value=id;
 document.querySelectorAll('.tab').forEach(t=>{const active=t.dataset.tab===id;
  t.classList.toggle('active',active);t.setAttribute('aria-selected',String(active));t.tabIndex=active?0:-1;
 });
 document.querySelectorAll('.view').forEach(v=>{
  const active=v.id==='view-'+id;v.classList.toggle('active',active);v.hidden=!active;
 });
 document.querySelector('.skip-link').setAttribute('href','#h-'+id);
 document.title=MODE_TITLES[id]+' · HanYuMatiz';
 if(updateRoute)setRoute(id);
 if(changed){enterContent(get('view-'+id));window.scrollTo(0,0);}
 if(focusHeading||wasChoosingScene||(id==='practicar'&&changed)){
  if(id==='practicar')focusPracticeHeading();
  else{get('h-'+id).focus();get('h-'+id).scrollIntoView({block:'nearest'});}
 }
}
function followRoute(focusHeading=false){
 const id=window.location.hash.slice(1);
 switchTab(MODES.includes(id)?id:'inicio',focusHeading,false);
}
window.addEventListener('hashchange',()=>followRoute(window.location.hash.slice(1)!==activeScreen));
document.querySelectorAll('[data-enter]').forEach(button=>button.addEventListener('click',event=>{
 event.preventDefault();switchTab(button.dataset.enter,true);
}));
get('mobile-tool-select')?.addEventListener('change',event=>switchTab(event.target.value,true));
for(const link of document.querySelectorAll('#home-link, .brand, .landing-brand'))link.addEventListener('click',event=>{
 event.preventDefault();showLanding(true);
});
document.querySelectorAll('a[href="#primeros-pasos"]').forEach(link=>link.addEventListener('click',event=>{
 event.preventDefault();const target=get('primeros-pasos');
 target.setAttribute('tabindex','-1');target.focus({preventScroll:true});
 target.scrollIntoView({block:'start',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
}));
document.querySelector('.skip-link').addEventListener('click',event=>{
 event.preventDefault();const target=get(activeScreen==='inicio'?'landing-title':'h-'+activeScreen);
 if(activeScreen==='practicar')focusPracticeHeading();
 else{target.focus();target.scrollIntoView({block:'nearest'});}
});
const demoScenario=scenarios.find(sc=>sc.id==='scn_p5_004');
const demoExercise=exercises.find(ex=>ex.id==='ex_p6_004_principal');
let demoChoice=null,demoChecked=false;
function drawLandingDemo(choice=null,transition=false){
 if(!demoScenario||!demoExercise||(choice!==null&&!['a','b'].includes(choice)))return;
 demoChoice=choice;demoChecked=false;
 document.querySelectorAll('[data-demo-word]').forEach(button=>{
  const selected=button.dataset.demoWord===choice;
  button.disabled=false;button.setAttribute('aria-pressed',String(selected));button.classList.toggle('active',selected);
 });
 const sentence=get('landing-demo-sentence'),pieces=demoScenario.sentence.split('〔词〕');
 const slot=el('span',choice===null?'demo-blank':'demo-selected-word');
 if(choice===null){slot.textContent='＿＿';slot.setAttribute('aria-label','Palabra por completar');}
 else slot.append(ruby(demoScenario[choice],DATA.phonetics[demoScenario.id][choice]));
 sentence.replaceChildren(document.createTextNode(pieces[0]),slot,document.createTextNode(pieces[1]||''));
 sentence.lang='zh-Hans';get('landing-demo-translation').textContent=demoScenario.translation;
 get('landing-demo-note').hidden=true;get('demo-feedback-title').textContent='';get('demo-feedback-text').textContent='';
 get('demo-check').hidden=false;get('demo-check').disabled=choice===null;
 get('demo-retry').hidden=true;get('demo-continue').hidden=true;
 if(transition)enterContent(sentence);
}
document.querySelectorAll('[data-demo-word]').forEach(button=>button.addEventListener('click',()=>{
 if(demoChecked||button.getAttribute('aria-pressed')==='true')return;
 drawLandingDemo(button.dataset.demoWord,true);
}));
document.querySelectorAll('[data-demo-word]').forEach(button=>{
 const word=byZh.get(demoScenario?.[button.dataset.demoWord]),target=button.querySelector('.demo-word-meta small');
 if(word&&target)target.replaceChildren(pinyinText(reading(word)));
});
get('demo-check').addEventListener('click',()=>{
 if(demoChoice===null||demoChecked)return;
 demoChecked=true;
 document.querySelectorAll('[data-demo-word]').forEach(button=>{button.disabled=true;});
 get('demo-check').hidden=true;get('demo-retry').hidden=false;get('demo-continue').hidden=false;
 const correct=demoChoice===demoExercise.answer_key;
 const heading=get('demo-feedback-title');heading.textContent=correct?'适合 encaja aquí.':'Con 合适 cambia la frase.';
 get('demo-feedback-text').textContent=demoScenario['note_'+demoChoice]+(correct?' '+demoScenario.sentence.replace('〔词〕',demoScenario[demoChoice]):'');
 const note=get('landing-demo-note');note.hidden=false;enterContent(note);
 heading.setAttribute('tabindex','-1');heading.focus({preventScroll:true});
 note.scrollIntoView({block:'nearest',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
});
get('demo-retry').addEventListener('click',()=>{drawLandingDemo();document.querySelector('[data-demo-word="a"]').focus({preventScroll:true});});
get('demo-comparison').addEventListener('click',()=>{
 const contrast=contrasts.find(item=>item.id===demoScenario?.contrast_id);if(!contrast)return;
 current.pair=contrast.id;showPairIndex=false;get('pair-search').value='';drawPairs(true);switchTab('comparar',true);
});
function closeScenePicker(restoreFocus=true){
 const dialog=get('scene-picker');if(!dialog?.open)return false;
 dialog.close();get('scene-browse').setAttribute('aria-expanded','false');
 if(restoreFocus)get('scene-browse').focus({preventScroll:true});
 return true;
}
get('scene-browse').addEventListener('click',()=>{
 drawSceneList();get('scene-picker').showModal();get('scene-browse').setAttribute('aria-expanded','true');
 get('scene-search').focus({preventScroll:true});
});
get('scene-picker-close').addEventListener('click',()=>closeScenePicker());
get('scene-picker').addEventListener('close',()=>get('scene-browse').setAttribute('aria-expanded','false'));
get('scene-picker').addEventListener('keydown',event=>{
 if(event.key==='Escape'&&!event.isComposing){event.preventDefault();closeScenePicker();}
});
let scenePointerStartedOutside=false;
function outsideScenePicker(event){
 const dialog=get('scene-picker'),rect=dialog.getBoundingClientRect();
 return event.target===dialog&&(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom);
}
get('scene-picker').addEventListener('pointerdown',event=>{scenePointerStartedOutside=outsideScenePicker(event)});
get('scene-picker').addEventListener('click',event=>{
 if(scenePointerStartedOutside&&outsideScenePicker(event))closeScenePicker();
 scenePointerStartedOutside=false;
});
const tabs=Array.from(document.querySelectorAll('.tab'));
document.querySelector('.tabs').setAttribute('aria-orientation','horizontal');
tabs.forEach((b,i)=>{
 b.addEventListener('click',()=>switchTab(b.dataset.tab));
 b.addEventListener('keydown',e=>{
  let target=-1;
  if(e.key==='ArrowRight')target=(i+1)%tabs.length;
  else if(e.key==='ArrowLeft')target=(i-1+tabs.length)%tabs.length;
  else if(e.key==='Home')target=0;
  else if(e.key==='End')target=tabs.length-1;
  if(target<0)return;
  e.preventDefault();switchTab(tabs[target].dataset.tab);
  if(tabs[target].dataset.tab==='practicar')focusPracticeHeading();else tabs[target].focus();
 });
});
function plain(value){return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase()}
function matching(q,...texts){const term=plain(q.slice(0,120).trim());return plain(texts.join(' ')).includes(term)}
function pinyinPlain(value){return plain(String(value).replace(/ü/gi,'v').replace(/ǖ|ǘ|ǚ|ǜ/gi,'v').replace(/u:/gi,'v')).replace(/[\s'’1-5-]/g,'')}
function pinyinMatching(q,...readings){const term=pinyinPlain(q);return !!term&&readings.some(p=>pinyinPlain(p).includes(term))}
function readingsFor(...zh){return zh.flatMap(z=>byZh.get(z)?.readings.map(r=>r.pinyin)||[])}
function posLabel(pos){return ({verb:'verbo',noun:'sustantivo',adjective:'adjetivo',adverb:'adverbio',preposition:'preposición'})[pos]||pos;}
function quietLabel(txt){return el('span','micro-label',txt);}
function studioLink(label,action){const b=el('button','studio-link',label);b.type='button';b.addEventListener('click',action);return b;}
const wordIndexBreakpoint=window.matchMedia('(min-width: 1100px)');
let showWordIndex=wordIndexBreakpoint.matches,wordIndexAutomatic=true;
wordIndexBreakpoint.addEventListener('change',event=>{
 if(!wordIndexAutomatic)return;
 showWordIndex=event.matches;drawWords();
});
function updateWordBrowser(){
 const box=get('lex-browser');const input=get('word-search');const open=showWordIndex||!!input.value.trim();
 box.classList.toggle('open',open);get('lex-browse').setAttribute('aria-expanded',String(open));
 get('lex-browse').firstChild.textContent=open?'Ocultar índice ':'Ver palabras ';
 input.setAttribute('aria-expanded',String(open));
}
get('lex-browse').addEventListener('click',()=>{const open=showWordIndex||!!get('word-search').value.trim();wordIndexAutomatic=false;showWordIndex=!open;if(open)get('word-search').value='';drawWords();if(showWordIndex)get('word-list').querySelector('button')?.focus();else get('word-search').focus()});
function drawWords(transition=false){
 const q=get('word-search').value;
 const found=words.filter(x=>matching(q,x.zh,...x.readings.map(r=>r.pinyin),...x.senses.map(s=>s.gloss))||pinyinMatching(q,...x.readings.map(r=>r.pinyin)));
 get('word-count').textContent=`${found.length} de ${words.length} entradas`;
 if(!found.some(x=>x.id===current.word))current.word=found[0]?.id||null;
 const list=get('word-list');list.replaceChildren();updateWordBrowser();
 appendMore(list,found.length,'word',drawWords);
 if(!found.length){empty(list,'Sin resultados. Busca de otra forma.');empty(get('word-detail'),'No encontramos esa palabra.');return;}
 found.slice(0,listLimits.word).forEach((w,i)=>{
  const b=el('button','lex-result'+(current.word===w.id?' active':''));b.type='button';b.setAttribute('aria-pressed',String(current.word===w.id));
  add(b,el('span','lex-result-word',w.zh),pinyinText(reading(w),'lex-result-reading'),el('span','lex-result-gloss',w.senses[0].gloss));
  b.querySelector('.lex-result-word').lang='zh-Hans';b.querySelector('.lex-result-reading').lang='zh-Latn-pinyin';
  b.addEventListener('click',()=>{current.word=w.id;wordIndexAutomatic=true;showWordIndex=wordIndexBreakpoint.matches;get('word-search').value='';drawWords(true);get('lex-entry-next')?.focus()});list.append(b);
 });
 const w=byId.get(current.word),d=get('word-detail');d.replaceChildren();
 const index=words.findIndex(x=>x.id===w.id);
 const root=el('article','lex-entry');
 const meta=el('div','lex-entry-meta');
 const pos=el('span','lex-position',`Palabra ${index+1} de ${words.length}`);
 const pager=el('div','lex-pager');
 for(const [label,offset,id] of [['← Anterior',-1,'lex-entry-prev'],['Siguiente →',1,'lex-entry-next']]){
  const btn=el('button','lex-page-button',label);btn.type='button';btn.id=id;
  btn.onclick=()=>{const next=words[(index+offset+words.length)%words.length];current.word=next.id;get('word-search').value='';wordIndexAutomatic=true;showWordIndex=wordIndexBreakpoint.matches;drawWords(true);get(id)?.focus()};pager.append(btn);
 }
 add(meta,pos,pager);root.append(meta);
 const hero=el('div','lex-feature');
 const glyph=el('div','lex-glyph');const hanzi=wordRuby(w.zh);hanzi.className='lex-glyph-zh';glyph.append(hanzi);
 if(!Array.isArray(reading(w).syllables)||reading(w).syllables.length!==Array.from(w.zh).length){
  const pron=el('div','lex-glyph-pron');add(pron,pinyinText(reading(w),'lex-glyph-pron-value'));glyph.append(pron);
 }
 const meaning=el('div','lex-definition');add(meaning,el('h3','lex-definition-main',w.senses[0].gloss));
 const roles=el('div','lex-role');add(roles,el('strong','',w.senses.map(s=>posLabel(s.pos)).filter((v,i,a)=>a.indexOf(v)===i).join(' · ')));meaning.append(roles);
 add(hero,glyph,meaning);root.append(hero);
 const bottom=el('div','lex-depth');
 const uses=w.senses.length>1?el('section','lex-uses'):null;
 if(uses){
  uses.append(el('h4','','Sentidos'));
  w.senses.forEach((sense,n)=>{const line=el('div','lex-use');add(line,el('small','',String(n+1).padStart(2,'0')),el('p','',sense.gloss),el('span','',posLabel(sense.pos)));uses.append(line)});
 }
 if(w.readings.length>1){const alt=el('p','lex-alt-reading','Otra lectura: ');w.readings.slice(1).forEach((value,index)=>{if(index)alt.append(document.createTextNode(' · '));alt.append(pinyinText(value));});(uses||root).append(alt)}
 const next=el('section','lex-connections');next.append(el('h4','','Palabras que conviene comparar'));
 const related=contrasts.filter(c=>c.word_id_a===w.id||c.word_id_b===w.id);
 if(!related.length)next.append(para('Aún no hay comparaciones para esta entrada.','lex-quiet'));
 related.forEach(c=>{const opposite=c.word_id_a===w.id?c.b:c.a;const b=el('button','lex-compare-link');b.type='button';add(b,el('span','lex-compare-name',opposite),el('span','lex-compare-topic',c.word_id_a===w.id?c.sense_b:c.sense_a),el('span','lex-compare-arrow','→'));b.querySelector('.lex-compare-name').lang='zh-Hans';b.onclick=()=>{current.pair=c.id;get('pair-search').value='';drawPairs();switchTab('comparar',true)};next.append(b)});
 if(uses)bottom.append(uses);bottom.append(next);
 const example=scenarios.find(sc=>(sc.a===w.zh&&sc.fit_a!=='requires_reformulation')||(sc.b===w.zh&&sc.fit_b!=='requires_reformulation'));
 if(example){
  const key=example.a===w.zh?'a':'b';const block=el('section','lex-example');const cap=el('div','lex-example-caption');
  add(cap,el('h4','','En una frase'),studioLink('Ver el contexto →',()=>{current.scene=example.id;current.sceneOption=key;get('scene-search').value='';drawScenes();switchTab('simular',true)}));block.append(cap);
  const phrase=el('p','zh');phrase.lang='zh-Hans';const pieces=example.sentence.split('〔词〕');add(phrase,document.createTextNode(pieces[0]),ruby(w.zh,reading(w).syllables),document.createTextNode(pieces[1]||''));
  add(block,phrase,para(example.translation,'translation'));root.append(block);
 }
 root.append(bottom);
 root.append(el('p','lex-disclaimer','Significados y ejemplos en revisión.'));
 d.append(root);
 if(transition)enterContent(root);
}
get('word-search').addEventListener('input',()=>{listLimits.word=LIST_LIMIT;drawWords();announce(get('word-count').textContent);});
function searchFromLanding(query){
 const value=String(query??'').slice(0,120).trim();
 const input=get('word-search');input.value=value;listLimits.word=LIST_LIMIT;
 drawWords(true);switchTab('buscar');announce(get('word-count').textContent);
 const heading=value&&current.word?get('word-detail').querySelector('.lex-definition-main'):null;
 if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});heading.scrollIntoView({block:'nearest'});}
 else input.focus({preventScroll:true});
}
const landingSearch=get('landing-search'),landingSearchForm=get('landing-search-form');
if(landingSearch){
 landingSearch.maxLength=120;
 const submitLandingSearch=event=>{event.preventDefault();searchFromLanding(landingSearch.value);};
 if(landingSearchForm)landingSearchForm.addEventListener('submit',submitLandingSearch);
 else{
  get('landing-search-submit')?.addEventListener('click',submitLandingSearch);
  landingSearch.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.isComposing)submitLandingSearch(event);});
 }
}
document.querySelectorAll('[data-landing-query]').forEach(button=>button.addEventListener('click',event=>{
 event.preventDefault();const query=button.dataset.landingQuery;
 if(landingSearch)landingSearch.value=query;
 searchFromLanding(query);
}));
document.querySelectorAll('[data-landing-query]').forEach(button=>{const word=byZh.get(button.dataset.landingQuery),target=button.querySelector('small');if(word&&target)target.replaceChildren(pinyinText(reading(word)));});
let showPairIndex=false;
get('pair-browse').addEventListener('click',()=>{const open=showPairIndex||!!get('pair-search').value.trim();showPairIndex=!open;if(open)get('pair-search').value='';drawPairs();if(showPairIndex)get('pair-list').querySelector('button')?.focus();else get('pair-search').focus()});
function comparisonTitle(c){return c.topic.includes('rasgos editoriales')?`${c.sense_a} / ${c.sense_b}`:c.topic}
function drawPairs(transition=false){
 const q=get('pair-search').value;
 const found=contrasts.filter(c=>matching(q,c.a,c.b,c.topic,c.sense_a,c.sense_b)||pinyinMatching(q,...readingsFor(c.a,c.b)));
 get('pair-count').textContent=`${found.length} / ${contrasts.length}`;
 if(!found.some(x=>x.id===current.pair))current.pair=found[0]?.id||null;
 const list=get('pair-list');list.replaceChildren();
 const open=showPairIndex||!!q.trim();
 get('contrast-catalog').classList.toggle('open',open);
 get('pair-browse').setAttribute('aria-expanded',String(open));
 get('pair-browse').firstChild.textContent=open?'Cerrar comparaciones ':'Ver comparaciones ';
 get('pair-search').setAttribute('aria-expanded',String(open));
 appendMore(list,found.length,'pair',drawPairs);
 if(!found.length){empty(list,'No encontramos ese contraste.');empty(get('pair-detail'),'Prueba con otra palabra.');return;}
 found.slice(0,listLimits.pair).forEach(c=>{
  const b=el('button','contrast-result'+(c.id===current.pair?' active':''));b.type='button';b.setAttribute('aria-pressed',String(c.id===current.pair));
  add(b,el('span','contrast-result-zh',`${c.a} / ${c.b}`),el('span','contrast-result-label',comparisonTitle(c)));
  b.querySelector('.contrast-result-zh').lang='zh-Hans';
  b.addEventListener('click',()=>{current.pair=c.id;showPairIndex=false;get('pair-search').value='';drawPairs(true);get('h-comparar').focus()});list.append(b)
 });
 const c=found.find(x=>x.id===current.pair),d=get('pair-detail');d.replaceChildren();
 const page=el('article','contrast-page');
 add(page,el('span','contrast-page-caption','Dos palabras, dos matices'),el('h3','contrast-page-title',comparisonTitle(c)));
 const track=el('div','contrast-track');
 for(const [side,label] of [['a','Primera palabra'],['b','Segunda palabra']]){
  const line=el('div','contrast-line '+side);
  const w=byZh.get(c[side]);
  const sign=el('div','contrast-sign');add(sign,el('small','',label),el('strong','',c[side]));sign.lastChild.lang='zh-Hans';
  const explain=el('div','contrast-explain');
  const pronunciation=el('small');if(w)pronunciation.append(pinyinText(reading(w)));explain.append(pronunciation);
  add(line,sign,explain);track.append(line);
 }
 page.append(track);
 const meanings=el('section','contrast-meaning-grid');meanings.setAttribute('aria-label','Significado y función de cada palabra');
 for(const side of ['a','b']){
  const meaning=el('section','contrast-meaning '+side),caption=el('p','contrast-meaning-word',c[side]);caption.lang='zh-Hans';
  add(meaning,caption,el('h4','contrast-sense',c['sense_'+side]),para(posLabel(c['pos_'+side]),'contrast-function'));meanings.append(meaning);
 }page.append(meanings);
 const register=el('p','contrast-register');add(register,el('strong','','Registro · '),document.createTextNode(c.signals.same_register?'Provisionalmente similar.':'Puede variar entre las dos expresiones; sin confirmar.'));page.append(register);
 const analysis=el('div','contrast-observations');
 const s=c.signals;
 const frames=s.shared_frames.filter(x=>x&&!x.includes('_'));
 if(frames.length){const what=el('section','contrast-about');add(what,el('h4','','Construcciones registradas'),para(frames.join(', ')));analysis.append(what)}
 const caution=el('section','contrast-caution');caution.append(el('h4','','Cuándo no confundirlas'));
 if(c.cautions?.length)c.cautions.forEach((x,i)=>{const row=el('p','');row.textContent=x;caution.append(row)});
 else caution.append(para('Aún no se ha revisado la intercambiabilidad de estas palabras.'));
 analysis.append(caution);page.append(analysis);
 const scenes=scenarios.filter(sc=>sc.contrast_id===c.id);
 const next=el('section','contrast-next');next.append(el('h4','','Pruébalo en una oración'));
 if(scenes.length)scenes.forEach(sc=>{const b=el('button','contrast-scene-link');b.type='button';const copy=el('span','contrast-scene-copy'),sentence=el('span','contrast-scene-sentence',sc.sentence.replace('〔词〕','…'));sentence.lang='zh-Hans';add(copy,el('span','contrast-scene-label',sc.label),sentence);add(b,copy,el('span','contrast-scene-arrow','→'));b.onclick=()=>{current.scene=sc.id;current.sceneOption='a';get('scene-search').value='';drawScenes();switchTab('simular',true)};next.append(b)});
 else next.append(para('Todavía no hay situaciones redactadas para esta comparación.'));
 page.append(next);page.append(el('p','lex-disclaimer','Comparaciones provisionales: estas explicaciones requieren validación lingüística antes de publicarse.'));
 d.append(page);
 if(transition)enterContent(page);
}
get('pair-search').addEventListener('input',()=>{listLimits.pair=LIST_LIMIT;drawPairs();announce(get('pair-count').textContent);});
const fitLabel={preferred_in_context:'Matiz preferido en este caso',possible_with_nuance:'Posible, con matiz distinto',requires_reformulation:'Requiere revisar la estructura'};
function drawSceneList(){
 const q=get('scene-search').value,found=scenarios.filter(x=>matching(q,x.label,x.intent,x.a,x.b,x.comparison)||pinyinMatching(q,...readingsFor(x.a,x.b)));
 get('scene-count').textContent=`${found.length} de ${scenarios.length} situaciones`;
 const list=get('scene-list');list.replaceChildren();
 appendMore(list,found.length,'scene',drawSceneList);
 if(!found.length){empty(list,'No encontramos esa situación. Prueba otra palabra.');return;}
 found.slice(0,listLimits.scene).forEach(sc=>{
  const selected=sc.id===current.scene,button=el('button','list-item'+(selected?' active':''));button.type='button';
  button.setAttribute('aria-pressed',String(selected));button.setAttribute('aria-label',sc.label+': '+sc.a+' / '+sc.b);
  const pair=el('span','scene-item-pair',sc.a+' / '+sc.b);pair.lang='zh-Hans';
  add(button,el('span','scene-item-title',sc.label),pair);
  button.addEventListener('click',()=>{
   current.scene=sc.id;current.sceneOption='a';get('scene-search').value='';drawScenes(true);closeScenePicker(false);
   const heading=get('h-simular');heading.focus({preventScroll:true});
   heading.scrollIntoView({block:'nearest',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
  });list.append(button);
 });
}
function drawScenes(transition=false){
 const keepAnalysisOpen=transition==='choice'&&!!get('scene-detail').querySelector('.context-analysis')?.open;
 drawSceneList();
 const sc=scenarios.find(x=>x.id===current.scene)||scenarios[0];if(!sc)return;
 current.scene=sc.id;
 get('scene-current-label').textContent=sc.label;
 get('scene-browse').setAttribute('aria-label','Cambiar situación. Actual: '+sc.label);
 const choice=current.sceneOption,d=get('scene-detail');d.replaceChildren();
 const study=el('article','context-study'),lead=el('header','context-lead');
 add(lead,el('h3','',sc.label),para(sc.intent,'context-intent'));study.append(lead);
 const options=el('div','choice-row');options.setAttribute('aria-label','Palabra de la oración');
 for(const key of ['a','b']){
  const button=el('button',choice===key?'active':'');button.type='button';button.setAttribute('aria-pressed',String(key===choice));button.append(ruby(sc[key],DATA.phonetics[sc.id][key]));
  button.onclick=()=>{if(current.sceneOption===key)return;current.sceneOption=key;drawScenes('choice');get('scene-detail').querySelectorAll('.choice-row button')[key==='a'?0:1].focus({preventScroll:true});};options.append(button);
 }study.append(options);
 const result=el('div','sentence-box');result.lang='zh-Hans';const pieces=sc.sentence.split('〔词〕');
 if(pieces.length===2)add(result,document.createTextNode(pieces[0]),ruby(sc[choice],DATA.phonetics[sc.id][choice]),document.createTextNode(pieces[1]));else result.textContent=sc.sentence;
 add(study,result,para(sc.translation,'speaker'));
 const fit=sc['fit_'+choice],explain=el('section','callout'+(fit==='requires_reformulation'?' caution':''));
 add(explain,pill(fitLabel[fit]||'Requiere revisión',fit==='requires_reformulation'?'bad':''),para(sc['note_'+choice]));
 if(fit==='requires_reformulation')explain.append(para('No se afirma que la oración resultante sea correcta. Haría falta adaptar la construcción.','notice'));
 study.append(explain);d.append(study);
 const analysis=el('details','context-analysis');analysis.open=keepAnalysisOpen;analysis.append(el('summary','','Ver las dos versiones'));
 const versions=el('section','context-versions');versions.setAttribute('aria-label','Las dos versiones de la oración');
 for(const key of ['a','b']){
  const versionFit=sc['fit_'+key],version=el('article','context-version'+(versionFit==='preferred_in_context'?' preferred':'')+(versionFit==='requires_reformulation'?' reformulation':'')+(key===choice?' active':''));
  const caption=el('div','context-version-caption'),word=el('strong','context-version-word',sc[key]);word.lang='zh-Hans';
  add(caption,word,el('span','context-version-fit',fitLabel[versionFit]||'Requiere revisión'));version.append(caption);
  const sentence=el('p','context-version-sentence');sentence.lang='zh-Hans';const parts=sc.sentence.split('〔词〕');
  add(sentence,document.createTextNode(parts[0]),ruby(sc[key],DATA.phonetics[sc.id][key]),document.createTextNode(parts[1]||''));
  add(version,sentence,para(sc['note_'+key],'context-version-note'));versions.append(version);
 }
 add(analysis,versions,para(sc.comparison,'context-comparison'),el('p','hint','Estos juicios de naturalidad siguen siendo hipótesis. Necesitan revisión de un especialista y ejemplos de contraste.'));d.append(analysis);
 const other=el('button','btn ghost','Intercambiar palabras');other.id='scene-swap';other.type='button';other.onclick=()=>{current.sceneOption=choice==='a'?'b':'a';drawScenes('choice');get('scene-swap').focus({preventScroll:true});announce('Ahora se muestra '+sc[current.sceneOption]);};
 add(d,other,para('Caso de estudio · Contenido en revisión.','lex-disclaimer'));
 if(transition==='choice'){enterContent(result);enterContent(explain);}else if(transition)enterContent(d);
}
get('scene-search').addEventListener('input',()=>{listLimits.scene=LIST_LIMIT;drawSceneList();announce(get('scene-count').textContent);});
// Academic navigation reflects the existing bank: difficulty is not an HSK level.
let learnLevel='all',learnUnit=contrasts.find(c=>scenarios.some(sc=>sc.contrast_id===c.id))?.id||contrasts[0].id;
let practiceOrigin=null,practiceTitle='Sesión de matices';
function lessonExercises(scenarioId){return exercises.filter(e=>e.scenario_id===scenarioId&&(learnLevel==='all'||e.difficulty===learnLevel));}
function unitLessons(contrastId){return scenarios.filter(sc=>sc.contrast_id===contrastId&&lessonExercises(sc.id).length);}
function drawLearn(){
 if(!get('learn-unit-list')||!get('learn-unit-detail'))return;
 get('learn-level').value=learnLevel;
 const practiced=scenarios.filter(sc=>(history[sc.id]?.attempts||0)>0).length;
 get('learn-progress').textContent=`${practiced} de ${scenarios.length} situaciones practicadas`;
 get('learn-curriculum-note').textContent='El banco actual se organiza por dificultad de los ejercicios. Los niveles HSK aún no están asignados ni validados.';
 const list=get('learn-unit-list');list.replaceChildren();
 const unitSelect=get('learn-unit-select');if(unitSelect)unitSelect.replaceChildren();
 contrasts.forEach((contrast,index)=>{
  const lessons=unitLessons(contrast.id),button=el('button','learn-unit-button'+(contrast.id===learnUnit?' active':''));button.type='button';button.dataset.learnUnit=contrast.id;
  const availability=lessons.length?`${lessons.length} ${lessons.length===1?'situación':'situaciones'}`:scenarios.some(sc=>sc.contrast_id===contrast.id)?'Otra dificultad':'Consulta';
  button.setAttribute('aria-pressed',String(contrast.id===learnUnit));
  const copy=el('span','learn-unit-copy');add(copy,el('strong','',comparisonTitle(contrast)),el('small','',contrast.a+' / '+contrast.b));copy.lastChild.lang='zh-Hans';
  add(button,el('span','learn-unit-number',String(index+1).padStart(2,'0')),copy,el('span','learn-unit-state',availability));
  button.onclick=()=>{learnUnit=contrast.id;drawLearn();get('learn-unit-detail').querySelector('h3')?.focus({preventScroll:true});};list.append(button);
  if(unitSelect){const option=el('option','',`${contrast.a} / ${contrast.b} · ${comparisonTitle(contrast)} · ${availability}`);option.value=contrast.id;unitSelect.append(option);}
 });if(unitSelect)unitSelect.value=learnUnit;
 const contrast=contrasts.find(c=>c.id===learnUnit)||contrasts[0];learnUnit=contrast.id;
 const detail=get('learn-unit-detail');detail.replaceChildren();
 const head=el('header','learn-unit-heading'),title=el('h3','',comparisonTitle(contrast));title.tabIndex=-1;
 const pair=el('p','learn-unit-pair',contrast.a+' / '+contrast.b);pair.lang='zh-Hans';
 add(head,el('span','learn-unit-label','Unidad de matices'),title,pair);detail.append(head);
 const lessons=unitLessons(contrast.id);
 if(!lessons.length){
  const consult=el('section','learn-consult-only');
  const hasCases=scenarios.some(sc=>sc.contrast_id===contrast.id);
  consult.append(para(hasCases?'Esta unidad no tiene ejercicios de la dificultad seleccionada. Puedes consultar la comparación o cambiar la dificultad.':'Esta comparación todavía no tiene situaciones ni ejercicios. Está disponible como consulta.'));
  const open=el('button','btn ghost','Consultar la comparación');open.type='button';open.onclick=()=>{current.pair=contrast.id;showPairIndex=false;get('pair-search').value='';drawPairs();switchTab('comparar',true);};consult.append(open);detail.append(consult);return;
 }
 const practicedHere=lessons.filter(sc=>(history[sc.id]?.attempts||0)>0).length;
 detail.append(para(`${lessons.length} situaciones disponibles · ${practicedHere} practicadas`,'learn-unit-progress'));
 lessons.forEach((scenario,index)=>{
  const items=lessonExercises(scenario.id),lesson=el('article','learn-lesson'),copy=el('div','learn-lesson-copy');
  add(copy,el('h4','',scenario.label),para(scenario.intent),el('small','',`${items.length} ejercicios · ${items[0].difficulty}${history[scenario.id]?.attempts?' · Ya practicada':''}`));
  const actions=el('div','learn-lesson-actions'),start=el('button','btn primary','Practicar');start.type='button';start.dataset.startLesson=scenario.id;start.setAttribute('aria-label','Practicar: '+scenario.label);
  start.onclick=()=>startPractice(items.map(e=>e.id),{title:scenario.label,origin:{contrastId:contrast.id,scenarioId:scenario.id}});
  const context=el('button','text-link','Ver el contexto');context.type='button';context.dataset.lessonContext=scenario.id;context.onclick=()=>{current.scene=scenario.id;current.sceneOption='a';get('scene-search').value='';drawScenes();switchTab('simular',true);};
  add(actions,start,context);add(lesson,el('span','learn-lesson-index',String(index+1).padStart(2,'0')),copy,actions);detail.append(lesson);
 });
}
get('learn-level')?.addEventListener('change',event=>{
 learnLevel=['all','inicial','intermedio','avanzado'].includes(event.target.value)?event.target.value:'all';
 if(!unitLessons(learnUnit).length)learnUnit=contrasts.find(contrast=>unitLessons(contrast.id).length)?.id||learnUnit;
 drawLearn();announce(get('learn-progress').textContent);
});
get('learn-unit-select')?.addEventListener('change',event=>{if(contrasts.some(c=>c.id===event.target.value)){learnUnit=event.target.value;drawLearn();get('learn-unit-select').focus({preventScroll:true});}});
// Adaptive practice reuses the exact P7 rules, source fingerprint and optional storage namespace.
const STORE='hanyumatiz:internal-p7:'+DATA.sourceHash.slice(0,16);
let history={},saved=false,storageOK=true,session=[],sessionIndex=0,responses={},selected=null,sessionCount=0;
let practicePinyin=false,practiceTranslation=false;
function today(){return S.isoToday()}
function canRead(){try{localStorage.getItem(STORE);return true}catch{return false}}
storageOK=canRead();
function loadStorage(){
 if(!storageOK)return;
 try{const raw=localStorage.getItem(STORE);if(raw===null)return;
  if(raw.length>STORAGE_LIMIT)throw Error('Historial excede 1 MiB');const v=JSON.parse(raw);
  if(v.schema!==1||v.sourceHash!==DATA.sourceHash||!S.validateHistory(v.history,exercises,today()))throw Error('Historial incompatible');
  history=v.history;saved=true;
 }catch{history={};saved=false;try{localStorage.removeItem(STORE)}catch{};get('save-status').textContent='Se rechazó el historial anterior: no era compatible.';}
}
function persist(){if(!saved||!storageOK)return false;try{const serialized=JSON.stringify({schema:1,sourceHash:DATA.sourceHash,history});if(serialized.length>STORAGE_LIMIT)throw Error('Historial excede 1 MiB');localStorage.setItem(STORE,serialized);return true}catch{saved=false;return false}}
function updateStats(){
 const entries=Object.values(history),sum=field=>entries.reduce((n,p)=>n+p[field],0);
 get('m-attempts').textContent=String(sum('attempts'));get('m-matches').textContent=String(sum('correct'));
 get('m-scenes').textContent=String(entries.length);get('m-due').textContent=String(entries.filter(p=>p.due_day<=today()).length);
 get('save').textContent=saved?'Dejar de guardar':'Guardar en este navegador';get('save').setAttribute('aria-pressed',String(saved));
 get('save').disabled=!storageOK;
 get('save-status').textContent=saved?'El historial se guarda solo en este navegador.':'El historial está solo en memoria; no se guarda al cerrar.';
 if(!storageOK)get('save-status').textContent='Este navegador no permite almacenamiento local; la práctica funciona en memoria.';
 drawLearn();
}
// Question content, feedback and action bar are separate regions of one viewport.
const expandedExplanations=new Set();
function updatePracticeScrollHint(){
 const scroll=get('practice-scroll'),hint=get('practice-scroll-hint');
 if(scroll&&hint)hint.hidden=activeScreen!=='practicar'||scroll.scrollHeight<=scroll.clientHeight+1;
}
if(window.ResizeObserver){
 const practiceSizeObserver=new ResizeObserver(updatePracticeScrollHint);
 if(get('practice-scroll'))practiceSizeObserver.observe(get('practice-scroll'));
 if(get('exercise'))practiceSizeObserver.observe(get('exercise'));
}
window.addEventListener('resize',updatePracticeScrollHint);
function closePracticeMenu(restoreFocus=true){
 const dialog=get('practice-menu');if(!dialog?.open)return false;
 dialog.close();get('practice-menu-open')?.setAttribute('aria-expanded','false');
 if(restoreFocus)get('practice-menu-open')?.focus({preventScroll:true});return true;
}
get('practice-menu-open')?.addEventListener('click',()=>{get('practice-menu').showModal();get('practice-menu-open').setAttribute('aria-expanded','true');get('practice-menu-close').focus({preventScroll:true});});
get('practice-menu-close')?.addEventListener('click',()=>closePracticeMenu());
get('practice-menu')?.addEventListener('close',()=>get('practice-menu-open')?.setAttribute('aria-expanded','false'));
get('practice-menu')?.addEventListener('keydown',event=>{
 if(event.defaultPrevented||event.key!=='Escape'||event.isComposing)return;
 event.preventDefault();
 if(!get('forget-confirm').hidden){closeForgetConfirmation();get('forget').focus({preventScroll:true});}else closePracticeMenu();
});
get('practice-menu')?.addEventListener('click',event=>{
 const dialog=get('practice-menu'),rect=dialog.getBoundingClientRect();
 if(event.target===dialog&&(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom))closePracticeMenu();
});
function returnToLearning(){closePracticeMenu(false);drawLearn();switchTab('aprender',true);}
get('practice-back')?.addEventListener('click',returnToLearning);
get('practice-exit')?.addEventListener('click',returnToLearning);
function prepareSession(items,description){
 if(items.some(e=>!e))throw Error('Ejercicio no localizado');
 session=items;responses={};sessionIndex=0;sessionCount++;selected=null;expandedExplanations.clear();
 get('session-description').textContent=session.length?`Sesión ${sessionCount} · ${session.length} ejercicios · ${description}`:'No hay preguntas pendientes en esta agenda. Puedes practicar anticipadamente.';
 if(get('session-total'))get('session-total').textContent=`${session.length} ${session.length===1?'ejercicio':'ejercicios'}`;
 renderTrainer(true);
}
function startPractice(ids,{title='Sesión de matices',origin=null}={}){
 if(!Array.isArray(ids)||!ids.length||ids.length>8||new Set(ids).size!==ids.length||ids.some(id=>!exerciseById.has(id)))throw Error('La sesión debe usar entre 1 y 8 ejercicios existentes y distintos.');
 if(origin){
  const scenario=scenarios.find(sc=>sc.id===origin.scenarioId&&sc.contrast_id===origin.contrastId);
  if(!scenario||ids.some(id=>exerciseById.get(id).scenario_id!==scenario.id))throw Error('La lección no coincide con estos ejercicios.');
 }
 practiceOrigin=origin?{contrastId:origin.contrastId,scenarioId:origin.scenarioId}:null;
 practiceTitle=String(title).slice(0,120);if(practiceOrigin)learnUnit=practiceOrigin.contrastId;
 prepareSession(ids.map(id=>exerciseById.get(id)),practiceOrigin?'lección de la unidad':'práctica del banco actual');
 switchTab('practicar',true);return true;
}
function startSession(early=false){
 practiceOrigin=null;practiceTitle=early?'Repaso anticipado':'Repaso de matices';
 try{const plan=S.schedule(exercises,history,today(),{limit:8,early});
 prepareSession(plan.exercises.map(p=>exerciseById.get(p.exercise_id)),early?'repaso anticipado':'repasos pendientes y casos nuevos');
 }catch(error){empty(get('exercise'),'No se pudo preparar la sesión: '+error.message);get('practice-actions')?.replaceChildren();}
}
function focusInPractice(node){
 if(!node)return;node.tabIndex=-1;node.focus({preventScroll:true});
 const scroll=get('practice-scroll');if(!scroll)return;
 const target=node.getBoundingClientRect(),region=scroll.getBoundingClientRect();
 if(target.top<region.top)scroll.scrollTop-=region.top-target.top;
 else if(target.bottom>region.bottom)scroll.scrollTop+=target.bottom-region.bottom;
}
function focusPracticeHeading(){focusInPractice(get('exercise').querySelector('h3'));}
function reviewSessionItem(index){
 const unfinished=session.findIndex(e=>!responses[e.id]);
 if(index!==sessionIndex&&index!==unfinished&&!responses[session[index]?.id])return;
 if(index!==sessionIndex)selected=null;
 sessionIndex=index;closePracticeMenu(false);renderTrainer(true);focusPracticeHeading();
}
// Pending steps cannot skip unanswered work. Review never records another attempt.
function renderSessionMap(){
 const map=get('session-map');if(!map)return;map.replaceChildren();
 const unfinished=session.findIndex(e=>!responses[e.id]);
 session.forEach((e,index)=>{
  const answer=responses[e.id],currentStep=index===sessionIndex,sc=scenarios.find(x=>x.id===e.scenario_id);
  const button=el('button','session-step'+(currentStep?' current':'')+(answer?' answered':'')+(answer&&!answer.ok?' missed':''));button.type='button';
  button.dataset.exerciseId=e.id;button.disabled=!answer&&!currentStep&&index!==unfinished;
  if(currentStep)button.setAttribute('aria-current','step');
  const state=answer?(answer.ok?'Coincide':'Revisar'):(currentStep?'En curso':'Pendiente');
  button.setAttribute('aria-label',`${index+1}. ${sc?.label||e.intent_es}. ${e.word_a} / ${e.word_b}. ${state}`);
  const words=el('span','session-step-words',e.word_a+' / '+e.word_b);words.lang='zh-Hans';
  add(button,el('span','session-step-number',String(index+1).padStart(2,'0')),words,el('span','session-step-label',sc?.label||e.intent_es),el('span','session-step-state',state));
  button.onclick=()=>reviewSessionItem(index);map.append(button);
 });
}
function practiceSentence(e,key,cls='practice-sentence'){
 const sentence=el('div',cls);sentence.lang='zh-Hans';
 const pieces=e.template_zh.split('〔词〕'),slot=el('span','practice-sentence-slot'+(key===null?' blank':''));
 if(key===null){slot.textContent='＿＿';slot.setAttribute('aria-label','Palabra por completar');}
 else if(key==='both'){
  add(slot,ruby(e.word_a,DATA.phonetics[e.scenario_id]?.a),el('span','practice-candidate-divider',' / '),ruby(e.word_b,DATA.phonetics[e.scenario_id]?.b));
  slot.setAttribute('aria-label','Las dos opciones: '+e.word_a+' y '+e.word_b);
 }else slot.append(ruby(e['word_'+key],DATA.phonetics[e.scenario_id]?.[key]));
 add(sentence,document.createTextNode(pieces[0]),slot,document.createTextNode(pieces[1]||''));return sentence;
}
function renderSessionSummary(box,actions){
 const done=session.map(e=>({e,answer:responses[e.id]})),matches=done.filter(x=>x.answer?.ok).length;
 add(box,el('span','practice-kind','Sesión completada'),el('h3','practice-summary-title',`${matches} de ${done.length} coincidencias`),para('Revisa una respuesta para comparar las dos frases. El resultado corresponde a esta sesión.','practice-summary-note'));
 const results=el('div','session-results');
 done.forEach(({e,answer},index)=>{
  const sc=scenarios.find(x=>x.id===e.scenario_id),button=el('button','session-result'+(answer?.ok?' matched':' missed'));button.type='button';button.dataset.exerciseId=e.id;
  const text=el('span','session-result-text');add(text,el('strong','',sc?.label||e.intent_es),el('span','',e.word_a+' / '+e.word_b));text.lastChild.lang='zh-Hans';
  const chosen=e.options.find(o=>o.key===answer?.key)?.label||'Sin respuesta';
  add(button,el('span','session-result-number',String(index+1).padStart(2,'0')),text,el('span','session-result-choice',chosen),el('span','session-result-state',answer?.ok?'Coincide':'Volver a mirar'),el('span','session-result-arrow','→'));
  button.onclick=()=>reviewSessionItem(index);results.append(button);
 });box.append(results);
 const missed=done.filter(x=>x.answer&&!x.answer.ok).map(x=>x.e);actions.classList.add('summary-actions');
 if(missed.length){
  const retry=el('button','btn primary',missed.length===1?'Repasar este matiz':'Repasar estos matices');retry.id='practice-retry-missed';retry.type='button';
  retry.onclick=()=>{prepareSession(missed,'repaso de las respuestas que no coincidieron');focusPracticeHeading();};actions.append(retry);
 }
 const another=el('button','btn '+(missed.length?'ghost':'primary'),'Otra sesión');another.id='practice-another';another.type='button';another.onclick=()=>{startSession(false);focusPracticeHeading();};actions.append(another);
 box.append(para('Resultado orientativo · Claves y explicaciones en revisión lingüística.','notice'));
 get('practice-action-status').textContent=missed.length?`${missed.length} ${missed.length===1?'matiz para repasar':'matices para repasar'}`:'Has revisado todos los ejercicios de esta sesión.';
}
function renderTrainer(transition=false){
 updateStats();renderSessionMap();const box=get('exercise'),scroll=get('practice-scroll'),previousScroll=scroll?.scrollTop||0;
 box.replaceChildren();const actions=get('practice-actions');actions.replaceChildren();actions.classList.remove('summary-actions');
 const status=get('practice-action-status'),stage=document.querySelector('.practice-stage');
 const activeAnswer=responses[session[sessionIndex]?.id];status.classList.toggle('matched',!!activeAnswer?.ok);status.classList.toggle('missed',!!activeAnswer&&!activeAnswer.ok);
 if(transition===true)enterContent(box);
 requestAnimationFrame(updatePracticeScrollHint);
 const answeredCount=Object.keys(responses).length;
 if(get('session-position'))get('session-position').textContent=sessionIndex<session.length?`Pregunta ${sessionIndex+1} de ${session.length}`:`${answeredCount} de ${session.length} respondidas`;
 if(get('practice-activity-title'))get('practice-activity-title').textContent=practiceTitle;
 get('bar').parentNode.setAttribute('aria-valuenow',String(answeredCount));get('bar').parentNode.setAttribute('aria-valuemax',String(session.length));
 get('bar').parentNode.setAttribute('aria-valuetext',`${answeredCount} de ${session.length} respuestas completadas`);
 get('bar').style.width=`${session.length?100*answeredCount/session.length:0}%`;
 if(stage)stage.dataset.phase=!session.length?'empty':sessionIndex>=session.length?'summary':responses[session[sessionIndex]?.id]?'feedback':'question';
 if(!session.length){
  add(box,el('h3','','Por hoy, al día'),para('Puedes adelantar un repaso si quieres seguir practicando.'),para('La agenda de repaso es orientativa.','notice'));
  const button=el('button','btn primary','Repasar ahora');button.type='button';button.onclick=()=>{startSession(true);focusPracticeHeading();};actions.append(button);status.textContent='No hay preguntas pendientes.';if(scroll)scroll.scrollTop=0;return;
 }
 if(sessionIndex>=session.length){renderSessionSummary(box,actions);if(scroll)scroll.scrollTop=0;return;}
 const e=session[sessionIndex],sc=scenarios.find(x=>x.id===e.scenario_id),answered=responses[e.id],chosen=answered?answered.key:selected;
 if(get('practice-activity-title'))get('practice-activity-title').textContent=sc?.label||practiceTitle;
 const kinds={choice_preference:'Matiz',choice_structure:'Estructura',both_acceptable:'Validez de las dos palabras',recognize_validity:'Validez de las dos palabras'};
 const question=el('section','practice-question');
 question.append(el('span','practice-kind',`${kinds[e.kind]||'Práctica'} · ${e.difficulty}`));
 const heading=el('h3','practice-scenario',e.prompt_es);heading.id='practice-question-title';question.append(heading);
 const intent=el('div','intent');intent.append(para(e.intent_es));question.append(intent);
 const sentence=practiceSentence(e,chosen);sentence.id='practice-sentence';question.append(sentence);
 const optbox=el('div','options');optbox.setAttribute('role','group');optbox.setAttribute('aria-labelledby',heading.id);
 e.options.forEach((opt,index)=>{
  const button=el('button','option'+(opt.key==='both'?' option-both':'')+(chosen===opt.key?' active':'')+(answered&&opt.key===e.answer_key?' correct':'')+(answered&&opt.key===answered.key&&!answered.ok?' incorrect':''));button.type='button';button.dataset.choice=opt.key;button.setAttribute('aria-pressed',String(opt.key===chosen));button.disabled=!!answered;
  button.append(el('span','letter',String(index+1)));const label=el('span','option-label');
  if(opt.key==='both')label.textContent=opt.label;
  else{if(opt.label.startsWith('Solo '))label.append(document.createTextNode('Solo '));label.append(ruby(e['word_'+opt.key],DATA.phonetics[e.scenario_id]?.[opt.key]));}
  button.append(label);
  if(answered&&opt.key===e.answer_key)button.append(el('span','option-state','Clave'));
  else if(answered&&opt.key===answered.key)button.append(el('span','option-state','Tu respuesta'));
  button.onclick=()=>{if(answered)return;selected=opt.key;renderTrainer();get('exercise').querySelectorAll('.option')[index]?.focus({preventScroll:true});};optbox.append(button);
 });question.append(optbox);
 const tools=el('div','practice-tools');
 for(const [id,label,enabled,action] of [
  ['practice-pinyin','Pinyin',practicePinyin,()=>{practicePinyin=!practicePinyin;}],
  ['practice-translation','Traducción',practiceTranslation,()=>{practiceTranslation=!practiceTranslation;}]
 ]){
  const button=el('button','practice-tool'+(enabled?' active':''),label);button.id=id;button.type='button';button.setAttribute('aria-pressed',String(enabled));
  if(id==='practice-pinyin')button.setAttribute('aria-label','Pinyin de las opciones');
  button.onclick=()=>{action();renderTrainer();get(id)?.focus({preventScroll:true});};tools.append(button);
 }question.append(tools);
 const translation=para(sc?.translation||'','practice-translation');translation.id='practice-translation-text';translation.hidden=!practiceTranslation;question.append(translation);box.append(question);
 if(!answered){
  status.textContent=selected===null?'Elige una respuesta para comprobar.':'Respuesta seleccionada.';
  const check=el('button','btn primary','Comprobar');check.id='practice-check';check.type='button';check.disabled=selected===null;
  check.onclick=()=>{
   if(selected===null||responses[e.id])return;const ok=selected===e.answer_key;
   try{history[e.scenario_id]=S.update(history[e.scenario_id],ok,today());}catch(error){status.textContent='No se pudo registrar el intento: '+error.message;announce(status.textContent);return;}
   responses[e.id]={key:selected,ok};persist();renderTrainer('feedback');focusInPractice(get('practice-feedback').querySelector('.practice-feedback-title'));
   announce(ok?'Respuesta registrada. Coincide con la clave provisional.':'Respuesta registrada. Difiere de la clave provisional.');
  };actions.append(check);
 }else{
  status.textContent=answered.ok?'Coincide con la clave provisional.':'No coincide con la clave provisional.';
  const next=el('button','btn primary',sessionIndex===session.length-1?'Ver resultados':'Continuar');next.id='practice-next';next.type='button';
  next.onclick=()=>{sessionIndex++;selected=null;renderTrainer(true);focusPracticeHeading();};actions.append(next);
  const feedback=el('section','feedback'+(answered.ok?'':' warn'));feedback.id='practice-feedback';
  const feedbackTitle=answered.ok?'Coincide con el matiz buscado':'Compara tu elección con la clave';
  add(feedback,el('h4','practice-feedback-title',feedbackTitle),para('Clave provisional: '+e.options.find(opt=>opt.key===e.answer_key).label,'practice-answer-key'),para(sc?.comparison||'Esta comparación sigue pendiente de revisión.','practice-comparison-note'));
  const fullExplanation=el('details','practice-full-explanation');fullExplanation.open=expandedExplanations.has(e.id);
  fullExplanation.append(el('summary','','Comparar las dos frases y ver la explicación'));
  const comparison=el('div','answer-comparison');
  for(const key of ['a','b']){
   const fit=sc?.['fit_'+key],version=el('section','answer-version'+(fit==='preferred_in_context'?' preferred':'')+(fit==='requires_reformulation'?' reformulation':''));version.dataset.choice=key;
   const caption=el('div','answer-version-caption');add(caption,el('strong','',e['word_'+key]),el('span','answer-fit',fitLabel[fit]||'Requiere revisión'));caption.firstChild.lang='zh-Hans';version.append(caption);
   add(version,practiceSentence(e,key,'answer-version-sentence'),para(sc?.['note_'+key]||'Esta versión sigue pendiente de revisión.','answer-version-note'));
   if(fit==='requires_reformulation')version.append(para('La sustitución se muestra para comparar; esta estructura necesita reformulación.','answer-version-caution'));
   comparison.append(version);
  }
  add(fullExplanation,comparison,para(e.explanation_es,'practice-explanation'));
  const context=studioLink('Abrir esta situación en contexto',()=>{current.scene=e.scenario_id;current.sceneOption=answered.key==='b'?'b':'a';get('scene-search').value='';drawScenes();switchTab('simular',true);});context.id='practice-context';
  add(fullExplanation,context,para('Claves y explicaciones en revisión lingüística.','notice'));
  fullExplanation.addEventListener('toggle',()=>{if(fullExplanation.open)expandedExplanations.add(e.id);else expandedExplanations.delete(e.id);});
  feedback.append(fullExplanation);box.append(feedback);if(transition==='feedback')enterContent(feedback);
 }
 box.append(para(answered?'Enter: continuar':'1–'+e.options.length+': elegir · Enter: comprobar','practice-shortcuts'));
 box.querySelectorAll('rt').forEach(rt=>{rt.hidden=!practicePinyin;});
 if(scroll)scroll.scrollTop=transition===true?0:previousScroll;
}
document.addEventListener('keydown',event=>{
 if(activeScreen!=='practicar'||event.defaultPrevented||event.isComposing||event.ctrlKey||event.altKey||event.metaKey||document.querySelector('dialog[open]')||!get('forget-confirm').hidden)return;
 if(event.target.closest('input, textarea, select, a, summary, [contenteditable="true"], [role="dialog"]'))return;
 if(/^[123]$/.test(event.key)){
  const option=get('exercise').querySelectorAll('.option')[Number(event.key)-1];if(!option||option.disabled)return;
  event.preventDefault();option.click();get('exercise').querySelectorAll('.option')[Number(event.key)-1]?.focus({preventScroll:true});return;
 }
 if(event.key!=='Enter')return;
 const targetButton=event.target.closest('button');if(targetButton&&!targetButton.matches('.option, #practice-check, #practice-next'))return;
 const action=get('practice-check')||get('practice-next');if(!action||action.disabled)return;
 event.preventDefault();action.click();
});
get('save').addEventListener('click',()=>{if(!storageOK)return;if(saved){saved=false;try{localStorage.removeItem(STORE)}catch{}}else{saved=true;persist()}updateStats()});
get('forget').addEventListener('click',()=>{get('forget-confirm').hidden=false;enterContent(get('forget-confirm'));get('forget-cancel').focus()});
get('forget-cancel').addEventListener('click',()=>{closeForgetConfirmation();get('forget').focus()});
get('forget-accept').addEventListener('click',()=>{
 try{if(storageOK)localStorage.removeItem(STORE)}catch{}
 history={};saved=false;sessionCount=0;closeForgetConfirmation();startSession(false);get('forget').focus();announce('Progreso borrado. Puedes empezar una sesión nueva.');
});
get('forget-confirm').addEventListener('keydown',event=>{
 if(event.key==='Escape'){event.preventDefault();closeForgetConfirmation();get('forget').focus();}
});
function focusExercise(){focusPracticeHeading();}
get('new-session').addEventListener('click',()=>{closePracticeMenu(false);startSession(false);focusExercise()});get('early-session').addEventListener('click',()=>{closePracticeMenu(false);startSession(true);focusExercise()});
get('stat-words').textContent=String(words.length);get('stat-pairs').textContent=String(contrasts.length);get('stat-scenarios').textContent=String(scenarios.length);get('stat-exercises').textContent=String(exercises.length);
const noteToggle=document.querySelector('.about-toggle');noteToggle.onclick=()=>{const note=get('editorial-note');note.hidden=!note.hidden;noteToggle.setAttribute('aria-expanded',String(!note.hidden));};
document.querySelector('.note-close').onclick=()=>{get('editorial-note').hidden=true;noteToggle.setAttribute('aria-expanded','false');noteToggle.focus()};
for(const [id,close] of [['word-search',()=>{wordIndexAutomatic=false;showWordIndex=false;get('word-search').value='';drawWords()}],['pair-search',()=>{showPairIndex=false;get('pair-search').value='';drawPairs()}]]){get(id).addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();close();get(id).focus()}})}
drawWords();drawPairs();drawScenes();drawLandingDemo();loadStorage();startSession(false);
followRoute();
window.HanYuMatizP10={
 inspect:()=>({words:words.length,contrasts:contrasts.length,scenarios:scenarios.length,exercises:exercises.length,publicUse:DATA.public_use,attempts:Object.values(history).reduce((n,v)=>n+v.attempts,0),saved,screen:activeScreen,sessionIds:session.map(e=>e.id),sessionIndex,exerciseId:session[sessionIndex]?.id||null,answeredCount:Object.keys(responses).length,selected,answer:responses[session[sessionIndex]?.id]?{...responses[session[sessionIndex].id]}:null,learning:{difficulty:learnLevel,unit:learnUnit},origin:practiceOrigin?{...practiceOrigin}:null}),
 navigate:switchTab,startPractice
};
})();
