# HanYuMatiz · V29

Aplicación en español para estudiar diferencias de significado y uso entre palabras chinas. V29 reconstruye la navegación y las actividades de V28, conservando su contenido y su planificador de repaso.

## Abrir

Extrae el ZIP y abre **HanYuMatiz_V29.html** o, en el paquete de fuentes, **index.html**. La página contiene estilos, paisaje, fuentes, datos y JavaScript. Funciona sin conexión, instalación, cuenta ni servidor. El progreso se guarda de forma voluntaria en el navegador; cuando el almacenamiento no está disponible funciona en memoria.

## Recorrido

- **Inicio:** paisaje original, entrada a Aprender, búsqueda real por chino, español y pinyin y demostración con un ejercicio del banco.
- **Aprender:** selección directa de dificultad editorial, unidad temática y situación. Cada lección utiliza sus dos ejercicios existentes. Se conservan filtro y unidad al regresar de la práctica. El progreso cuenta situaciones practicadas.
- **Diccionario:** índice, búsqueda y ficha con lectura, significado, función, otras acepciones y ejemplos disponibles. Los enlaces llevan a comparaciones y situaciones reales.
- **Comparar:** dos palabras y sus significados en paralelo, registro, cautelas y acceso a ejemplos. Sustituye la tabla administrativa de V28.
- **En contexto:** frase intercambiable y explicación de su interpretación. «Ver las dos versiones» abre el análisis completo; intercambiar conserva ese panel abierto.
- **Practicar:** actividad de altura de pantalla con encabezado compacto, zona central flexible y acciones inferiores persistentes. El mapa y la gestión de la sesión están en un menú secundario. La explicación esencial permanece junto a las opciones; las versiones completas se despliegan cuando se necesitan.
- **Resultados:** coincidencias de la sesión, respuesta elegida, revisión y repaso de los matices pendientes. Revisar una respuesta no registra otro intento.

En escritorio normal, una pregunta y su feedback esencial caben sin desplazar el documento ni la región central. En poca altura, con zoom o al abrir una explicación extensa, la zona central puede desplazarse con teclado y muestra un aviso; las acciones siguen visibles. Las herramientas de consulta pueden desplazarse de forma normal.

El banco conserva **32 palabras, 14 comparaciones, 15 situaciones y 30 ejercicios**. Hay 11 unidades con práctica y 3 comparaciones consultables sin lecciones. **Inicial, intermedio y avanzado son dificultades editoriales de ejercicios; no son niveles HSK.** La clasificación HSK y la revisión lingüística siguen pendientes. No se añadieron palabras ni se modificaron definiciones, frases o claves.

## Continuar desarrollando

| Archivo | Responsabilidad |
| --- | --- |
| `index.template.html` | Estructura de Inicio, Aprender y cuatro herramientas; diálogos. |
| `assets/styles.css` | Sistema común, portada, navegación y actividad. |
| `assets/tools.css` | Aprender, diccionario, comparación, contexto y selector. |
| `assets/app.js` | Renderizado, navegación, filtros, lecciones y sesión. |
| `assets/scheduler.js` | Agenda y validación del historial, conservadas de V28. |
| `assets/landscape.svg` | Paisaje original de la portada. |
| `assets/fonts/` | Subconjuntos y licencias SIL OFL. |
| `data/vocabulary.json` | Contenido lingüístico y ejercicios. |
| `data/integrity-baseline.json` | Línea base para comprobar su conservación. |
| `tools/build.py` | Construcción del HTML autónomo y hashes CSP. |

Desde la carpeta del proyecto:

```sh
python3 tools/validate_data.py
python3 tools/build.py
python3 tools/build.py --check
```

La construcción utiliza solo la biblioteca estándar de Python y los archivos incluidos. Edita las fuentes; **index.html** es el resultado generado. Para ampliar contenido consulta **docs/CONTENIDO.md**. Regenerar fuentes requiere herramientas adicionales indicadas en **docs/TIPOGRAFIA.md**; abrir la aplicación y construir con los subconjuntos incluidos no las requiere.

## Verificación

```sh
node tools/test_scheduler.cjs
python3 tools/test_ui.py
```

Las pruebas de interfaz requieren Python, Playwright y Chromium. `python3 tools/test_ui.py --help` permite indicar el navegador y la salida. **docs/VALIDACION_V29.json** registra las pruebas reales y el SHA-256 del HTML probado; **screenshots/v29/** contiene capturas propias. Las pruebas de viewport y zoom se realizaron en Chromium automatizado, no en dispositivos físicos ni otros motores.

**docs/AUDITORIA_V29.md** documenta el banco y la jerarquía académica; **docs/SISTEMA_VISUAL_V29.md**, la identidad común; **docs/REFERENCIAS_V29.md**, las referencias observadas y sus límites de acceso; **docs/ENTREGA_V29.md**, el informe de esta versión. Las capturas de productos ajenos utilizadas durante la investigación no forman parte del frontend ni del paquete de fuentes.

Los atajos de práctica son 1, 2 y 3 para elegir y Enter para comprobar o continuar. Las ayudas muestran la lectura de las palabras disponibles; no inventan pinyin de frases completas. Los tonos también tienen sus marcas escritas. El guardado conserva el identificador de contenido y el formato anterior; al modificar el banco sigue el procedimiento de versionado de **docs/CONTENIDO.md**.
